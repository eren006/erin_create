// ==UserScript==
// @name         长日将尽系统
// @author       长日将尽
// @version      1.5.7
// @description  无
// @timestamp    1778742000
// @license      MIT
// ==/UserScript==

let ext = seal.ext.find("changri")
if (!ext) {
    ext = seal.ext.new("changri", "长日将尽", "1.5.7");
    // 注册扩展
    seal.ext.register(ext);
    ext.autoActive = true;
}
ext.autoActive = true;

// ── 存储缓存层 ──────────────────────────────────────────────────────────────
// 缓存 storageGet 的原始字符串，写时同步落库（写穿）。
// 约束：changri 存储的所有读写（含卫星插件，经 __changriApi.kvGetRaw/kvSetRaw）
// 都必须经过这两个函数；若在海豹 WebUI 直接改了插件存储，需重载本插件清缓存。
const _kvCache = Object.create(null);
function cachedGet(key) {
    if (!(key in _kvCache)) _kvCache[key] = ext.storageGet(key);
    return _kvCache[key];
}
function cachedSet(key, val) {
    const str = typeof val === "string" ? val : String(val);
    ext.storageSet(key, str);
    _kvCache[key] = str;
    delete _objCache[key];
}

// 解析对象缓存：仅限白名单热 key（每条消息都要读的账号映射/权限/开关）。
// 命中时返回同一个缓存对象——这些 key 的读取方不得修改返回对象，除非改完立即 kvSet 写回
// （2026-07 已审计全部调用点均满足）。新增白名单 key 前需做同样审计。
const _objCache = Object.create(null);
const PARSED_CACHE_KEYS = { extra_accounts: 1, a_adminList: 1, global_feature_toggle: 1 };

// JSON 对象读写（在 cachedGet/cachedSet 之上）。所有存 JSON 的 key 一律走这两个函数：
// 读到空值或损坏串时返回 def 并记日志，不让单个坏 key 炸掉整条指令。
function kvGet(key, def) {
    if (key in _objCache) return _objCache[key];
    const raw = cachedGet(key);
    if (raw === null || raw === undefined || raw === "") return def;
    try {
        const v = JSON.parse(raw);
        if (v === null || v === undefined) return def;
        if (PARSED_CACHE_KEYS[key]) _objCache[key] = v;
        return v;
    } catch (e) {
        console.error(`[长日系统] 存储 JSON 损坏，已回退默认值: ${key}`);
        return def;
    }
}
function kvSet(key, val) { cachedSet(key, JSON.stringify(val)); }

// 读取自定义类型别名，留空则返回原 subtype 值
function getCustomTypeLabel(subtype) {
    try {
        const labels = kvGet("custom_type_labels", {});
        return (labels[subtype] && labels[subtype].trim()) ? labels[subtype].trim() : subtype;
    } catch { return subtype; }
}

function escapeRegExp(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// 读取整数型设置，兼容 JSON 编码的 '"48"' 与裸字符串 '48' 两种格式
function getStorageInt(key, defaultVal) {
    const raw = cachedGet(key);
    if (!raw) return defaultVal;
    try { const v = parseInt(JSON.parse(raw)); return isNaN(v) ? defaultVal : v; }
    catch (e) { const v = parseInt(raw); return isNaN(v) ? defaultVal : v; }
}

seal.ext.registerStringConfig(ext, "ws地址", "ws://localhost:3001");
    seal.ext.registerStringConfig(ext, "ws Access token", '', "输入与上方端口对应的token，没有则留空");
    seal.ext.registerStringConfig(ext, "群管插件使用需要满足的条件", '1', "使用豹语表达式，例如：$t群号_RAW=='2001'，1为所有群可用");
    seal.ext.registerBoolConfig(ext, "开启现实时段校验", false, "是否限制玩家只能发起与当前现实时间对应的剧情时段邀约");
    seal.ext.registerBoolConfig(ext, "启用RP存档传输", false, "开启后，监听到的RP正文、短信、礼物将在结戏时发送到存档服务器");
    seal.ext.registerStringConfig(ext, "RP存档服务器地址", "http://localhost:6666", "Flask存档服务器地址，末尾不带/");
    seal.ext.registerStringConfig(ext, "RP存档Token", "", "存档服务器API验证Token，与服务器端RP_API_TOKEN环境变量一致，留空则不验证");


// ========================
// 🌐 WebSocket 通信模块
// ========================
// 批量同步专用函数（使用单个连接）
function wsBatchSync(requestQueue, ctx, msg) {
    const wsUrl = seal.ext.getStringConfig(ext, "ws地址");
    const token = seal.ext.getStringConfig(ext, "ws Access token");
    let connectionUrl = wsUrl;

    if (token) {
        const separator = connectionUrl.includes('?') ? '&' : '?';
        connectionUrl += `${separator}access_token=${encodeURIComponent(token)}`;
    }

    const ws = new WebSocket(connectionUrl);
    let isClosed = false;
    let currentIndex = 0;
    let successCount = 0;
    let failureCount = 0;

    const closeSafe = (reason) => {
        if (!isClosed) {
            isClosed = true;
            clearTimeout(timeoutId);
            if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
                ws.close(1000, reason);
            }
        }
    };

    const timeoutId = setTimeout(() => {
        if (!isClosed) {
            console.log(`[WS] 批量同步超时`);
            closeSafe("TIMEOUT");
        }
    }, 30000); // 30秒超时

    let pendingEcho = null;

    const sendNext = () => {
        if (currentIndex >= requestQueue.length) {
            closeSafe("BATCH_COMPLETE");
            return;
        }

        const postData = requestQueue[currentIndex];
        pendingEcho = postData.action + "_" + Date.now() + "_" + currentIndex;
        postData.echo = pendingEcho;

        if (postData.params) {
            if (postData.params.message_id) postData.params.message_id = parseInt(postData.params.message_id);
            if (postData.params.group_id) postData.params.group_id = parseInt(postData.params.group_id);
        }

        try {
            ws.send(JSON.stringify(postData));
        } catch (e) {
            console.error('发送失败:', e);
            currentIndex++;
            failureCount++;
            sendNext();
        }
    };

    ws.onopen = function() {
        sendNext();
    };

    ws.onmessage = function(event) {
        try {
            const response = JSON.parse(event.data);
            if (response.post_type === "meta_event") return;
            if (!response.echo || response.echo !== pendingEcho) return;

            if (response.status === 'ok' || response.retcode === 0) {
                successCount++;
            } else {
                console.error(`[WS] 请求失败: ${response.echo}`);
                failureCount++;
            }

            currentIndex++;
            setTimeout(sendNext, 50);
        } catch (e) {
            console.error('收包解析异常:', e);
        }
    };

    ws.onerror = function(e) {
        if (isClosed || ws.readyState === WebSocket.CLOSING || ws.readyState === WebSocket.CLOSED) {
            return;
        }
        console.error('[WS] 连接异常，请检查OneBot连接状态');
        closeSafe("ERROR");
    };

    ws.onclose = function(event) {
        isClosed = true;
        const resultMsg = `✅ 同步完成！\n成功: ${successCount}\n失败: ${failureCount}\n总计: ${requestQueue.length}`;
        seal.replyToSender(ctx, msg, resultMsg);
    };
}

// ── WS 请求器：每请求短连接 + echo 匹配 + 超时清理 ──
// 注意：不做常驻连接。配置的 ws地址 是 OneBot 正向 WS 的 universal 端点（根路径），
// 常驻连接会持续收到全部 QQ 事件推送涌入海豹 JS 运行时，且插件重载后旧连接
// 回调悬空，实测会导致海豹崩溃。社区插件（恋综2.2.2 等）均为短连接模式。
// 收益保留在结构层：全系统唯一实现，卫星插件经 api.ws 委托；
// echo 带自增序号，避免同毫秒两个同名 action 串包。
const WSM = {
    seq: 0,

    buildUrl() {
        let url = seal.ext.getStringConfig(ext, "ws地址") || "";
        const token = seal.ext.getStringConfig(ext, "ws Access token");
        if (url && token) {
            url += (url.includes("?") ? "&" : "?") + "access_token=" + encodeURIComponent(token);
        }
        return url;
    },

    // 发起一次请求；onResponse 收到完整 response 对象；超时/失败走 onTimeout
    request(postData, onResponse, onTimeout, timeoutMs = 3000) {
        const echo = postData.echo || (postData.action + "_" + Date.now() + "_" + (this.seq++));
        postData.echo = echo;
        let payload;
        try { payload = JSON.stringify(postData); } catch (e) {
            console.error("发送失败, JSON序列化错误:", e);
            return null;
        }
        const url = this.buildUrl();
        if (!url) {
            console.error("[WS] 未配置 ws地址");
            if (onTimeout) onTimeout();
            return null;
        }
        let conn;
        try { conn = new WebSocket(url); } catch (e) {
            console.error("[WS] 连接创建失败，请检查 ws地址 配置:", e);
            if (onTimeout) onTimeout();
            return null;
        }
        let done = false;
        const finish = (reason) => {
            if (done) return;
            done = true;
            clearTimeout(timer);
            if (conn.readyState === WebSocket.OPEN || conn.readyState === WebSocket.CONNECTING) {
                try { conn.close(1000, reason); } catch (e) { console.error("[WS] 关闭连接失败:", e.message); }
            }
        };
        const timer = setTimeout(() => {
            if (!done) {
                console.log(`[WS] 请求超时: ${postData.action}`);
                finish("TIMEOUT");
                if (onTimeout) onTimeout();
            }
        }, timeoutMs);
        conn.onopen = () => {
            try { conn.send(payload); } catch (e) {
                console.error("[WS] 发送失败:", e);
                finish("SEND_ERROR");
                if (onTimeout) onTimeout();
            }
        };
        conn.onmessage = (event) => {
            if (done) return;
            let response;
            try { response = JSON.parse(event.data); } catch (e) { return; }
            if (response.post_type === "meta_event") return;
            if (response.echo !== echo) return;
            finish("DONE");
            try { onResponse(response); } catch (e) { console.error("[WS] 回调异常:", e); }
        };
        conn.onerror = () => {
            if (done || conn.readyState === WebSocket.CLOSING || conn.readyState === WebSocket.CLOSED) return;
            console.error("[WS] 运行异常，请检查地址、Token或OneBot连接状态");
        };
        conn.onclose = (event) => {
            // 仅在异常关闭（请求未完成）时打日志；成功后的关闭忽略 code
            if (!done && event && event.code !== 1000) {
                console.log(`[WS] 连接已关闭 (代码: ${event.code}, 原因: ${event.reason || ""})`);
            }
            // 未收到响应即被关闭（如 OneBot 未启动、连接被拒）：立即按失败处理
            if (!done) {
                done = true;
                clearTimeout(timer);
                if (onTimeout) onTimeout();
            }
        };
        return echo;
    },

    // 单向发送，不关心响应
    push(postData) {
        this.request(postData, () => {}, null);
    },
};

// 兼容包装：签名与历史版本一致，全部调用点无需改动
// timeoutMs 可选：默认沿用 WSM.request 的 3000ms，个别偏慢的动作（如 set_group_name）可单独放宽
function ws(postData, ctx, msg, successreply, errorreply, timeoutMs) {
    if (postData.params) {
        if (postData.params.message_id) postData.params.message_id = parseInt(postData.params.message_id);
        if (postData.params.group_id) postData.params.group_id = parseInt(postData.params.group_id);
    }
    WSM.request(postData,
        (response) => {
            if (response.status === 'ok' || response.retcode === 0) {
                if (postData.action === "get_group_member_list") {
                    handleMemberListResponse(ctx, msg, response.data, postData.echo);
                } else if (postData.action === "get_group_info") {
                    handleGroupInfoResponse(response.data, postData.echo);
                } else {
                    if (successreply) seal.replyToSender(ctx, msg, successreply);
                }
            } else {
                console.error(`[WS] 服务端返回错误: ${JSON.stringify(response)}`);
                if (errorreply) seal.replyToSender(ctx, msg, errorreply);
            }
        },
        () => { if (errorreply) seal.replyToSender(ctx, msg, errorreply); },
        timeoutMs
    );
    return seal.ext.newCmdExecuteResult(true);
}

// 暴露给其他插件使用
ext._ws = ws;

// 音乐卡片发送偏慢、偶发失败（OneBot 侧），单独放宽超时并失败重试一次，
// 重试仍失败才提示用户
// message 用 OneBot v11 标准数组段格式（而非 CQ 码字符串），
// 避开 LLOneBot 对 CQ 码字符串解析路径的问题
function sendMusicCardWithRetry(ctx, msg, gid, songMeta, attempt) {
    attempt = attempt || 1;
    const cardMsg = [{ type: "music", data: { type: songMeta.musicType, id: Number(songMeta.songId) } }];
    WSM.request(
        { action: "send_group_msg", params: { group_id: gid, message: cardMsg } },
        (response) => {
            if (response.status === 'ok' || response.retcode === 0) {
                seal.replyToSender(ctx, msg, "✅ 点歌已同步至戏群。");
                return;
            }
            console.error(`[WS] 服务端返回错误: ${JSON.stringify(response)}`);
            if (attempt < 2) {
                setTimeout(() => sendMusicCardWithRetry(ctx, msg, gid, songMeta, attempt + 1), 1500);
            } else {
                sendSongFallbackText(ctx, msg, gid, songMeta);
            }
        },
        () => {
            if (attempt < 2) {
                setTimeout(() => sendMusicCardWithRetry(ctx, msg, gid, songMeta, attempt + 1), 1500);
            } else {
                sendSongFallbackText(ctx, msg, gid, songMeta);
            }
        },
        6000
    );
}

// 卡片重试仍失败时的兜底：文字消息通道已反复验证稳定，
// 改发文字通知到戏群，保证歌曲信息至少能送达
// 对玩家呈现为正常点歌结果，不暴露卡片发送失败的细节（LLOneBot 侧问题排查中）
function sendSongFallbackText(ctx, msg, gid, songMeta) {
    const { musicType, songId, songTitle, songArtist } = songMeta;
    const label = musicType === "163" ? "网易云音乐" : musicType === "qq" ? "QQ音乐" : musicType;
    const link  = musicType === "163" ? `https://music.163.com/#/song?id=${songId}`
                : musicType === "qq"  ? `https://y.qq.com/n/ryqq/songDetail/${songId}`
                : "";
    const songLine = songTitle ? `《${songTitle}》${songArtist ? " - " + songArtist : ""}\n` : "";
    const text = `🎵 【点歌台】\n${songLine}${label}${link ? "：" + link : "，ID：" + songId}`;
    ws({ action: "send_group_msg", params: { group_id: gid, message: text } }, ctx, msg,
        "✅ 点歌已同步至戏群。",
        "❌ 点歌失败：请稍后重试。");
}

// 点歌投递：gid/dgr/ly 全部由调用方通过闭包传入，不读全局 temp key
// userSongName：玩家在指令里填的歌名（选填），优先于从卡片 JSON 里猜的 title
// songTo：点歌献给谁（选填），只用于戏群里的点歌台提示文案
function handleSongDelivery(ctx, msg, data, gid, dgr, ly, userSongName, songTo) {
    if (!data || !data.message) {
        seal.replyToSender(ctx, msg, "❌ 点歌失败：消息内容为空，请确认回复的是音乐卡片。");
        return;
    }
    const originalContent = typeof data.message === 'string' ? data.message : JSON.stringify(data.message);

    // 优先匹配 CQ 码格式：[CQ:music,type=qq,id=xxx] / [CQ:music,type=163,id=xxx]
    const cqMatch = originalContent.match(/\[CQ:music,type=(\w+),id=([\w]+)\]/);
    // 次优先匹配 JSON 格式：{"type":"qq","id":"xxx"}
    const jsonTypeMatch = originalContent.match(/"type"\s*:\s*"(qq|163|kugou|migu|kuwo)"/);
    const jsonIdMatch   = originalContent.match(/"id"\s*:\s*"?([\w]+)"?/);

    let songId = "";
    let musicType = "163";

    if (cqMatch) {
        musicType = cqMatch[1];
        songId    = cqMatch[2];
    } else if (jsonTypeMatch && jsonIdMatch) {
        musicType = jsonTypeMatch[1];
        songId    = jsonIdMatch[1];
    } else {
        // 兜底：mid/songmid 字段（旧版 QQ 音乐格式）
        const qqFallback = originalContent.match(/["'](?:mid|songmid)["']\s*[:=]\s*["'](\w+)["']/)
                        || originalContent.match(/mid=([\w]+)/);
        const neteaseFallback = originalContent.match(/id[=:]\s*(\d+)/);
        if (qqFallback) { songId = qqFallback[1]; musicType = "qq"; }
        else if (neteaseFallback) { songId = neteaseFallback[1]; musicType = "163"; }
    }

    // 尝试从分享卡片 JSON 里取歌名/歌手（meta.music 下的 title/desc），仅卡片失败降级成文字时用得上
    let songTitle = "", songArtist = "";
    const musicBlockMatch = originalContent.match(/"music"\s*:\s*\{([^}]*)\}/);
    if (musicBlockMatch) {
        const titleM = musicBlockMatch[1].match(/"title"\s*:\s*"([^"]*)"/);
        const descM  = musicBlockMatch[1].match(/"desc"\s*:\s*"([^"]*)"/);
        if (titleM) songTitle  = titleM[1];
        if (descM)  songArtist = descM[1];
    }
    if (userSongName) songTitle = userSongName;

    if (songId) {
        const toLine = songTo ? `送给：${songTo}\n` : "";
        ws({ action: "send_group_msg", params: { group_id: gid, message: `🎵 【点歌台】\n点歌人：${dgr}\n${toLine}留言：${ly}` } }, ctx, msg, "",
            "❌ 点歌同步失败：戏群消息发送异常，请稍后重试。");
        setTimeout(() => {
            sendMusicCardWithRetry(ctx, msg, gid, { musicType, songId, songTitle, songArtist });
        }, 800);
    } else {
        seal.replyToSender(ctx, msg, "❌ 识别失败，请引用音乐分享卡片。");
    }
}

// ========================
// 📦 RP存档模块
// ========================

function isArchiveEnabled() {
    return seal.ext.getBoolConfig(ext, "启用RP存档传输");
}

// 强结私约是否发放结戏奖励，「设置 互动参数」中的「强结发放奖励」开关（默认关闭）
function isForceEndRewardEnabled() {
    return cachedGet("force_end_grant_reward") === "true";
}

function applyMsgTemplate(tplName, vars) {
    const raw = cachedGet("custom_message_templates");
    if (!raw) return null;
    try {
        const tpl = JSON.parse(raw)[tplName];
        if (!tpl || !tpl.trim()) return null;
        return tpl.replace(/\{([^}]+)\}/g, (_, k) => (vars[k] !== undefined ? vars[k] : `{${k}}`));
    } catch (e) { return null; }
}

async function postToArchive(endpoint, data) {
    const base = (seal.ext.getStringConfig(ext, "RP存档服务器地址") || "").replace(/\/$/, "");
    const token = seal.ext.getStringConfig(ext, "RP存档Token") || "";
    if (!base) return;
    // 网络抖动重试：session_end 丢失会导致该场次统计永远停留在 entry 累加值
    for (let attempt = 1; attempt <= 3; attempt++) {
        try {
            const resp = await fetch(base + endpoint, {
                method: "POST",
                headers: { "Content-Type": "application/json", "X-Archive-Token": token },
                body: JSON.stringify(data)
            });
            if (resp.ok) return;
            // 4xx 是请求本身的问题，重试无意义
            if (resp.status < 500) {
                console.error(`[RP存档] ${endpoint} 返回 ${resp.status}，不重试`);
                return;
            }
            console.error(`[RP存档] ${endpoint} 返回 ${resp.status}（第${attempt}次）`);
        } catch (e) {
            console.error(`[RP存档] 发送失败 ${endpoint}（第${attempt}次）:`, e.message || String(e));
        }
        if (attempt < 3) await new Promise(r => setTimeout(r, attempt * 3000));
    }
}

// 从一个 [CQ:image,...] 标签里提取可下载的原图链接：优先 url= 字段；
// 有的 OneBot 实现（实测 LLOneBot 某些版本）不带 url=，而是把下载链接直接放在 file= 里，这种也认
function extractImageSrc(cqTag) {
    const urlMatch = cqTag.match(/url=([^,\]]+)/);
    if (urlMatch) return urlMatch[1];
    const fileMatch = cqTag.match(/file=([^,\]]+)/);
    if (fileMatch && /^https?:\/\//i.test(fileMatch[1])) return fileMatch[1];
    return null;
}

// 「删除上传」/「我清空」/「查看收集」失效检查共用：把已转存到 rp_archive 的图片文件删掉（连同配额记录），
// 尽力而为，请求失败不阻塞主流程（本地记录该删还是删，只是服务器那边的文件可能没删干净）
async function deleteCollectedImage(imageUrl) {
    const base = (seal.ext.getStringConfig(ext, "RP存档服务器地址") || "").replace(/\/$/, "");
    const token = seal.ext.getStringConfig(ext, "RP存档Token") || "";
    if (!base) return false;
    try {
        const resp = await fetch(base + "/api/collect_image/delete", {
            method: "POST",
            headers: { "Content-Type": "application/json", "X-Archive-Token": token },
            body: JSON.stringify({ url: imageUrl })
        });
        const data = await resp.json();
        return !!(data && data.ok);
    } catch (e) {
        console.error("[删除收集图片] 失败:", e.message || String(e));
        return false;
    }
}

// 从一段存档文本里提取所有已转存图片的永久链接——只有改用直存 QQ 链接方案之前的老记录才会有这种格式，
// extractStoredImageUrls/isStoredImageAlive/deleteCollectedImage 三件套是专门留给这些老记录扫尾用的
function extractStoredImageUrls(text) {
    if (!text) return [];
    return [...text.matchAll(/\[CQ:image,url=([^,\]]+)\]/g)].map(m => m[1]);
}

// 图片相关功能（我提交/出场图片）不再经 rp_archive 下载落地（参考开源恋综插件「公知/二表」的做法：
// 直接存 QQ 原始链接，零下载零磁盘占用）。QQ 图片链接实测至少能扛 3 天，超过这个阈值后展示时自动把
// 图片标签换成提示文字，避免裂图——用时间戳被动降级，不用再对 QQ 发 HEAD 请求去反复探活。
const COLLECT_IMAGE_STALE_MS = 3 * 24 * 60 * 60 * 1000;
function degradeStaleImages(text, ts) {
    if (!text || !ts) return text; // 没有时间戳的是老记录（rp_archive永久链接），不受影响
    if (Date.now() - ts <= COLLECT_IMAGE_STALE_MS) return text;
    return text.replace(/\[CQ:image,[^\]]*\]/g, "[图片已过期]");
}

// 查看收集时的失效检查：图片如果被超级管理员在 rp_archive 那边直接删掉了，HEAD 请求会 404
async function isStoredImageAlive(imageUrl) {
    const base = (seal.ext.getStringConfig(ext, "RP存档服务器地址") || "").replace(/\/$/, "");
    if (!base || !imageUrl.startsWith(base)) return true; // 不是本服务器的链接就不检查，当正常处理
    try {
        const resp = await fetch(imageUrl, { method: "HEAD" });
        return resp.ok;
    } catch (e) {
        return true; // 网络抖动时不要误删，保守当作还在
    }
}

function buildSessionArchive(gid, platform, forced) {
    const timers = getGroupTimers();
    const timer  = timers[gid] || {};
    const ss     = getSessionStats()[gid] || {};

    const startTs = ss._startTime || Date.now();
    const endTs   = Date.now();
    const sessionId = `${gid}_${startTs}`;

    const participants = timer.participants || [];

    // 每人统计（uid → roleName 映射后输出）
    const stats = {};
    participants.forEach(roleName => {
        const uid = getUidByRoleName(platform, roleName);
        if (uid && ss[uid]) {
            stats[roleName] = { replies: ss[uid].replies || 0, words: ss[uid].words || 0 };
        }
    });

    const expireInfo = kvGet("group_expire_info", {})[gid] || {};
    const gameDay    = expireInfo.day  || timer.day || cachedGet("global_days") || "";

    // 心动信/短信/礼物均已在事件发生时实时 POST /api/event，此处不再批量附带
    // （心动信 pool 投完即清空，批量读取必然为空；短信/礼物实时上传已含 session_id）

    // 顺带附上 QQ→角色映射，服务器自动更新玩家数据库，无需手动同步
    const _npcListBuild = kvGet("a_npc_list", []);
    const playersList = participants.map(roleName => {
        const uid = getUidByRoleName(platform, roleName);
        return uid ? { qq: uid, role_name: roleName, is_npc: _npcListBuild.includes(roleName) } : null;
    }).filter(Boolean);

    return {
        session_id:   sessionId,
        group_id:     gid,
        platform:     platform,
        game_day:     gameDay,
        game_time:    expireInfo.time    || timer.time    || "",
        place:        expireInfo.place   || timer.place   || "",
        subtype:      timer.subtype      || expireInfo.subtype || "",
        participants: participants,
        start_ts:     startTs,
        end_ts:       endTs,
        forced:       forced ? 1 : 0,
        stats:        stats,
        players:      playersList,
    };
}

// ========================
// 🔧 核心工具函数
// ========================

// 全局静默标记和回调
const silentMemberCallbackMap = new Map();

function handleMemberListResponse(ctx, msg, data, echo) {
    let members = [];
    if (Array.isArray(data)) {
        members = data;
    } else if (data && typeof data === 'object') {
        members = data.members || data.list || Object.values(data);
    }

    if (echo && silentMemberCallbackMap.has(echo)) {
        const callback = silentMemberCallbackMap.get(echo);
        silentMemberCallbackMap.delete(echo);
        if (typeof callback === 'function') {
            callback(members);
        }
        return;
    }

    // 3. 如果是审计模式（用于管理员检查群成员对不对），执行审计逻辑
    const auditOwner = cachedGet("temp_audit_owner");
    if (auditOwner) {
        performAuditLogic(ctx, msg, auditOwner, members);
        cachedSet("temp_audit_owner", "");
        return; // 结束
    }
}

/**
 * 静默获取群成员列表（不输出到聊天窗口）
 * @param {string} gid 群号
 * @param {Object} ctx 上下文
 * @param {Object} msg 消息对象
 * @returns {Promise<Array>} 成员列表
 */
function getGroupMembersSilent(gid, ctx, msg) {
    return new Promise((resolve) => {
        const echo = `get_group_member_list_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
        silentMemberCallbackMap.set(echo, resolve);

        ws({
            action: "get_group_member_list",
            params: { group_id: parseInt(gid, 10) },
            echo: echo
        }, ctx, msg, null);

        // 超时兜底：3.5秒后若仍未响应，清理并以空数组 resolve，避免 Promise 永远悬空
        setTimeout(() => {
            if (silentMemberCallbackMap.has(echo)) {
                console.warn(`[getGroupMembersSilent] 超时未响应，echo: ${echo}, gid: ${gid}`);
                silentMemberCallbackMap.delete(echo);
                resolve([]);
            }
        }, 3500);
    });
}

// 全局静默标记和回调（群信息）
const silentGroupInfoCallbackMap = new Map();

function handleGroupInfoResponse(data, echo) {
    if (echo && silentGroupInfoCallbackMap.has(echo)) {
        const callback = silentGroupInfoCallbackMap.get(echo);
        silentGroupInfoCallbackMap.delete(echo);
        if (typeof callback === 'function') callback(data || null);
    }
}

/**
 * 静默获取群信息（不输出到聊天窗口），主要用于取群名
 * @param {string} gid 群号
 * @param {Object} ctx 上下文
 * @param {Object} msg 消息对象
 * @returns {Promise<Object|null>} 群信息（含 group_name），失败/超时为 null
 */
function getGroupInfoSilent(gid, ctx, msg) {
    return new Promise((resolve) => {
        const echo = `get_group_info_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
        silentGroupInfoCallbackMap.set(echo, resolve);

        ws({
            action: "get_group_info",
            params: { group_id: parseInt(gid, 10) },
            echo: echo
        }, ctx, msg, null);

        setTimeout(() => {
            if (silentGroupInfoCallbackMap.has(echo)) {
                silentGroupInfoCallbackMap.delete(echo);
                resolve(null);
            }
        }, 3500);
    });
}

/**
 * 核心对比逻辑：执行结果分析
 */
function performAuditLogic(ctx, msg, ownerName, members) {
    const platform = msg.platform;
    const a_private_group = kvGet("a_private_group", {});
    const npcList = kvGet("a_npc_list", []);
    
    const playerMap = {}; 
    const npcUIDs = {};   
    const memberUIDs = members.map(m => (m.user_id || m.qq).toString());

    // 建立映射（新结构：uid为key，roleName在value[0]）
    Object.entries(a_private_group[platform] || {}).forEach(([uid, data]) => {
        const name = data[0];
        if (npcList.includes(name)) npcUIDs[name] = uid;
        else playerMap[uid] = name;
    });

    // 通过 ownerName 反查 uid
    const ownerEntry = Object.entries(a_private_group[platform] || {}).find(([_, v]) => v[0] === ownerName);
    if (!ownerEntry) return;
    const ownerUID = ownerEntry[0];
    const gid = ownerEntry[1][1];

    // 1. 检查缺 NPC
    let missing = npcList.filter(n => !memberUIDs.includes(npcUIDs[n]));
    // 2. 检查多玩家
    let overlaps = memberUIDs.filter(id => playerMap[id] && id !== ownerUID).map(id => playerMap[id]);

    // 只有异常才回复
    if (missing.length > 0 || overlaps.length > 0) {
        let res = `📌 群「${ownerName}」(${gid})：\n`;
        if (missing.length > 0) res += `❌ 缺NPC：${missing.join('/')}\n`;
        if (overlaps.length > 0) res += `⚠️ 重合：${overlaps.join('/')}`;
        seal.replyToSender(ctx, msg, res.trim());
    }
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 10);
}

function generateGroupRef() {
    return "grp_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 8);
  }
  

  function isValidTimeFormat(timeStr) {
    const regex = /^(\d{2}):(\d{2})-(\d{2}):(\d{2})$/;
    const match = timeStr.match(regex);
    if (!match) return false;
  
    const [, h1, m1, h2, m2] = match.map(Number);
    if (
      h1 < 0 || h1 > 23 || m1 < 0 || m1 > 59 ||
      h2 < 0 || h2 > 23 || m2 < 0 || m2 > 59
    ) return false;
  
    const start = h1 * 60 + m1;
    const end = h2 * 60 + m2;
  
    // ❌ 禁止跨日
    if (end <= start) return false;
  
    return true;
  }
  
function parseTimeRange(timeStr) {
  const [start, end] = timeStr.split("-");
  return [parseInt(start.replace(":", "")), parseInt(end.replace(":", ""))];
}
function timeConflict(newDay, newTime, existingDay, existingTime) {
  if (newDay !== existingDay) return false;
  const [newStart, newEnd] = parseTimeRange(newTime);
  const [existStart, existEnd] = parseTimeRange(existingTime);
  return !(newEnd <= existStart || newStart >= existEnd);
}

function isUserAdmin(ctx, msg) {
    const platform = msg.platform;
    const uid = msg.sender.userId.replace(`${platform}:`, "");
    const a_adminList = kvGet("a_adminList", {});
    return ctx.privilegeLevel === 100 || (a_adminList[platform] && a_adminList[platform].includes(uid));
  }

  function timeOverlap(t1, t2) {
    const [start1, end1] = parseStartEnd(t1);
    const [start2, end2] = parseStartEnd(t2);
    return !(end1 <= start2 || end2 <= start1); // 包含、重叠、边界接触全都算冲突
  }
  

  function normalizeTimeString(s) {
    return s.replace(/\s+/g, "").replace("–", "-").replace("－", "-");
  }
  
  function parseStartEnd(t) {
    t = normalizeTimeString(t); // ✅ 标准化时间段格式
    const [s, e] = t.split("-");
    const toMin = t => {
      const [h, m] = t.split(":").map(Number);
      return h * 60 + m;
    };
    return [toMin(s), toMin(e)];
  }


function recordMeetingAndAnnounce(subtype, platform, ctx, endPoint) {
    const subtypeKeyMap = {
        "电话": "call",
        "私密": "private",
        "寄信": "chaosletter",
        "发送信件": "directletter",
        "心动信": "lovemail",
        "礼物": "gift",
        "心愿": "wish",
        "官约": "official",
        "拉线": "relation"
    };
    const keyType = subtypeKeyMap[subtype] || "unknown";
    const storageKey = `a_meetingCount_${keyType}`;

    let count = parseInt(cachedGet(storageKey) || "0");
    count++;
    cachedSet(storageKey, count.toString());

    const groupId = kvGet("adminAnnounceGroupId", null);

    if (groupId) {
        const msgDivineLog = seal.newMessage();
        msgDivineLog.messageType = "group";
        msgDivineLog.groupId = `${platform}-Group:${groupId}`;
        const ctxDivineLog = seal.createTempCtx(endPoint, msgDivineLog);

        const getStageText = (subtype, count) => {
            // --- 核心修改部分：从配置项获取频率 ---
            // 获取用户在插件设置里填写的数字，默认为 5
            const frequency = getStorageInt("announceFrequency", 5);
            
            // 检查是否应该触发公告：使用动态频率
            let shouldAnnounce = (count % frequency === 0);
            
            if (!shouldAnnounce) return null;

            const getDirectRecord = (type, count, emoji) => {
                return `${emoji} 【第${count}次${type}记录】`;
            };

            // ... 以下逻辑保持不变 ...
            if (subtype === "电话") return getDirectRecord(getCustomTypeLabel("电话"), count, "☎️");
            if (subtype === "私密") return getDirectRecord(getCustomTypeLabel("私密"), count, "💫");
            if (subtype === "寄信") return getDirectRecord("寄信", count, "📮");

            if (subtype === "心动信") return getDirectRecord("心动信派送", count, "💌");
            if (subtype === "礼物") return getDirectRecord("礼物赠送", count, "🎁");
            if (subtype === "心愿") return getDirectRecord(getCustomTypeLabel("心愿"), count, "🌠");
            if (subtype === "官约") return getDirectRecord(getCustomTypeLabel("官约"), count, "🏢");
            if (subtype === "拉线") return getDirectRecord("关系线记录", count, "🔗");

            return getDirectRecord("互动", count, "📝");
        };

        const broadcastText = getStageText(subtype, count);
        if (broadcastText) {
            seal.replyToSender(ctxDivineLog, msgDivineLog, broadcastText);
        }
    }
}

// 统一的接受请求冲突检查函数
function checkAcceptanceConflicts(platform, userId, roleName, day, time, excludeMultiGroupRef = null, excludeAppointmentId = null) {
  const results = [];
  
  // 1. 检查锁定冲突
  const a_lockedSlots = kvGet("a_lockedSlots", {});
  const locked = a_lockedSlots[`${platform}:${userId}`]?.[day] || [];
  for (let slot of locked) {
    if (timeOverlap(slot, time)) {
      results.push(`在 ${day} ${slot} 被管理员锁定`);
      break;
    }
  }

  // 2. 检查已确认日程冲突
  const b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
  const confirmedList = b_confirmedSchedule[`${platform}:${userId}`] || [];
  for (let sch of confirmedList) {
    if (sch.day === day && timeOverlap(sch.time, time)) {
      results.push(`在 ${day} ${time} 已有确认的${getCustomTypeLabel(sch.subtype || '') || '活动'}安排`);
      break;
    }
  }

  // 3. 检查已接受但未成团的多人邀请（排除当前邀约）
  const b_MultiGroupRequest = kvGet("b_MultiGroupRequest", {});
  for (let [ref, group] of Object.entries(b_MultiGroupRequest)) {
    // 排除当前正在处理的多人邀约
    if (excludeMultiGroupRef && ref === excludeMultiGroupRef) continue;
    
    const status = group.targetList?.[roleName];
    if (status === "accepted" && group.day === day && timeOverlap(group.time, time)) {
      results.push(`在 ${day} ${time} 已接受其他多人小群邀请`);
      break;
    }
  }

  return results;
}

  function getAdminPassword() {
    let rawPass = cachedGet("adminPassword");
    let parsedPass;
  
    try {
      parsedPass = JSON.parse(rawPass);
    } catch (e) {
      parsedPass = rawPass;
    }
  
    return (parsedPass || "detroit").trim(); // 兜底并清理空格
  }

function isUserFeatureEnabled(uid, key, defaultValue = true) {
  const blockMap = kvGet("feature_user_blocklist", {});
  const personConfig = blockMap[uid];
  if (personConfig && personConfig[key] !== undefined) {
    return personConfig[key];
  }
  return defaultValue;
}
 // 辅助函数：统一获取并清洗数据格式
function getRoleStorage() {
    let data = kvGet("a_private_group", {});
    // 直接返回数据，不再进行 Array 检查和 needsUpdate 判断
    return data;
}

// ========================
// 👤 角色与权限管理
// ========================

// ── 季度工具函数 ──────────────────────────────────────────────────────────────
function getSeasonShowName() { return cachedGet("season_show_name") || ""; }
function getSeasonMode()     { return cachedGet("season_mode") || "review"; }
function hasActiveSeason()   { return !!getSeasonShowName(); }

// a_private_group 是否已无任何角色（所有 platform 下都无 uid entry）
function isRoleStorageEmpty() {
    const storage = getRoleStorage();
    for (const platform of Object.keys(storage)) {
        if (Object.keys(storage[platform] || {}).length > 0) return false;
    }
    return true;
}
// ─────────────────────────────────────────────────────────────────────────────

// 1. 创建新角色
let cmd_bind_role = {};
cmd_bind_role.solve =(ctx, msg, cmdArgs) => {
    let name = cmdArgs.getArgN(1);
    if (!name || name === "help") {
        const ret = seal.ext.newCmdExecuteResult(true);
        ret.showHelp = true;
        return ret;
    }

    if (isArchiveEnabled() && !hasActiveSeason()) {
        seal.replyToSender(ctx, msg, "⚠️ 当前没有活跃的季度，请联系主办发起「创建新季度」后再创建角色。");
        return seal.ext.newCmdExecuteResult(true);
    }

    let platform = msg.platform;
    let gid = msg.groupId ? msg.groupId.replace(`${platform}-Group:`, "") : "0";
    let uid = msg.sender.userId.replace(`${platform}:`, "");
    let storage = getRoleStorage();

    if (!storage[platform]) storage[platform] = {};

    // 检查名称是否被他人占用（新结构：uid为key，roleName在value[0]）
    const existingUidForName = Object.entries(storage[platform]).find(([k, v]) => v[0] === name && k !== uid)?.[0];
    if (existingUidForName) {
        seal.replyToSender(ctx, msg, `❌ 名称「${name}」已被其他用户占用`);
        return seal.ext.newCmdExecuteResult(true);
    }

    // 已有角色则拒绝，提示用修改名字（新结构：直接按uid查找）
    if (storage[platform][uid]) {
        const existingName = storage[platform][uid][0];
        seal.replyToSender(ctx, msg, `⚠️ 你已有角色「${existingName}」。若想改名，请发送「修改名字 新名字」。`);
        return seal.ext.newCmdExecuteResult(true);
    }

    storage[platform][uid] = [name, gid];
    kvSet("a_private_group", storage);
    initCharProfile(platform, name);

    const profile = getCharProfile(platform, name);
    seal.replyToSender(ctx, msg,
        `✅ 角色「${name}」创建成功！\n` +
        `\n欢迎加入长日！以下是你的初始档案：\n` +
        `👤 性别：${profile.gender}　年龄：${profile.age}\n` +
        `🌸 皮相：${profile.look}\n` +
        `\n💡 可发送以下消息定制角色：\n` +
        `  修改性别 男/女\n` +
        `  修改年龄 数字\n` +
        `  修改皮相 明星名\n` +
        `  修改签名 你的签名（12小时冷却）\n` +
        `\n📋 发送「我的」随时查看"我的待回/我的弧长/我的数量"这些自查指令的速查一览。\n` +
        `\n发送「玩家名单」查看所有角色。`
    );
    seal.replyToSender(ctx, msg, `📋 记不住指令格式？发送「格式」查看目录，发送「格式+类型」（如「格式心动信」）直接拿可复制的模板。\n📖 发送「玩家指南」随时查看这份入门指令一览，发送「基础指南」查看约会互动类指令。`);
    return seal.ext.newCmdExecuteResult(true);
};

// 修改名字
function doRenameRole(ctx, msg, newName) {
    const platform = msg.platform;
    const uid = msg.sender.userId.replace(`${platform}:`, "");
    const storage = getRoleStorage();
    if (!storage[platform]) return seal.replyToSender(ctx, msg, "❌ 请先创建角色");

    const entry = storage[platform][uid];
    if (!entry) return seal.replyToSender(ctx, msg, "❌ 请先创建角色");
    const oldName = entry[0];
    if (oldName === newName) return seal.replyToSender(ctx, msg, "❌ 新名字与当前名字相同");

    const takenByOther = Object.entries(storage[platform]).find(([k, v]) => v[0] === newName && k !== uid);
    if (takenByOther) return seal.replyToSender(ctx, msg, `❌ 名字「${newName}」已被他人使用`);

    storage[platform][uid][0] = newName;
    kvSet("a_private_group", storage);

    const npcList = kvGet("a_npc_list", []);
    const npcIdx = npcList.indexOf(oldName);
    if (npcIdx !== -1) { npcList[npcIdx] = newName; kvSet("a_npc_list", npcList); }

    const relData = kvGet("relationship_lines", {});
    if (relData[platform]) {
        for (const rels of Object.values(relData[platform])) {
            for (const rel of Object.values(rels)) {
                if (rel.initiator === oldName) rel.initiator = newName;
                if (Array.isArray(rel.details)) rel.details.forEach(d => { if (d.from === oldName) d.from = newName; });
            }
        }
        kvSet("relationship_lines", relData);
    }

    // 同步 b_confirmedSchedule 中的 partner 字段
    const bcs = kvGet("b_confirmedSchedule", {});
    let bcsChanged = false;
    for (const schedList of Object.values(bcs)) {
        for (const ev of schedList) {
            if (ev.partner && ev.partner !== "多人小群") {
                const parts = ev.partner.split(/[、,]/).map(s => s.trim());
                const idx = parts.indexOf(oldName);
                if (idx !== -1) { parts[idx] = newName; ev.partner = parts.join("、"); bcsChanged = true; }
            }
        }
    }
    if (bcsChanged) kvSet("b_confirmedSchedule", bcs);

    // 同步 group_expire_info 中的 participants
    const gei = kvGet("group_expire_info", {});
    let geiChanged = false;
    for (const info of Object.values(gei)) {
        if (Array.isArray(info.participants)) {
            const i = info.participants.indexOf(oldName);
            if (i !== -1) { info.participants[i] = newName; geiChanged = true; }
        }
    }
    if (geiChanged) kvSet("group_expire_info", gei);

    // 同步 group_timers 中的 participants 和 timerStatus key
    const timers = kvGet("group_timers", {});
    let timersChanged = false;
    for (const timer of Object.values(timers)) {
        if (Array.isArray(timer.participants)) {
            const i = timer.participants.indexOf(oldName);
            if (i !== -1) { timer.participants[i] = newName; timersChanged = true; }
        }
        if (timer.timerStatus && timer.timerStatus[oldName]) {
            timer.timerStatus[newName] = timer.timerStatus[oldName];
            delete timer.timerStatus[oldName];
            timersChanged = true;
        }
    }
    if (timersChanged) kvSet("group_timers", timers);

    // 同步 interaction_counts 中的 roleName key 和内层统计 key
    const ic = kvGet("interaction_counts", {});
    let icChanged = false;
    const oldKey = `${platform}:${oldName}`;
    const newKey = `${platform}:${newName}`;
    if (ic[oldKey]) { ic[newKey] = ic[oldKey]; delete ic[oldKey]; icChanged = true; }
    for (const entry of Object.values(ic)) {
        for (const field of Object.keys(entry)) {
            if (entry[field] && typeof entry[field] === "object" && entry[field][oldName] !== undefined) {
                entry[field][newName] = entry[field][oldName];
                delete entry[field][oldName];
                icChanged = true;
            }
        }
    }
    if (icChanged) kvSet("interaction_counts", ic);

    seal.replyToSender(ctx, msg, `✅ 角色名已由「${oldName}」改为「${newName}」。`);
    return seal.ext.newCmdExecuteResult(true);
}

// 2. 玩家名单
let cmd_role_list = {};
cmd_role_list.solve =(ctx, msg) => {
    let storage = getRoleStorage();
    let platform = msg.platform;
    let roles = storage[platform] || {};

    if (Object.keys(roles).length === 0) {
        seal.replyToSender(ctx, msg, `当前平台暂无已绑定的角色`);
        return seal.ext.newCmdExecuteResult(true);
    }

    // 获取 NPC 列表（全局存储）
    let npcList = kvGet("a_npc_list", []);

    let rep = `📊 当前已绑定角色列表：\n`;
    // 新结构：uid为key，roleName在value[0]
    for (let [uid, info] of Object.entries(roles)) {
        const name = info[0];
        let isNPC = npcList.includes(name);
        let npcTag = isNPC ? " 🎭" : "";
        const prof = getCharProfile(platform, name);
        const gender = prof.gender || "女";
        const age = prof.age !== undefined ? prof.age : 18;
        const look = prof.look || (gender === "男" ? "亨利卡维尔" : "刘亦菲");
        const bio = prof.bio ? `\n   签名：${prof.bio}` : "";
        rep += `👤 ${name}${npcTag}\n   ${gender} · ${age}岁 · 皮相：${look}${bio}\n\n`;
    }
    seal.replyToSender(ctx, msg, rep.trim());
    return seal.ext.newCmdExecuteResult(true);
}
// 3. 清除玩家
let cmd_del_role = seal.ext.newCmdItemInfo();
cmd_del_role.name = "清除玩家";
cmd_del_role.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, `该指令仅限骰主使用`);
        return seal.ext.newCmdExecuteResult(true);
    }

    let delName = cmdArgs.getArgN(1);
    if (!delName) {
        seal.replyToSender(ctx, msg, `请输入要移除的角色名`);
        return seal.ext.newCmdExecuteResult(true);
    }

    let storage = getRoleStorage();
    let platform = msg.platform;

    // 新结构：uid为key，按roleName查找
    const targetUidEntry = storage[platform] && Object.entries(storage[platform]).find(([_, v]) => v[0] === delName);
    if (!targetUidEntry) {
        seal.replyToSender(ctx, msg, `未找到角色「${delName}」，请检查输入`);
        return seal.ext.newCmdExecuteResult(true);
    }

    const uid = targetUidEntry[0];
    const uidKey = `${platform}:${uid}`;

    // 1. 绑定记录
    delete storage[platform][uid];
    kvSet("a_private_group", storage);

    // 2. 时间锁定
    const lockedSlots = kvGet("a_lockedSlots", {});
    delete lockedSlots[uidKey];
    kvSet("a_lockedSlots", lockedSlots);

    // 3. 已确认日程 + 释放该玩家占用的群号
    const confirmed = kvGet("b_confirmedSchedule", {});
    const playerSchedules = confirmed[uidKey] || [];
    const groupsToRelease = playerSchedules
        .filter(ev => ev.group && ev.status === "active")
        .map(ev => ev.group);
    if (groupsToRelease.length > 0) {
        let groupList = kvGet("group", []);
        for (const gid of groupsToRelease) {
            const occupiedIdx = groupList.indexOf(gid + "_占用");
            if (occupiedIdx !== -1) {
                groupList.splice(occupiedIdx, 1);
                groupList.push(gid);
            }
        }
        kvSet("group", groupList);
    }
    delete confirmed[uidKey];
    kvSet("b_confirmedSchedule", confirmed);

    // 4. 地点钥匙
    const placeKeys = kvGet("place_keys", {});
    if (placeKeys[platform]) {
        delete placeKeys[platform][uid];
        kvSet("place_keys", placeKeys);
    }

    // 5. 角色档案（性别/皮相/签名/年龄）
    const profiles = kvGet("sys_char_profiles", {});
    delete profiles[uidKey];
    kvSet("sys_char_profiles", profiles);

    // 6. 关系线（删除该玩家的条目，及其他人对该玩家的条目）
    const relData = kvGet("relationship_lines", {});
    if (relData[platform]) {
        delete relData[platform][uid];
        for (const otherUid of Object.keys(relData[platform])) {
            delete relData[platform][otherUid][uid];
        }
        kvSet("relationship_lines", relData);
    }

    // 7. 心动信发送次数记录
    const lovemailCounts = kvGet("lovemail_day_counts", {});
    delete lovemailCounts[uid];
    kvSet("lovemail_day_counts", lovemailCounts);

    // 7.5 交互统计（interaction_counts key 为 platform:roleName）
    const ic = kvGet("interaction_counts", {});
    const icKey = `${platform}:${delName}`;
    let icChanged = false;
    if (ic[icKey]) { delete ic[icKey]; icChanged = true; }
    // 清除其他人记录中对该角色的引用
    for (const entry of Object.values(ic)) {
        for (const field of Object.keys(entry)) {
            if (entry[field] && typeof entry[field] === "object" && entry[field][delName] !== undefined) {
                delete entry[field][delName];
                icChanged = true;
            }
        }
    }
    if (icChanged) kvSet("interaction_counts", ic);

    // 8. RPG数据（背包/属性/抽取记录/二手市场挂单）——全部存在主 ext
    {
        // 背包
        const invs = kvGet("global_inventories", {});
        delete invs[uidKey];
        kvSet("global_inventories", invs);

        // RPG属性
        const charAttrs = kvGet("sys_character_attrs", {});
        delete charAttrs[uid];
        kvSet("sys_character_attrs", charAttrs);

        // 抽取记录
        const drawRecs = kvGet("player_draw_records", {});
        delete drawRecs[uidKey];
        kvSet("player_draw_records", drawRecs);

        // 二手市场：撤销该角色的所有挂单
        const market = kvGet("secondhand_market", {});
        let marketChanged = false;
        for (const code of Object.keys(market)) {
            if (market[code].sellerRole === delName) { delete market[code]; marketChanged = true; }
        }
        if (marketChanged) kvSet("secondhand_market", market);
    }

    seal.replyToSender(ctx, msg, `✅ 已成功清除玩家「${delName}」的全部数据`);
    return seal.ext.newCmdExecuteResult(true);
}
ext.cmdMap["清除玩家"] = cmd_del_role;


// ========================
// ========================
// 🗝️ 地点权限管理系统
// ========================

// --- 核心工具函数 ---
const store = {
    get: (key) => kvGet(key, {}),
    set: (key, val) => kvSet(key, val)
};

// 将辅助账号 uid 解析为主账号 uid（找不到则原样返回）
const getPrimaryUid = (platform, uid) => {
    const extras = store.get("extra_accounts");
    return extras[`${platform}:${uid}`] || uid;
};

// 新结构：a_private_group[platform][uid] = [roleName, gid]
// getRoleName: O(1) 查找（uid为key）
const getRoleName = (ctx, msg) => {
    const platform = msg.platform;
    const rawUid = msg.sender.userId.replace(`${platform}:`, "");
    const uid = getPrimaryUid(platform, rawUid);
    return store.get("a_private_group")[platform]?.[uid]?.[0] || null;
};

// getUserRoleName: O(1) 查找
const getUserRoleName = (platform, fullUid) => {
    const uid = getPrimaryUid(platform, String(fullUid).replace(`${platform}:`, ""));
    return store.get("a_private_group")[platform]?.[uid]?.[0] || null;
};

// 通过 roleName 反查 uid（O(n) 扫描，仅在必要时使用）
const getUidByRoleName = (platform, roleName) => {
    const roles = store.get("a_private_group")[platform] || {};
    return Object.entries(roles).find(([_, v]) => v[0] === roleName)?.[0] || null;
};

// uid → roleName 显示（找不到则返回 uid 本身）
const resolveUidToName = (platform, uid) => {
    return store.get("a_private_group")[platform]?.[uid]?.[0] || uid;
};

// 跨平台查找 uid → roleName
const resolveUidToNameAnyPlatform = (uid) => {
    const apg = store.get("a_private_group");
    for (const platform in apg) {
        if (apg[platform][uid]) return apg[platform][uid][0];
    }
    return uid;
};

// ========================
// 🚫 拉黑系统：单方面屏蔽指定角色对自己发起的短信/礼物/私约/电话/微信/漂流瓶回信联系
// sys_blocklist[platform][blockerUid][blockedUid] = { silent, since, blockerName, blockedName }
// blockerUid/blockedUid 统一用 getPrimaryUid(自己)/getUidByRoleName(对方) 取值，
// 两者对同一人算出来的 uid 相同（getUidByRoleName 本就是在 a_private_group 里按主uid存的），可以互相比对。
// ========================
function getBlockEntry(platform, blockerUid, blockedUid) {
    const bl = kvGet("sys_blocklist", {});
    return bl[platform]?.[blockerUid]?.[blockedUid] || null;
}

// ========================
// 🔌 共享 API：卫星插件统一入口
// ========================
// 所有插件运行在同一个 JS 运行时，经 globalThis 共享。
// 卫星插件（RPG/设置/社交/写信综/晚餐）调用时懒获取 globalThis.__changriApi，
// 不要在卫星文件里复制这些函数的实现。
const changriApi = {
    ext,
    // 存储（带缓存，卫星读写主存储必须走这两对函数；JSON key 用 kvGet/kvSet，裸串用 kvGetRaw/kvSetRaw）
    kvGetRaw: cachedGet,
    kvSetRaw: cachedSet,
    kvGet,
    kvSet,
    getStorageInt,
    // 身份与权限
    getPrimaryUid,
    getRoleName,
    getUserRoleName,
    getUidByRoleName,
    resolveUidToName,
    resolveUidToNameAnyPlatform,
    isUserAdmin,
    isUserFeatureEnabled,
    getBlockEntry,
    // 互动计数与公告
    recordMeetingAndAnnounce,
    recordInteractionStat,
    getTodayActivitySummaryLine,
    // 统计数据读写（统计卫星用）
    getUserStats,
    saveUserStats,
    getRoleStorage,
    getInteractionCounts,
    getTop3Text,
    // 邀约公共校验与建群（心愿等卫星用）
    checkTsFeatureWindow,
    parseAndValidateTime,
    checkRealityHourLimit,
    checkPlaceCommon,
    checkAcceptanceConflicts,
    isLetterSystemEnabled,
    checkAndCostLetterCoin,
    getCharProfile,
    finalizeGroupCreation,
    checkNoQuitBlocker,
    // 消息模板与存档（礼物等卫星用）
    applyMsgTemplate,
    isArchiveEnabled,
    postToArchive,
    // getRoleDetails/sendTextToGroup 是 const 箭头函数（不提升），需包一层延迟取值
    getRoleDetails: (platform, name) => getRoleDetails(platform, name),
    getSafeEndPoint,
    sendTextToGroup: (platform, gid, text) => sendTextToGroup(platform, gid, text),
    // 图片转存/删除/降级与原始 WS 请求（出场等卫星用）
    deleteCollectedImage,
    extractImageSrc,
    degradeStaleImages,
    wsRequest: (postData, onResponse, onTimeout, timeoutMs) => WSM.request(postData, onResponse, onTimeout, timeoutMs),
    // OneBot WS（常驻连接）
    ws,
    wsBatchSync,
    // 季度/时间线/场次卫星所需
    getSeasonShowName,
    hasActiveSeason,
    isRoleStorageEmpty,
    getSessionStats: () => getSessionStats(),
    saveSessionStats: (ss) => saveSessionStats(ss),
    getCustomTypeLabel,
    getScheduleZone,
    updateActiveTimerSettings,
    timeConflict,
    extractRoleContent,
    setGroupName: (ctx, msg, gid, name) => setGroupName(ctx, msg, gid, name),
    getIdleGroupName,
    cleanupGroupTimer,
    addToInv_system: (roleKey, code, count) => addToInv_system(roleKey, code, count),
    // 发错撤回（礼物/拉线卫星记投递用）
    trackSentItem,
    updateTrackedDelivery,
    getMsgRawId,
    getRecallHint: () => RECALL_RECEIPT_HINT,
};
globalThis.__changriApi = changriApi;
try { ext._api = changriApi; } catch (e) { console.log("[长日系统] ext._api 挂载失败（不影响 globalThis 共享）"); }

// ========================
// 数据结构迁移：roleName-key → uid-key
// ========================
function migrateToUidIndex() {
    const apg = store.get("a_private_group");
    let migrated = false;

    for (const platform in apg) {
        const platformData = apg[platform];
        const newPlatformData = {};
        let platformMigrated = false;

        for (const key in platformData) {
            const val = platformData[key];
            // 新结构特征：val[0] 是 roleName（字符串），val[1] 是 gid（纯数字字符串）
            // 旧结构特征：key 是 roleName，val[0] 是 uid（纯数字字符串），val[1] 是 gid
            // 判断依据：uid 通常是纯数字，roleName 通常包含中文或字母
            const looksLikeUid = /^\d+$/.test(key);
            if (!looksLikeUid) {
                // 旧结构：key = roleName, val = [uid, gid]
                const roleName = key;
                const uid = val[0];
                const gid = val[1];
                if (!uid) continue; // 跳过无效记录
                if (!newPlatformData[uid]) {
                    newPlatformData[uid] = [roleName, gid];
                    platformMigrated = true;
                    console.log(`[迁移] ${platform} ${roleName}(${uid}) → uid-key`);
                }
            } else {
                // 新结构：key = uid，直接复制
                newPlatformData[key] = val;
            }
        }

        if (platformMigrated) {
            apg[platform] = newPlatformData;
            migrated = true;
        }
    }

    if (migrated) {
        store.set("a_private_group", apg);
        console.log("[迁移] a_private_group 迁移完成（roleName-key → uid-key）");
    }

    // 迁移 feature_user_blocklist: roleName-key → uid-key
    const fbl = store.get("feature_user_blocklist");
    let fblMigrated = false;
    const newFbl = {};
    for (const k in fbl) {
        // 旧结构：key = platform:roleName；新结构：key = platform:uid
        const colonIdx = k.indexOf(':');
        if (colonIdx === -1) { newFbl[k] = fbl[k]; continue; }
        const plat = k.slice(0, colonIdx);
        const nameOrUid = k.slice(colonIdx + 1);
        const looksLikeUid = /^\d+$/.test(nameOrUid);
        if (!looksLikeUid) {
            // 旧：roleName → 查找 uid
            const uidLookup = getUidByRoleName(plat, nameOrUid);
            if (uidLookup) {
                newFbl[`${plat}:${uidLookup}`] = fbl[k];
                fblMigrated = true;
            } else {
                newFbl[k] = fbl[k]; // 无法迁移，保留
            }
        } else {
            newFbl[k] = fbl[k];
        }
    }
    if (fblMigrated) {
        store.set("feature_user_blocklist", newFbl);
        console.log("[迁移] feature_user_blocklist 迁移完成");
    }

    // 迁移 place_keys: roleName-key → uid-key（per platform）
    const placeKeys = store.get("place_keys");
    let pkMigrated = false;
    for (const plat in placeKeys) {
        const platData = placeKeys[plat];
        const newPlatData = {};
        let changed = false;
        for (const nameOrUid in platData) {
            const looksLikeUid = /^\d+$/.test(nameOrUid);
            if (!looksLikeUid) {
                const uidLookup = getUidByRoleName(plat, nameOrUid);
                if (uidLookup) {
                    newPlatData[uidLookup] = platData[nameOrUid];
                    changed = true;
                } else {
                    newPlatData[nameOrUid] = platData[nameOrUid];
                }
            } else {
                newPlatData[nameOrUid] = platData[nameOrUid];
            }
        }
        if (changed) {
            placeKeys[plat] = newPlatData;
            pkMigrated = true;
        }
    }
    if (pkMigrated) {
        store.set("place_keys", placeKeys);
        console.log("[迁移] place_keys 迁移完成");
    }
}

// 在扩展加载时执行迁移
try {
    migrateToUidIndex();
} catch (e) {
    console.error("[迁移] migrateToUidIndex 执行失败:", e);
}

// ========================
// 角色档案系统
// ========================
function getCharProfile(platform, roleName) {
    // 新结构：通过 roleName 反查 uid
    const uid = getUidByRoleName(platform, roleName);
    if (!uid) return {};
    return store.get("sys_char_profiles")[`${platform}:${uid}`] || {};
}

function setCharProfile(platform, roleName, patch) {
    const uid = getUidByRoleName(platform, roleName);
    if (!uid) return;
    const profiles = store.get("sys_char_profiles");
    const key = `${platform}:${uid}`;
    profiles[key] = Object.assign(profiles[key] || {}, patch);
    store.set("sys_char_profiles", profiles);
}

function initCharProfile(platform, roleName, gender) {
    const genderVal = gender || "女";
    const defaultLook = genderVal === "男" ? "亨利卡维尔" : "刘亦菲";
    const existing = getCharProfile(platform, roleName);
    setCharProfile(platform, roleName, {
        gender: existing.gender || genderVal,
        age: existing.age !== undefined ? existing.age : 18,
        look: existing.look || defaultLook,
        bio: existing.bio || "",
        bioUpdatedAt: existing.bioUpdatedAt || 0,
        lookUpdatedAt: existing.lookUpdatedAt || 0
    });
}

// --- 逻辑判断逻辑 ---
function checkPlacePermission(platform, roleName, placeName) {
    const config = store.get("place_system_config");
    if (!config.enabled || config.enabled === undefined) return { allowed: true };

    const places = store.get("available_places");
    const place = places[placeName];

    // 处理私人房间
    if (!place) {
        const owner = placeName.match(/^(.+?)的房间$/)?.[1];
        if (!owner) return { allowed: false, reason: "地点不存在" };
        const ownerUid = getUidByRoleName(platform, owner);
        return { allowed: !!ownerUid, reason: "地点不存在或私人房间未激活" };
    }

    if (!place.locked) return { allowed: true };
    // 新结构：place_keys[platform][uid]
    const uid = getUidByRoleName(platform, roleName);
    const hasKey = uid && (store.get("place_keys")[platform]?.[uid] || []).includes(placeName);
    return { allowed: !!hasKey, reason: "需要钥匙" };
}

/**
 * 统一的地点检查函数（优化版）
 * @param {string} platform 平台
 * @param {string} senderName 发送者角色名
 * @param {string} place 地点
 * @param {string} instructionName 指令名称
 */
function checkPlaceCommon(platform, senderName, place, instructionName = "发起邀约") {
  // 获取配置，增加默认值兜底
  const placeSystemConfig = kvGet("place_system_config", {"enabled": false});
  const availablePlaces = kvGet("available_places", {});
  
  // --- 情况 A: 地点系统已【启用】 (严格检查模式) ---
  if (placeSystemConfig.enabled) {

    // 新增：检查私人房间是否被禁用
    const allowPrivateRooms = kvGet("allow_private_rooms", true);
    const isPrivateRoom = place.match(/^(.+?)的房间$/);
    if (!allowPrivateRooms && isPrivateRoom) {
      return { 
        valid: false, 
        errorMsg: `⚠️ 私人房间功能已关闭，不能使用「${place}」格式的地点。\n` 
      };
    }
    // 调用你原有的权限检查函数
    const permission = checkPlacePermission(platform, senderName, place);
    
    if (!permission.allowed) {
      // 获取该用户的钥匙，按权限分类显示地点
      const senderUid = getUidByRoleName(platform, senderName);
      const userKeys = senderUid ? (kvGet("place_keys", {})[platform]?.[senderUid] || []) : [];

      let errorMsg = `⚠️ 地点「${place}」不可用：${permission.reason}\n`;

      if (Object.keys(availablePlaces).length > 0) {
        const accessible = [], locked = [];
        Object.entries(availablePlaces).forEach(([placeName, data]) => {
          const desc = data.desc ? `（${data.desc}）` : '';
          if (!data.locked) {
            accessible.push(`📍 ${placeName}${desc}`);
          } else if (userKeys.includes(placeName)) {
            accessible.push(`🔑 ${placeName}${desc}`);
          } else {
            locked.push(`🔒 ${placeName}${desc}`);
          }
        });
        if (accessible.length) {
          errorMsg += "\n✅ 你可以进入：\n" + accessible.map(s => `  ${s}`).join("\n") + "\n";
        }
        if (locked.length) {
          errorMsg += "\n🔒 需要钥匙：\n" + locked.map(s => `  ${s}`).join("\n") + "\n";
        }
      }

      errorMsg += "\n💡 ";
      if (allowPrivateRooms) errorMsg += "也可用「[角色名]的房间」格式；";
      errorMsg += "「地点 查看」查看完整列表";

      return { valid: false, errorMsg: errorMsg };
    }
  } 
  
  // --- 情况 B: 地点系统已【禁用】 (宽松检查模式，直接通过) ---
  // 地点系统未启用时不做任何地点校验，也不显示地点列表
  
  // 默认通过
  return { valid: true, errorMsg: "", warningMsg: "" };
}

// --- 玩家指令 ---
let cmdPlace = seal.ext.newCmdItemInfo();
cmdPlace.name = "地点";
cmdPlace.help = "。地点 查看 // 。地点 钥匙";
cmdPlace.solve = (ctx, msg, cmdArgs) => {
    const role = getRoleName(ctx, msg);
    const platform = msg.platform;
    const sub = cmdArgs.getArgN(1);
    const places = store.get("available_places");
    // 新结构：place_keys[platform][uid]
    const roleUid = role ? getUidByRoleName(platform, role) : null;
    const userKeys = roleUid ? (store.get("place_keys")[platform]?.[roleUid] || []) : [];

    if (sub === "查看") {
        const placeConfig = kvGet("place_system_config", {"enabled": false});
        const allowPrivateRooms = kvGet("allow_private_rooms", true);
        const placeList = Object.entries(places);

        let rep = "🏢 地点列表\n";
        if (placeConfig.enabled) {
            if (placeList.length === 0) {
                rep += "（暂无公共地点）\n";
            } else {
                placeList.forEach(([name, data]) => {
                    let tag;
                    if (!data.locked) {
                        tag = "📍";
                    } else if (userKeys.includes(name)) {
                        tag = "🔑 已解锁";
                    } else {
                        tag = "🔒 需要钥匙";
                    }
                    rep += `${tag} ${name}${data.desc ? `（${data.desc}）` : ""}\n`;
                });
            }
            rep += `\n🏠 私人房间：${allowPrivateRooms ? "✅ 可用" : "❌ 已关闭"}`;
            if (allowPrivateRooms) rep += "\n💡 使用「[角色名]的房间」格式";
        } else {
            if (placeList.length === 0) {
                rep += "（暂无地点）\n";
            } else {
                placeList.forEach(([name, data]) => {
                    rep += `📍 ${name}${data.desc ? `（${data.desc}）` : ""}\n`;
                });
            }
            if (allowPrivateRooms) rep += "\n💡 也可使用「[角色名]的房间」格式的私人地点";
        }
        return seal.replyToSender(ctx, msg, rep);
    }

    if (sub === "钥匙") {
        if (!role) return seal.replyToSender(ctx, msg, "❌ 未绑定角色，无法查看钥匙");
        if (!userKeys.length) return seal.replyToSender(ctx, msg, "🔐 你目前没有任何地点钥匙");
        let rep = "🔑 你持有的钥匙：\n";
        userKeys.forEach(k => {
            const exists = places[k];
            if (!exists) {
                rep += `  ⚠️ ${k}（地点已被删除）\n`;
            } else {
                rep += `  🔑 ${k}${exists.desc ? `（${exists.desc}）` : ""}${exists.locked ? "" : "（当前未上锁）"}\n`;
            }
        });
        return seal.replyToSender(ctx, msg, rep);
    }
};
ext.cmdMap["地点"] = cmdPlace;

// ========================
// 🛠️ 地点管理系统 - 核心指令集
// ========================

// 1. 基础管理指令：。地点管理 [添加/删除/开关/钥匙/清空]
let cmdPlaceAdm = seal.ext.newCmdItemInfo();
cmdPlaceAdm.name = "地点管理";
cmdPlaceAdm.help = "。地点管理 添加 地点:描述 / 删除 地点 / 开关 地点 / 钥匙 角色名 地点 / 清空";
cmdPlaceAdm.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
        return seal.ext.newCmdExecuteResult(true);
    }
    
    const op = cmdArgs.getArgN(1);
    let places = kvGet("available_places", {});
    let keys = kvGet("place_keys", {});
    const pf = msg.platform;

    switch(op) {
        case "添加": {
            const arg = cmdArgs.getArgN(2);
            if (!arg) return seal.replyToSender(ctx, msg, "用法：.地点管理 添加 地点名:描述\n示例：.地点管理 添加 庭院:阳光充足的小院");
            const [rawName, desc] = arg.split(/[:：]/);
            const name = (rawName || "").trim();
            if (!name) return seal.replyToSender(ctx, msg, "❌ 地点名不能为空");
            if (places[name]) return seal.replyToSender(ctx, msg, `⚠️ 地点「${name}」已存在，如需修改描述请先删除再重新添加`);
            const trimDesc = (desc || "").trim();
            places[name] = { desc: trimDesc, locked: false, creator: "管理员", created_at: new Date().toLocaleString() };
            seal.replyToSender(ctx, msg, `✅ 已添加地点：${name}${trimDesc ? `\n📝 描述：${trimDesc}` : ""}`);
            break;
        }
        case "删除": {
            const name = cmdArgs.getArgN(2);
            if (!name) { seal.replyToSender(ctx, msg, "用法：.地点管理 删除 地点名"); break; }
            if (!places[name]) {
                const available = Object.keys(places);
                const hint = available.length ? `\n现有地点：${available.join("、")}` : "\n（当前无地点）";
                seal.replyToSender(ctx, msg, `❌ 地点「${name}」不存在${hint}`);
                break;
            }
            delete places[name];
            // 同步清理所有平台中该地点的钥匙记录
            let cleanedCount = 0;
            for (const plat in keys) {
                for (const uid in keys[plat]) {
                    const idx = keys[plat][uid].indexOf(name);
                    if (idx !== -1) { keys[plat][uid].splice(idx, 1); cleanedCount++; }
                }
            }
            const cleanMsg = cleanedCount > 0 ? `\n🔑 已同步清理 ${cleanedCount} 个角色的相关钥匙` : "";
            seal.replyToSender(ctx, msg, `🗑️ 已删除地点：${name}${cleanMsg}`);
            break;
        }
        case "开关": {
            const name = cmdArgs.getArgN(2);
            if (!name) { seal.replyToSender(ctx, msg, "用法：.地点管理 开关 地点名"); break; }
            if (!places[name]) {
                const available = Object.keys(places);
                const hint = available.length ? `\n现有地点：${available.join("、")}` : "\n（当前无地点）";
                seal.replyToSender(ctx, msg, `❌ 地点「${name}」不存在${hint}`);
                break;
            }
            places[name].locked = !places[name].locked;
            const newState = places[name].locked ? "🔒 已上锁" : "🔓 已解锁";
            const lockHint = places[name].locked ? "\n持有钥匙的角色仍可进入" : "";
            seal.replyToSender(ctx, msg, `${newState}：${name}${lockHint}`);
            break;
        }
        case "钥匙": {
            const role = cmdArgs.getArgN(2);
            const pName = cmdArgs.getArgN(3);
            if (!role || !pName) return seal.replyToSender(ctx, msg, "用法：.地点管理 钥匙 角色名 地点名\n示例：.地点管理 钥匙 张三 图书馆");
            if (!places[pName]) {
                const available = Object.keys(places);
                const hint = available.length ? `\n现有地点：${available.join("、")}` : "\n（当前无地点）";
                return seal.replyToSender(ctx, msg, `❌ 地点「${pName}」不存在${hint}`);
            }
            // 新结构：place_keys[platform][uid]
            const targetUid = getUidByRoleName(pf, role);
            if (!targetUid) { seal.replyToSender(ctx, msg, `❌ 找不到角色「${role}」，请确认角色名是否正确`); break; }
            if (!keys[pf]) keys[pf] = {};
            if (!keys[pf][targetUid]) keys[pf][targetUid] = [];

            const idx = keys[pf][targetUid].indexOf(pName);
            if (idx === -1) {
                keys[pf][targetUid].push(pName);
                const unlockedHint = !places[pName].locked ? "\n（提示：该地点当前未上锁，钥匙暂不生效）" : "";
                seal.replyToSender(ctx, msg, `🔑 已发放「${pName}」钥匙给「${role}」${unlockedHint}`);
            } else {
                keys[pf][targetUid].splice(idx, 1);
                seal.replyToSender(ctx, msg, `🚫 已收回「${role}」的「${pName}」钥匙`);
            }
            break;
        }
        case "清空": {
            if (cmdArgs.getArgN(2) !== "Y") return seal.replyToSender(ctx, msg, "⚠️ 确认清空请使用：.地点管理 清空 Y");
            places = {}; keys = {};
            seal.replyToSender(ctx, msg, "🧹 地点系统已彻底初始化");
            break;
        }
        case "私人房间": {
          const subCmd = cmdArgs.getArgN(2);
          if (subCmd === "on" || subCmd === "开" || subCmd === "开启") {
            cachedSet("allow_private_rooms", "true");
            seal.replyToSender(ctx, msg, "✅ 私人房间功能已开启\n玩家可以使用「[角色名]的房间」格式进行私约");
          } else if (subCmd === "off" || subCmd === "关" || subCmd === "关闭") {
            cachedSet("allow_private_rooms", "false");
            seal.replyToSender(ctx, msg, "❌ 私人房间功能已关闭\n玩家不能再使用「[角色名]的房间」格式");
          } else {
            const cur = kvGet("allow_private_rooms", true);
            seal.replyToSender(ctx, msg, `🏠 私人房间当前状态：${cur ? "✅ 开启" : "❌ 关闭"}\n切换：.地点管理 私人房间 on/off`);
          }
          break;
        }
        default: {
            const allowPrivate = kvGet("allow_private_rooms", true);
            const helpMsg = [
                "📚 地点管理帮助",
                "",
                "【添加】.地点管理 添加 地点名:描述",
                "  例：.地点管理 添加 庭院:阳光充足的小院",
                "  描述可留空，支持中英文冒号",
                "",
                "【删除】.地点管理 删除 地点名",
                "  会自动清理该地点的所有钥匙记录",
                "",
                "【开关】.地点管理 开关 地点名",
                "  切换上锁/解锁状态，上锁后无钥匙者无法进入",
                "",
                "【钥匙】.地点管理 钥匙 角色名 地点名",
                "  再次执行同一命令可收回钥匙（切换式）",
                "",
                "【清空】.地点管理 清空 Y",
                "  ⚠️ 永久删除所有地点和钥匙数据，需加 Y 确认",
                "",
                `【私人房间】.地点管理 私人房间 on/off`,
                `  当前状态：${allowPrivate ? "✅ 开启" : "❌ 关闭"}`,
                "  开启后玩家可用「[角色名]的房间」格式",
                "",
                "💡 地点名、角色名均区分大小写"
            ].join("\n");
            seal.replyToSender(ctx, msg, helpMsg);
            break;
        }
    }
    kvSet("available_places", places);
    kvSet("place_keys", keys);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["地点管理"] = cmdPlaceAdm;

// 2. 批量设置地点
let cmdBatchPlace = seal.ext.newCmdItemInfo();
cmdBatchPlace.name = "批量设置地点";
cmdBatchPlace.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
        return seal.ext.newCmdExecuteResult(true);
    }
    const arg = cmdArgs.getArgN(1);
    if (!arg) return seal.replyToSender(ctx, msg, "格式：.批量设置地点 地点1:描述/地点2:描述\n示例：.批量设置地点 图书馆:安静的阅读空间/咖啡厅:温馨小店");

    let places = kvGet("available_places", {});
    const items = arg.split("/");
    const added = [], skipped = [];
    items.forEach(item => {
        const [rawName, desc] = item.split(/[:：]/); // 支持中英文冒号
        const name = (rawName || "").trim();
        if (!name) { skipped.push("（空名称）"); return; }
        places[name] = { desc: (desc || "").trim(), locked: false, creator: "管理员", created_at: new Date().toLocaleString() };
        added.push(name);
    });
    kvSet("available_places", places);
    let rep = `✅ 成功添加 ${added.length} 个地点：${added.join("、")}`;
    if (skipped.length) rep += `\n⚠️ 跳过 ${skipped.length} 个无效条目`;
    seal.replyToSender(ctx, msg, rep);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["批量设置地点"] = cmdBatchPlace;

// 3. 批量发放钥匙
let cmdBatchKey = seal.ext.newCmdItemInfo();
cmdBatchKey.name = "批量发放钥匙";
cmdBatchKey.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
        return seal.ext.newCmdExecuteResult(true);
    }
    const roles = (cmdArgs.getArgN(1) || "").split("/");
    const pNames = (cmdArgs.getArgN(2) || "").split("/");
    let keys = kvGet("place_keys", {});
    const pf = msg.platform;
    if (!keys[pf]) keys[pf] = {};

    const found = [], notFound = [];
    roles.forEach(r => {
        const rName = r.trim();
        if (!rName) return;
        // 新结构：place_keys[platform][uid]
        const rUid = getUidByRoleName(pf, rName);
        if (!rUid) { notFound.push(rName); return; }
        if (!keys[pf][rUid]) keys[pf][rUid] = [];
        pNames.forEach(p => {
            const pTrimmed = p.trim();
            if (pTrimmed && !keys[pf][rUid].includes(pTrimmed)) keys[pf][rUid].push(pTrimmed);
        });
        found.push(rName);
    });
    kvSet("place_keys", keys);
    let rep = `✅ 已授权 ${found.length} 个角色：${found.join("、") || "无"}`;
    if (notFound.length) rep += `\n⚠️ 未找到以下角色：${notFound.join("、")}\n（请检查角色名是否正确）`;
    seal.replyToSender(ctx, msg, rep);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["批量发放钥匙"] = cmdBatchKey;

// 4. 查看详情与统计 (合二为一)
let cmdViewPlace = seal.ext.newCmdItemInfo();
cmdViewPlace.name = "查看地点详情";
cmdViewPlace.solve = (ctx, msg) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
        return seal.ext.newCmdExecuteResult(true);
    }
    const places = kvGet("available_places", {});
    const keys = kvGet("place_keys", {})[msg.platform] || {};
    
    const placeConfig = kvGet("place_system_config", {"enabled": false});
    const allowPrivate = kvGet("allow_private_rooms", true);
    const placeCount = Object.keys(places).length;
    let rep = "🏢 地点系统详细报告\n";
    rep += "━━━━━━━━━━━━\n";
    rep += `系统状态：${placeConfig.enabled ? "✅ 已启用" : "⭕ 未启用"}\n`;
    rep += `私人房间：${allowPrivate ? "✅ 开启" : "❌ 关闭"}\n`;
    rep += `地点总数：${placeCount} 个\n`;
    rep += "━━━━━━━━━━━━\n";
    if (placeCount === 0) {
        rep += "（暂无地点）";
    } else {
        Object.entries(places).forEach(([name, data]) => {
            // 新结构：keys的key是uid，显示时转为roleName
            const holders = Object.entries(keys).filter(([_, kList]) => kList.includes(name)).map(([uid]) => resolveUidToName(msg.platform, uid));
            rep += `${data.locked ? "🔒" : "🔓"} ${name}\n`;
            if (data.desc) rep += `   📝 ${data.desc}\n`;
            rep += `   🔑 持钥匙者：${holders.join("、") || "无"}\n`;
        });
    }
    seal.replyToSender(ctx, msg, rep);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["查看地点详情"] = cmdViewPlace;
ext.cmdMap["查看钥匙分配"] = cmdViewPlace; // 共用逻辑

// ========================
// 💕 约会与邀约系统
// ========================
function checkTsFeatureWindow(featureKey) {
    const windows = kvGet("ts_feature_windows", []);
    const entry = windows.find(w => w.feature === featureKey);
    if (!entry) return { ok: true };
    const h = new Date().getHours();
    if (h >= entry.start && h < entry.end) return { ok: true };
    const s = String(entry.start).padStart(2, "0");
    const e = String(entry.end).padStart(2, "0");
    return { ok: false, msg: `⚠️ 该功能当前不可用，开放时间为 ${s}:00–${e}:00。` };
}

function checkRealityHourLimit(timeStr, ctx, msg) {
    const slotSizeRaw = cachedGet("ts_reality_slot_size");
    const slotSize = slotSizeRaw ? JSON.parse(slotSizeRaw) : 0;
    if (!slotSize) {
        // 兜底：兼容旧版 strict_hour_match 开关
        const enableStorage = cachedGet("ts_strict_hour_match");
        const enable = enableStorage ? JSON.parse(enableStorage) : seal.ext.getBoolConfig(ext, "开启现实时段校验");
        if (!enable) return true;
    } else if (slotSize <= 0) {
        return true;
    }

    const now = new Date();
    const currentHour = now.getHours();
    const currentTimeStr = `${String(currentHour).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;

    let startHour = null;
    const match = timeStr.match(/(\d{2}):\d{2}-/);
    if (match) startHour = parseInt(match[1], 10);

    if (startHour === null) {
        seal.replyToSender(ctx, msg, "⚠️ 时间格式错误，无法进行时段检查");
        return false;
    }

    const sz = slotSize || 1;
    const currentSlot = Math.floor(currentHour / sz);
    const startSlot   = Math.floor(startHour   / sz);

    const slotModeRaw = cachedGet("ts_slot_mode") || '';
    const exactMode = slotModeRaw.replace(/^"|"$/g, '') === 'exact';

    const slotMismatch = exactMode ? (startSlot !== currentSlot) : (startSlot > currentSlot);
    if (slotMismatch) {
        const slotStart = currentSlot * sz;
        const slotEnd   = Math.min(slotStart + sz, 24);
        if (exactMode) {
            seal.replyToSender(ctx, msg,
                `⚠️ 时段限制：当前现实时间为 ${currentTimeStr}，本时段（现实 ${String(slotStart).padStart(2,'0')}:00–${String(slotEnd - 1).padStart(2,'0')}:59）` +
                `只能发起戏内 ${String(slotStart).padStart(2,'0')}:xx–${String(slotEnd - 1).padStart(2,'0')}:xx 开始的剧情邀约。\n\n` +
                `💡 如需取消此限制，请联系管理调整「现实/戏内时间对照档位」。`);
        } else {
            seal.replyToSender(ctx, msg,
                `⚠️ 时段限制：当前现实时间为 ${currentTimeStr}，` +
                `只能发起戏内 00:00–${String(slotEnd).padStart(2,'0')}:00 以前开始的剧情邀约。\n\n` +
                `💡 如需取消此限制，请联系管理调整「现实/戏内时间对照档位」。`);
        }
        return false;
    }
    return true;
}

// ========================
// 🔧 公共辅助函数（电话/私约共用）
// ========================

function parseAndValidateTime(rawTime, allowedRanges, minDuration, subtype) {
    let time = "";
    if (/^\d{4}-\d{4}$/.test(rawTime)) {
        const start = rawTime.slice(0, 2) + ":" + rawTime.slice(2, 4);
        const end = rawTime.slice(5, 7) + ":" + rawTime.slice(7, 9);
        time = `${start}-${end}`;
    } else if (/^(\d{2}):(\d{2})-(\d{2}):(\d{2})$/.test(rawTime)) {
        time = rawTime;
    } else {
        return { valid: false, errorMsg: `⚠️ 时间参数格式错误：「${rawTime}」\n请输入标准格式，如：\n· 1100-1200\n· 11:20-12:30` };
    }

    if (allowedRanges.length > 0) {
        const [userStart, userEnd] = time.split('-');
        const ok = allowedRanges.some(range => {
            const [rangeStart, rangeEnd] = range.split('-');
            return userStart >= rangeStart && userEnd <= rangeEnd;
        });
        if (!ok) {
            const rangesText = allowedRanges.map(r => `· ${r}`).join('\n');
            return { valid: false, errorMsg: `⚠️ 时间 ${time} 不在允许的范围内\n\n📋 当前允许的时间段：\n${rangesText}\n\n请选择上述时间段内的预约时间~` };
        }
    }

    if (!isValidTimeFormat(time)) {
        return { valid: false, errorMsg: "请输入正确的时间格式，时间段需合法" };
    }

    const match = time.match(/(\d{2}):(\d{2})-(\d{2}):(\d{2})/);
    if (match) {
        const startMinutes = parseInt(match[1]) * 60 + parseInt(match[2]);
        const endMinutes = parseInt(match[3]) * 60 + parseInt(match[4]);
        const duration = endMinutes - startMinutes;
        if (duration < minDuration) {
            return { valid: false, errorMsg: `⚠️ ${getCustomTypeLabel(subtype)}邀约时间需大于等于 ${minDuration}分钟，请重新设置（如 ${minDuration === 29 ? "1400-1430" : "14:00-15:00"}）` };
        }
    }

    return { valid: true, time };
}

function checkLockedSlots(platform, day, time, fromKey, sendname, names, a_private_group, a_lockedSlots) {
    let failed = [];
    for (let toname of names) {
        // 新结构：通过 roleName 反查 uid
        const toUidLookup = Object.entries(a_private_group[platform] || {}).find(([_, v]) => v[0] === toname)?.[0];
        if (!toUidLookup) {
            failed.push(`${toname}（未注册）`);
            continue;
        }
        const toKey = `${platform}:${toUidLookup}`;
        const toLocked = a_lockedSlots[toKey]?.[day] || [];
        if (toLocked.some(lockedTime => timeOverlap(time, lockedTime))) {
            failed.push(`${toname}（该时段被锁定）`);
            continue;
        }
        if (toname === sendname) {
            failed.push(`${toname}（不能邀请自己）`);
        }
    }
    const fromLocked = a_lockedSlots[fromKey]?.[day] || [];
    const selfLocked = fromLocked.some(lockedTime => timeOverlap(time, lockedTime));
    return { selfLocked, failed };
}

// 修改点：去除了 pending 队列的检查，只查 b_confirmedSchedule 的硬冲突
function checkParticipantConflicts(platform, day, time, sendname, names, a_private_group, b_confirmedSchedule) {
    let failedNames = [];           
    let existingAppointments = [];  

    for (let toname of names) {
        // 新结构：通过 roleName 反查 uid
        const toUidLookup2 = Object.entries(a_private_group[platform] || {}).find(([_, v]) => v[0] === toname)?.[0];
        if (!toUidLookup2) continue;
        const toKey = `${platform}:${toUidLookup2}`;
        
        let hasConflict = false;
        let conflictSchedule = null;
        if (b_confirmedSchedule[toKey]) {
            for (let ev of b_confirmedSchedule[toKey]) {
                if (timeConflict(day, time, ev.day, ev.time)) {
                    hasConflict = true;
                    conflictSchedule = ev;   
                    break;
                }
            }
        }
        
        if (hasConflict) {
            existingAppointments.push({
                name: toname,
                schedule: conflictSchedule,
                groupId: conflictSchedule.group,      
                day: conflictSchedule.day,
                time: conflictSchedule.time,
                place: conflictSchedule.place
            });
            continue; 
        }
    }
    
    return { stop: false, failedNames, existingAppointments };
}

function getExampleTimeRange() {
    const now = new Date();
    let startHour = now.getHours();
    const formatHour = (h) => String(h).padStart(2, '0');
    
    if (startHour === 23) {
        return "2300-2359";  
    }
    return `${formatHour(startHour)}00-${formatHour(startHour + 1)}00`;
}

function mergeIntoExistingAppointment(ctx, msg, existingAppointment, newNames, preData) {
    const { platform, sendname, day, time, place, a_private_group, fromKey } = preData;
    const groupId = existingAppointment.group;
    
    let groupExpireInfo = kvGet("group_expire_info", {});
    let existingParticipants = groupExpireInfo[groupId]?.participants || [];
    
    if (existingParticipants.length === 0) {
        const b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
        const participantsSet = new Set();
        for (const [key, schedules] of Object.entries(b_confirmedSchedule)) {
            for (const ev of schedules) {
                if (ev.group === groupId && ev.day === day && ev.time === time) {
                    const partners = ev.partner.split(/[、,]/).map(s => s.trim());
                    partners.forEach(p => participantsSet.add(p));
                }
            }
        }
        existingParticipants = Array.from(participantsSet);
    }
    
    const allParticipants = [...new Set([...existingParticipants, ...newNames])];
    
    if (groupExpireInfo[groupId]) {
        groupExpireInfo[groupId].participants = allParticipants;
    } else {
        groupExpireInfo[groupId] = {
            acceptTime: Date.now(),
            expireTime: Date.now() + (getStorageInt("group_expire_hours", 48) * 3600000),
            participants: allParticipants,
            subtype: "私密",
            day: day,
            time: time,
            place: place
        };
    }
    kvSet("group_expire_info", groupExpireInfo);
    
    let b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
    
    for (const [key, schedules] of Object.entries(b_confirmedSchedule)) {
        for (let ev of schedules) {
            if (ev.group === groupId && ev.day === day && ev.time === time) {
                if (allParticipants.length > 2) {
                    ev.partner = "多人小群";
                } else {
                    const currentPartners = ev.partner.split(/[、,]/).map(s => s.trim());
                    const newPartners = [...new Set([...currentPartners, ...newNames])];
                    ev.partner = newPartners.join("、");
                }
            }
        }
    }
    
    for (let newName of newNames) {
        // 新结构：通过 roleName 反查 uid
        const newNameUid = getUidByRoleName(platform, newName);
        const targetInfo = newNameUid ? a_private_group[platform][newNameUid] : null;
        if (!targetInfo) continue;
        const targetUid = newNameUid;
        const targetKey = `${platform}:${targetUid}`;
        if (!b_confirmedSchedule[targetKey]) b_confirmedSchedule[targetKey] = [];
        
        const alreadyExists = b_confirmedSchedule[targetKey].some(ev => 
            ev.group === groupId && ev.day === day && ev.time === time
        );
        if (!alreadyExists) {
            b_confirmedSchedule[targetKey].push({
                day: day,
                time: time,
                partner: allParticipants.length > 2 ? "多人小群" : allParticipants.find(n => n !== newName) || allParticipants.join("、"),
                subtype: "私密",
                place: place,
                group: groupId,
                status: "active"
            });
        }
    }
    kvSet("b_confirmedSchedule", b_confirmedSchedule);
    
    let groupTimers = kvGet("group_timers", {});
    let timer = groupTimers[groupId];
    
    if (timer) {
        const now = Date.now();
        const isTwoPerson = timer.participants.length === 2;
        
        if (timer.timerMode === "turn_taking" && isTwoPerson) {
            timer.timerMode = "independent";
            for (let [role, status] of Object.entries(timer.timerStatus)) {
                if (status.status === "waiting") {
                    status.status = "timing";
                    status.startTime = now;
                    status.repliedTime = null;
                    status.wordCount = 0;
                    status.remindedTimes = 0;
                }
            }
        }
        
        for (let newName of newNames) {
            if (!timer.timerStatus[newName]) {
                timer.timerStatus[newName] = {
                    status: "timing",
                    startTime: now,
                    repliedTime: null,
                    wordCount: 0,
                    remindedTimes: 0,
                    isInitiator: false
                };
            }
        }
        
        timer.participants = allParticipants;
        groupTimers[groupId] = timer;
        kvSet("group_timers", groupTimers);
    }
    
    // 更新群名
    const nameTag = allParticipants.length > 2 ? "多人" : allParticipants.join("、");
    const newGroupName = `${getCustomTypeLabel("私密")} ${day} ${time} ${place} ${nameTag}`;
    const renameMsg = seal.newMessage();
    renameMsg.messageType = "group";
    renameMsg.groupId = `${platform}-Group:${groupId}`;
    const renameCtx = seal.createTempCtx(ctx.endPoint, renameMsg);
    setGroupName(renameCtx, renameMsg, groupId, newGroupName);

    const groupMsg = seal.newMessage();
    groupMsg.messageType = "group";
    groupMsg.groupId = `${platform}-Group:${groupId}`;
    const groupCtx = seal.createTempCtx(ctx.endPoint, groupMsg);
    const joinNotice = `🎉 欢迎新伙伴加入！\n\n${newNames.join("、")} 也选择了在 ${day} ${time} 前往【${place}】。\n现在你们可以一起进行这场约会啦！\n\n当前参与者：${allParticipants.join("、")}`;
    seal.replyToSender(groupCtx, groupMsg, joinNotice);

    // 通知新成员（跳过发起者 sendname，发起者由私约指令的 successMsg 告知）
    for (let newName of newNames) {
        if (newName === sendname) continue;
        const newNameUid2 = getUidByRoleName(platform, newName);
        const targetInfo = newNameUid2 ? a_private_group[platform][newNameUid2] : null;
        if (targetInfo) {
            const targetGroupId = targetInfo[1];
            const privateMsg = seal.newMessage();
            privateMsg.messageType = "group";
            privateMsg.groupId = `${platform}-Group:${targetGroupId}`;
            const privateCtx = seal.createTempCtx(ctx.endPoint, privateMsg);
            const notice = `✨ ${sendname} 发起的私约已自动合并到现有约会中！\n\n📅 时间：${day} ${time}\n📍 地点：${place}\n👥 参与者：${allParticipants.join("、")}\n💬 群号：${groupId}\n\n请自行申请入群，享受约会时光~`;
            seal.replyToSender(privateCtx, privateMsg, notice);
        }
    }

    return true;
}

async function checkAppointmentPreflight(ctx, msg, cmdArgs, subtype, minDurationKey, minDurationOverride) {
    let config = kvGet("global_feature_toggle", {});
    let enable_general_appointment = config.enable_general_appointment ?? true;
    if (!enable_general_appointment) {
        return { valid: false, errorMsg: "📅 当前已禁用通用发起邀约功能，无法发起" + getCustomTypeLabel(subtype === "电话" ? "电话" : "私密") + "邀约。" };
    }

    const platform = msg.platform;
    const uid = msg.sender.userId.replace(`${platform}:`, "");
    const a_private_group = kvGet("a_private_group", {});
    if (!a_private_group[platform]) a_private_group[platform] = {};

    const sendname = getRoleName(ctx, msg);
    if (!sendname) return { valid: false, errorMsg: "请先使用「创建新角色」绑定角色" };

    // 新结构：blockMap[uid]
    const sendUid = getPrimaryUid(platform, uid);
    if (!isUserFeatureEnabled(sendUid, "enable_general_appointment")) {
        return { valid: false, errorMsg: "🚫 您已被禁止使用发起邀约功能" };
    }

    const globalDay = cachedGet("global_days");
    if (!globalDay) return { valid: false, errorMsg: "⚠️ 当前尚未设置全局天数，请先使用 \".设置天数 D1\"" };
    const day = globalDay;

    const rawTime = cmdArgs.getArgN(1);
    const namesArg = subtype === "电话" ? cmdArgs.getArgN(2) : cmdArgs.getArgN(3);
    const placeOrTitle = subtype === "电话" ? cmdArgs.getArgN(3) : cmdArgs.getArgN(2); 
    if (!rawTime || !namesArg) {
        const exampleTime = getExampleTimeRange();
        let helpMsg = "";
        if (subtype === "电话") {
            helpMsg = `⚠️ 参数不足，正确格式：\n电话 ${exampleTime} 邀请人1[/邀请人2/...] [标题]\n示例：\n电话 ${exampleTime} 张三\n电话 ${exampleTime} 李四/王五 一起聊聊`;
        } else {
            const cmdName = subtype === "私密" ? "私约" : subtype;
            helpMsg = `⚠️ 参数不足，正确格式：\n${cmdName} ${exampleTime} 地点 对方角色名[/对方2/...]\n示例：\n${cmdName} ${exampleTime} 咖啡厅 张三\n${cmdName} ${exampleTime} 餐厅 李四/王五`;
        }
        return { valid: false, errorMsg: helpMsg };
    }

    const allowedRanges = kvGet("allowed_appointment_times", []);
    const durationConfig = kvGet("appointment_duration_config", {});
    const minDuration = minDurationOverride !== undefined ? minDurationOverride
        : (durationConfig[minDurationKey] !== undefined ? durationConfig[minDurationKey] : (minDurationKey === "phone" ? 29 : 59));
    const timeRes = parseAndValidateTime(rawTime, allowedRanges, minDuration, subtype);
    if (!timeRes.valid) return { valid: false, errorMsg: timeRes.errorMsg };
    const time = timeRes.time;

    if (!checkRealityHourLimit(time, ctx, msg)) return { valid: false, errorMsg: "" };

    // 时间调度：禁约时段（按游戏日）
    {
        const _blocked = kvGet("ts_blocked_by_day", {})[day] || [];
        if (_blocked.length > 0) {
            const _startHour = parseInt(time.split(":")[0]);
            if (_blocked.includes(_startHour)) {
                return { valid: false, errorMsg: `⚠️ ${day} ${String(_startHour).padStart(2,"0")}:00 时段已被系统禁约，请选择其他时间。` };
            }
        }
    }

    // 时间调度：允许弧长（小时）
    {
        const _allowedDurs = kvGet("ts_allowed_durations", []);
        if (_allowedDurs.length > 0) {
            const _m = time.match(/(\d{2}):(\d{2})-(\d{2}):(\d{2})/);
            if (_m) {
                const _durMins = (parseInt(_m[3]) * 60 + parseInt(_m[4])) - (parseInt(_m[1]) * 60 + parseInt(_m[2]));
                const _durHours = _durMins / 60;
                if (!_allowedDurs.includes(_durHours)) {
                    const _opts = _allowedDurs.map(h => `${h}h`).join("、");
                    return { valid: false, errorMsg: `⚠️ 邀约时长不符，当前允许的弧长为：${_opts}。` };
                }
            }
        }
    }

    let names = namesArg.replace(/，/g, "/").split("/").map(n => n.trim()).filter(Boolean);

    // 拉黑检查：被拉黑的对象不能被邀约，不做"伪装建群"（群号是有限的真实资源，不能为演戏消耗掉）。
    // 单人邀约：非静默直接告知"对方已拒绝"，静默给一个不暴露原因的通用失败，两种都不建群。
    // 多人邀约：被拉黑的对象直接从名单剔除，非静默会告知是谁被拒，静默则悄悄剔除不留痕迹；剔除后为空按同样的失败处理。
    {
        const isSingleTarget = names.length === 1;
        const blockedNoticeNames = [];
        const availableNames = [];
        let singleBlockedSilent = false;
        for (const n of names) {
            const targetUidForBlock = getUidByRoleName(platform, n);
            const entry = targetUidForBlock ? getBlockEntry(platform, targetUidForBlock, sendUid) : null;
            if (!entry) { availableNames.push(n); continue; }
            if (entry.silent) { if (isSingleTarget) singleBlockedSilent = true; }
            else blockedNoticeNames.push(n);
        }
        if (isSingleTarget && (singleBlockedSilent || blockedNoticeNames.length)) {
            return { valid: false, errorMsg: blockedNoticeNames.length ? `❌ ${blockedNoticeNames[0]} 已拒绝你的联络。` : "❌ 发起失败，请稍后重试。" };
        }
        if (blockedNoticeNames.length) {
            seal.replyToSender(ctx, msg, `❌ ${blockedNoticeNames.join("、")} 已拒绝你的联络，未能加入本次邀约。`);
        }
        names = availableNames;
        if (names.length === 0) {
            return { valid: false, errorMsg: "⚠️ 邀约对象均不可用，请检查角色名或稍后重试。" };
        }
    }
    const isMulti = names.length > 1;
    const fromKey = `${platform}:${uid}`;

    let a_lockedSlots = kvGet("a_lockedSlots", {});
    const { selfLocked, failed: lockFailed } = checkLockedSlots(platform, day, time, fromKey, sendname, names, a_private_group, a_lockedSlots);
    if (selfLocked) return { valid: false, errorMsg: `⚠️ 你在 ${day} ${time} 段与锁定时间重叠，无法发起预约` };
    if (lockFailed.length) return { valid: false, errorMsg: `⚠️ 无法发起${getCustomTypeLabel(subtype)}，以下对象不符合条件：\n- ${lockFailed.join("\n- ")}` };

    if (subtype !== "电话") {
        const instructionName = getCustomTypeLabel(subtype);
        const placeCheck = checkPlaceCommon(platform, sendname, placeOrTitle, instructionName);
        if (!placeCheck.valid) return { valid: false, errorMsg: placeCheck.errorMsg };
        if (placeCheck.warningMsg) seal.replyToSender(ctx, msg, placeCheck.warningMsg);
    }

    if (!(await checkNoQuitBlocker(uid, ctx, msg))) {
        return { valid: false, errorMsg: "🚫 您仍有未退出的违规临时群，无法发起邀约" };
    }

    let b_confirmedSchedule = kvGet("b_confirmedSchedule", {});

    let conflict = false;
    if (b_confirmedSchedule[fromKey]) {
        b_confirmedSchedule[fromKey].forEach(ev => {
            const evSubtype = (ev.subtype || "").toLowerCase();
            if (["小群", "私密", "电话", "心愿", "官约"].includes(evSubtype) && timeConflict(day, time, ev.day, ev.time)) {
                conflict = true;
            }
        });
    }
    if (conflict) return { valid: false, errorMsg: `⚠️ 你在 ${day} ${time} 时段已有安排，无法发起${getCustomTypeLabel(subtype)}~` };

    // 修改点：去除了待处理队列的检查，只检查硬冲突
    const conflictRes = checkParticipantConflicts(platform, day, time, sendname, names, a_private_group, b_confirmedSchedule);
    if (conflictRes.stop) return { valid: false, errorMsg: conflictRes.errorMsg };

    const autoMerge = (subtype === "私密") && (kvGet("auto_merge_duplicate_private", false));
    let mergeTarget = null;
    let otherConflicts = [];

    if (conflictRes.existingAppointments) {
        for (let conflict of conflictRes.existingAppointments) {
            const isExactlySame = conflict.schedule.day === day &&
                                  conflict.schedule.time === time &&
                                  conflict.schedule.place === placeOrTitle &&
                                  conflict.schedule.group; 
            if (isExactlySame && autoMerge) {
                mergeTarget = conflict.schedule;
            } else {
                otherConflicts.push(conflict);
            }
        }
    }

    if (otherConflicts.length > 0) {
        const conflictNames = otherConflicts.map(e => e.name).join("、");
        const joinEnabled = cachedGet("enable_join_existing_appointment") === "true";
        const joinHint = joinEnabled ? `\n💡 你可以使用「申请加入 角色名 时间点」尝试加入对方的预约。` : "";
        return {
            valid: false,
            errorMsg: `⚠️ 以下角色在 ${day} ${time} 时段已有安排：${conflictNames}${joinHint}`
        };
    }

    return {
        valid: true,
        data: {
            platform, uid, sendname, day, time, names, isMulti,
            a_private_group, fromKey,
            place: subtype === "电话" ? "电话" : placeOrTitle,
            title: subtype === "电话" ? placeOrTitle || "" : "",
            b_confirmedSchedule,
            mergeTarget
        }
    };
}

// ========================
// 🚀 直接建群与通知（替换原有的待回应队列逻辑）
// ========================
async function directCreateAndFinalizeAppointment({
    ctx, msg, platform, sendname, sendid, subtype, day, time, place, names, title = "", isMulti
}) {
    const a_private_group = kvGet("a_private_group", {});

    // 直接构造已确认的数据体并调用 finalizeGroupCreation 建群
    if (isMulti) {
        const groupRef = generateGroupRef(); 
        const groupData = {
            id: groupRef,
            sendname, 
            sendid,
            subtype,
            day, 
            time, 
            place,
            title,
            targetList: {}
        };
        // 全部置为已接受
        names.forEach(n => groupData.targetList[n] = "accepted");
        
        const participants = [sendname, ...names];
        const gid = await finalizeGroupCreation(platform, ctx, msg, groupData, participants);
        if (gid === false) return { success: false };
        names.forEach(n => recordInteractionStat(platform, sendname, n, "appt"));
        return { success: true, isMulti, names, gid };
    } else {
        const toname = names[0];
        // 新结构：通过 roleName 反查 uid，再取 gid
        const toUidDirect = getUidByRoleName(platform, toname);
        const toid = toUidDirect;
        const sendUidDirect = getUidByRoleName(platform, sendname);
        const item = {
            id: generateId(),
            type: "小群",
            subtype,
            sendname,
            sendid,
            toname,
            toid,
            gid: sendUidDirect ? a_private_group[platform][sendUidDirect]?.[1] : null,
            day,
            time,
            place,
            ...(title ? { title } : {})
        };

        const participants = [sendname, toname];
        const gid = await finalizeGroupCreation(platform, ctx, msg, item, participants);
        if (gid === false) return { success: false };
        names.forEach(n => recordInteractionStat(platform, sendname, n, "appt"));
        return { success: true, isMulti, names, gid };
    }
}

// ========================
// 💰 写信币消费辅助函数
// ========================

/**
 * 检查写信系统是否启用
 */
function isLetterSystemEnabled() {
    const letterExt = seal.ext.find("changri");
    if (!letterExt) return false;
    const config = kvGet("global_feature_toggle", {});
    return config.enable_direct_letter === true;
}

/**
 * 检查和消费写信币
 * @returns {success: bool, errorMsg?: string}
 */
function checkAndCostLetterCoin(ctx, msg, costType) {
    const letterExt = seal.ext.find("changri");
    if (!letterExt) return { success: false, errorMsg: "❌ 写信系统未找到" };

    const platform = msg.platform;
    const uid = msg.sender.userId.replace(`${platform}:`, "");

    // 获取玩家角色名（新结构：uid为key，roleName在value[0]）
    const a_private_group = kvGet("a_private_group", {});
    const senderRoleName = a_private_group[platform]?.[uid]?.[0];

    if (!senderRoleName) {
        return { success: false, errorMsg: "✨ 请先使用「创建新角色」来认领你的身份。" };
    }

    // 获取消费成本
    let cost = 0;
    if (costType === "wish") {
        cost = parseInt(cachedGet("wish_coin_cost") || "0");
    } else if (costType === "appointment") {
        cost = parseInt(cachedGet("appointment_coin_cost") || "0");
    }

    if (cost <= 0) {
        return { success: true }; // 未启用消费
    }

    // 检查写信币余额（从背包 global_inventories 读取）
    const roleKey = `${platform}:${uid}`;
    const itemReg = kvGet("item_registry", {});
    const coinEntry = Object.entries(itemReg).find(([, v]) => v.name === "写信币");
    if (!coinEntry) {
        return { success: false, errorMsg: "❌ 写信币尚未注册，请先执行「注册写信综基础道具」。" };
    }
    const [coinCode] = coinEntry;

    const invs = kvGet("global_inventories", {});
    const inv = invs[roleKey] || [];
    const currentCoins = inv.filter(e => e.code === coinCode).reduce((sum, e) => sum + (e.count || 0), 0);

    if (currentCoins < cost) {
        return { success: false, errorMsg: `💰 写信币不足！需要 ${cost} 枚，现有 ${currentCoins} 枚。` };
    }

    // 消费写信币（从背包中扣除）
    let remaining = cost;
    for (const entry of inv) {
        if (entry.code === coinCode && remaining > 0) {
            const deduct = Math.min(entry.count || 0, remaining);
            entry.count -= deduct;
            remaining -= deduct;
        }
    }
    invs[roleKey] = inv.filter(e => e.count > 0 || e.code !== coinCode);
    kvSet("global_inventories", invs);

    return { success: true, cost };
}

// ========================
// 📞 电话指令（直接确认版）
// ========================
let cmd_phone = {};

cmd_phone.solve = async (ctx, msg, cmdArgs) => {
    // 检查写信系统是否启用
    if (isLetterSystemEnabled()) {
        seal.replyToSender(ctx, msg, "❌ 启用写信综模式后，电话功能已禁用。");
        return seal.ext.newCmdExecuteResult(true);
    }

    const pre = await checkAppointmentPreflight(ctx, msg, cmdArgs, "电话", "phone");
    if (!pre.valid) return seal.replyToSender(ctx, msg, pre.errorMsg), seal.ext.newCmdExecuteResult(true);
    const { platform, uid, sendname, day, time, names, isMulti, a_private_group, title } = pre.data;

    // 替换为直接确认函数
    const result = await directCreateAndFinalizeAppointment({
        ctx, msg, platform, sendname, sendid: uid,
        subtype: "电话", day, time, place: "电话",
        names, isMulti, title
    });

    if (result.success) {
        const _对方 = isMulti ? names.join("、") : names[0];
        const successMsg = applyMsgTemplate("phone_success", { 对方: _对方, 群号: result.gid }) || (isMulti
            ? `✅ 你已成功向 ${_对方} 发起多人电话，通讯频段已自动建立！\n💬 频段：${result.gid}`
            : `✅ 你已成功与 ${_对方} 连线，通讯频段已自动建立！\n💬 频段：${result.gid}`);
        seal.replyToSender(ctx, msg, successMsg + buildAppointmentGuide(result.gid, day, { includeEnd: true }));
    }
    return seal.ext.newCmdExecuteResult(true);
};

function formatTime(date) {
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  return `${hours}:${minutes}`;
}

// ========================
// 🤫 私约指令（直接确认版）
// ========================

function getPrivateAliases() {
    try { return kvGet("private_appointment_aliases", []); } catch { return []; }
}

// 短信自定义触发词（如「飞鸽传书」），格式/存档/文案均与「短信」本体完全一致，只是换个词触发
function getSmsAliases() {
    try { return kvGet("sms_aliases", []); } catch { return []; }
}

let cmd_appointment_private = {};

cmd_appointment_private.solve = async (ctx, msg, cmdArgs, aliasConfig) => {
    const subtype = aliasConfig?.trigger || "私密";
    const typeName = aliasConfig?.trigger || "私约";
    const minDurationOverride = aliasConfig?.minDuration;

    // 检查写信系统启用时是否需要消费写信币
    let coinCheck = { success: true, cost: 0 };
    if (isLetterSystemEnabled()) {
        coinCheck = checkAndCostLetterCoin(ctx, msg, "appointment");
        if (!coinCheck.success) {
            seal.replyToSender(ctx, msg, coinCheck.errorMsg);
            return seal.ext.newCmdExecuteResult(true);
        }
    }

    const pre = await checkAppointmentPreflight(ctx, msg, cmdArgs, subtype, "private", minDurationOverride);
    if (!pre.valid) return seal.replyToSender(ctx, msg, pre.errorMsg), seal.ext.newCmdExecuteResult(true);

    if (pre.data.mergeTarget) {
        const newNames = [pre.data.sendname, ...pre.data.names];
        const success = mergeIntoExistingAppointment(ctx, msg, pre.data.mergeTarget, newNames, pre.data);
        if (success) {
            const successMsg = `✅ 你发起的${typeName}已自动合并到现有约会中！\n参与者：${pre.data.mergeTarget.partner}\n群号：${pre.data.mergeTarget.group}\n请自行申请入群~`;
            seal.replyToSender(ctx, msg, successMsg + buildAppointmentGuide(pre.data.mergeTarget.group, pre.data.day, { includeEnd: true }));
            return seal.ext.newCmdExecuteResult(true);
        } else {
            seal.replyToSender(ctx, msg, "❌ 自动合并失败，请稍后重试或联系管理员。");
            return seal.ext.newCmdExecuteResult(true);
        }
    }

    const { platform, uid, sendname, day, time, names, isMulti, place, a_private_group } = pre.data;

    // 替换为直接确认函数
    const result = await directCreateAndFinalizeAppointment({
        ctx, msg, platform, sendname, sendid: uid,
        subtype, day, time, place,
        names, isMulti
    });

    if (result.success) {
        const _对方 = isMulti ? names.join("、") : names[0];
        const _费用 = coinCheck.cost > 0 ? `\n💰 已消耗写信币 ${coinCheck.cost} 枚` : "";
        let successMsg = applyMsgTemplate("private_success", { 对方: _对方, 群号: result.gid, 费用: _费用.trim() }) || (isMulti
            ? `✅ 你已成功与 ${_对方} 开启多方${typeName}，私人空间已自动建立！\n💬 群号：${result.gid}${_费用}`
            : `✅ 你已成功与 ${_对方} 开启${typeName}，私人空间已自动建立！\n💬 群号：${result.gid}${_费用}`);
        seal.replyToSender(ctx, msg, successMsg + buildAppointmentGuide(result.gid, day, { includeEnd: true }));
    }
    return seal.ext.newCmdExecuteResult(true);
};

// ========================
// 💬 微信长期群聊功能
// ========================

// 🔧 检查两人之间是否已有活跃微信群
// users：完整参与者列表（含发起者）。已存在一个活跃群同时包含这些人时视为重复
function checkWechatAmongUsers(platform, users) {
    const wechatGroups = kvGet("wechat_groups", {});
    const platformGroups = wechatGroups[platform] || {};

    for (const groupId in platformGroups) {
        const group = platformGroups[groupId];
        if (group.status === "active" && users.every(u => group.participants.includes(u))) {
            return {
                exists: true,
                groupId: groupId,
                topic: group.topic || "(无主题)"
            };
        }
    }

    return { exists: false };
}

// ========================
// 核心指令：微信
// ========================

let cmd_wechat = {};
cmd_wechat.solve =async (ctx, msg, cmdArgs) => {
    let config = kvGet("global_feature_toggle", {});
    if (config.enable_wechat === false) {
        seal.replyToSender(ctx, msg, "💬 微信功能已关闭");
        return seal.ext.newCmdExecuteResult(true);
    }

    const platform = msg.platform;
    const uid = msg.sender.userId.replace(`${platform}:`, "");
    const a_private_group = kvGet("a_private_group", {});
    if (!a_private_group[platform]) a_private_group[platform] = {};

    const sendname = getRoleName(ctx, msg);
    if (!sendname) {
        seal.replyToSender(ctx, msg, "请先使用「创建新角色」绑定角色");
        return seal.ext.newCmdExecuteResult(true);
    }

    // 新结构：feature_user_blocklist[uid]
    const wechatSendUid = getPrimaryUid(platform, uid);
    if (!isUserFeatureEnabled(wechatSendUid, "enable_wechat")) {
        seal.replyToSender(ctx, msg, "🚫 您已被禁止使用微信功能");
        return seal.ext.newCmdExecuteResult(true);
    }

    const namesArg = cmdArgs.getArgN(1);
    if (!namesArg) {
        seal.replyToSender(ctx, msg, "⚠️ 格式：微信 对方角色名[/对方2/...]\n例：微信 张三\n例：微信 张三/李四");
        return seal.ext.newCmdExecuteResult(true);
    }
    let names = [...new Set(namesArg.replace(/，/g, "/").split("/").map(n => n.trim()).filter(Boolean))];
    if (names.includes(sendname)) {
        seal.replyToSender(ctx, msg, "❌ 不能邀请自己");
        return seal.ext.newCmdExecuteResult(true);
    }

    // 新结构：通过 roleName 反查 uid，逐个校验是否都已注册
    const notFoundNames = names.filter(n => !getUidByRoleName(platform, n));
    if (notFoundNames.length) {
        seal.replyToSender(ctx, msg, `❌ 未找到角色「${notFoundNames.join("、")}」，请确认对方已注册`);
        return seal.ext.newCmdExecuteResult(true);
    }

    // 拉黑检查：被拉黑的对象不能被邀约，不做"伪装建群"。单人邀约：非静默直接告知"对方已拒绝"，
    // 静默给不暴露原因的通用失败。多人邀约：被拉黑的对象直接从名单剔除，非静默会告知是谁被拒，
    // 静默则悄悄剔除不留痕迹；剔除后为空按同样的失败处理。
    {
        const isSingleTarget = names.length === 1;
        const blockedNoticeNames = [];
        const availableNames = [];
        let singleBlockedSilent = false;
        for (const n of names) {
            const targetUidForBlock = getUidByRoleName(platform, n);
            const entry = getBlockEntry(platform, targetUidForBlock, wechatSendUid);
            if (!entry) { availableNames.push(n); continue; }
            if (entry.silent) { if (isSingleTarget) singleBlockedSilent = true; }
            else blockedNoticeNames.push(n);
        }
        if (isSingleTarget && (singleBlockedSilent || blockedNoticeNames.length)) {
            seal.replyToSender(ctx, msg, blockedNoticeNames.length ? `❌ ${blockedNoticeNames[0]} 已拒绝你的联络。` : "❌ 发起失败，请稍后重试。");
            return seal.ext.newCmdExecuteResult(true);
        }
        if (blockedNoticeNames.length) {
            seal.replyToSender(ctx, msg, `❌ ${blockedNoticeNames.join("、")} 已拒绝你的联络，未能加入本次微信群。`);
        }
        if (availableNames.length === 0) return seal.ext.newCmdExecuteResult(true);
        names = availableNames;
    }

    const allParticipants = [sendname, ...names];
    const existing = checkWechatAmongUsers(platform, allParticipants);
    if (existing.exists) {
        seal.replyToSender(ctx, msg, `⚠️ 你和「${names.join("、")}」之间已存在活跃微信群：${existing.groupId}（主题：${existing.topic}）`);
        return seal.ext.newCmdExecuteResult(true);
    }

    const gid = await allocateGroup(platform, ctx, msg);
    if (!gid) {
        seal.replyToSender(ctx, msg, "⚠️ 暂无可用群号，请联系管理员添加备用群");
        return seal.ext.newCmdExecuteResult(true);
    }

    try {
        const wechatGroups = kvGet("wechat_groups", {});
        if (!wechatGroups[platform]) wechatGroups[platform] = {};
        const now = new Date();
        wechatGroups[platform][gid] = {
            id: gid,
            creator: sendname,
            creator_id: uid,
            topic: "",
            participants: allParticipants,
            status: "active",
            created_at: now.toLocaleString("zh-CN", { timeZone: "Asia/Shanghai" }),
            created_timestamp: now.getTime()
        };
        kvSet("wechat_groups", wechatGroups);

        const othersLabel = names.join("、");
        const nameTag = allParticipants.length > 2 ? "多人" : names.join("&");

        // 戏群公告
        const groupMsg = seal.newMessage();
        groupMsg.messageType = "group";
        groupMsg.groupId = `${platform}-Group:${gid}`;
        const groupCtx = seal.createTempCtx(ctx.endPoint, groupMsg);
        seal.replyToSender(groupCtx, groupMsg, applyMsgTemplate("wechat_announcement", { 发起者: sendname, 对方: othersLabel, 群号: gid })
            || `💬 微信群已建立\n\n👥 成员：${sendname}、${othersLabel}\n\n💡 长期群聊，无时间限制，每个微信关系只能有一个活跃群。`);
        setGroupName(groupCtx, groupMsg, gid, `${getCustomTypeLabel("微信")}:${sendname}&${nameTag}`);

        // 通知每一位受邀者（发起者已通过下方 successMsg 得到回执）
        names.forEach(toname => {
            const toUidLookup = getUidByRoleName(platform, toname);
            const toInfo = toUidLookup ? a_private_group[platform][toUidLookup] : null;
            if (!toInfo) return;
            const toBindGid = toInfo[1];
            const notifyMsg = seal.newMessage();
            notifyMsg.messageType = "group";
            notifyMsg.groupId = `${platform}-Group:${toBindGid}`;
            const notifyCtx = seal.createTempCtx(ctx.endPoint, notifyMsg);
            seal.replyToSender(notifyCtx, notifyMsg, applyMsgTemplate("wechat_notice", { 发起者: sendname, 对方: othersLabel, 群号: gid })
                || `💬 ${sendname} 邀你加入微信群\n\n📱 群号：${gid}\n👥 成员：${sendname}、${othersLabel}\n\n💡 长期群聊，无时间限制。`);
        });

        seal.replyToSender(ctx, msg, `✅ 微信群创建成功！\n📱 群号：${gid}\n👥 成员：${sendname}、${othersLabel}`);
    } catch (e) {
        // 创建失败，释放已分配的群号
        const groupList = kvGet("group", []);
        const idx = groupList.indexOf(gid + "_占用");
        if (idx !== -1) {
            groupList.splice(idx, 1);
            groupList.push(gid);
            kvSet("group", groupList);
        }
        seal.replyToSender(ctx, msg, `❌ 微信群创建失败（群号已释放），请重试。错误：${e.message}`);
    }
    return seal.ext.newCmdExecuteResult(true);
};



let cmd_view_schedule = {};
cmd_view_schedule.solve =(ctx, msg) => {
    const platform = msg.platform, uid = msg.sender.userId, roleId = uid.replace(`${platform}:`, "");
    const storage = (k) => kvGet(k, {});
    const schedule = storage("b_confirmedSchedule"), multiReq = storage("b_MultiGroupRequest");
    const privGroup = storage("a_private_group"), timers = storage("group_timers");
    
    // 新结构：uid为key，roleName在value[0]
    const myName = privGroup[platform]?.[roleId]?.[0] || null;
    if (!myName) return seal.replyToSender(ctx, msg, "请先绑定角色");

    // 1. 聚合日程与微信群
    let events = (schedule[uid] || []).map(e => ({...e}));
    
    // 注入多人预约
    Object.entries(multiReq).forEach(([ref, g]) => {
        const isRecip = g.targetList?.[myName] === "accepted", isSend = g.sendid === roleId;
        if ((isRecip || isSend) && !events.some(e => e.day === g.day && e.time === g.time)) {
            const partners = isSend ? [...new Set([g.sendname, ...Object.keys(g.targetList || {}).filter(n => g.targetList[n] !== "rejected")])] : [g.sendname];
            events.push({ day: g.day, time: g.time, subtype: g.subtype, place: g.place, partner: partners.join("、"), status: "pending", isMulti: true, multiRef: ref });
        }
    });

    // 排序并格式化
    events.sort((a, b) => parseInt(a.day.slice(1)) - parseInt(b.day.slice(1)) || a.time.localeCompare(b.time));

    const wechat = Object.values(storage("wechat_groups")[platform] || {})
        .filter(g => g.status === "active" && g.participants.includes(myName))
        .map(g => ({ day: "微信群", time: "长期", subtype: "微信群", place: g.topic, partner: g.participants.join("、"), status: "active", isWechat: true }));

    const allEvents = [...events, ...wechat];
    if (!allEvents.length) return seal.replyToSender(ctx, msg, "✨ 【日程表】\n\n当前暂无行程安排。");

    // 2. 构造显示文本
    allEvents.forEach(ev => {
        const isPending = ev.status === "pending", isEnded = ev.status === "ended";
        let tag = "";
        if (ev.isWechat) tag = "长期活跃";
        else {
            const timer = ev.group ? timers[ev.group]?.timerStatus?.[myName]?.status : null;
            tag = isEnded ? "已完结" : (isPending ? "待开启" : "进行中") + 
                  (timer === "replied" ? " [已回]" : (timer === "timing" ? " [⏳未回]" : ""));
            if (isPending && ev.isMulti && multiReq[ev.multiRef]?.targetList?.[myName] === "accepted") tag += " [🤝已接]";
        }
        const _aliasIconMap = {};
        getPrivateAliases().forEach(a => { if (a.trigger && a.icon) _aliasIconMap[a.trigger] = a.icon; });
        const icon = ({ "电话": "📞", "微信群": "💬", ..._aliasIconMap })[ev.subtype] || "🎭";
        let progressText = "";
        if (ev.group && !ev.isWechat) {
            // ended 用存档快照，进行中用实时计数
            const grpProg = ev.finalProgress || kvGet("group_write_progress", {})[ev.group] || {};
            const privGrp = store.get("a_private_group")[platform] || {};
            let counts;
            if (ev.partner === "多人小群" || ev.partner?.startsWith("多人小群、")) {
                // 多人小群 partner 字段无法反查参与者，直接从进度 uid 键取数
                const myCount = grpProg[roleId] || 0;
                const otherCounts = Object.entries(grpProg)
                    .filter(([u]) => u !== roleId)
                    .map(([_, c]) => c);
                counts = [myCount, ...otherCounts];
            } else {
                const parts = [myName, ...ev.partner.split(/[、,，]/).map(s => s.trim()).filter(Boolean)]
                    .filter((v, i, a) => a.indexOf(v) === i);
                counts = parts.map(n => {
                    const uid = Object.entries(privGrp).find(([_, v]) => v[0] === n)?.[0];
                    return uid ? (grpProg[uid] || 0) : 0;
                });
            }
            if (counts.some(c => c > 0)) progressText = `\n✍️ ${ev.status === "ended" ? "最终段数" : "当前进度"}：${counts.join('v')}`;
        }
        ev.displayText = `【${ev.day} ${ev.time}】\n${icon} ${getCustomTypeLabel(ev.subtype)} · ${tag}\n📍 地点：${ev.place || "未知"}\n👥 伙伴：${ev.partner}${progressText}`;
    });

    if (!msg.groupId) return seal.replyToSender(ctx, msg, "请在群内使用合并转发。");
    
    // 3. 构造合并转发节点
    const botUid = ctx.endPoint.userId, nodes = [];
    let curDay = "";

    allEvents.forEach(ev => {
        if (ev.day !== curDay) {
            nodes.push({ type: "node", data: { name: "📅 日程管家", uin: botUid, content: ev.isWechat ? "💬 我的微信群" : `✨ ==== ${ev.day} 的日程 ==== ✨` } });
            curDay = ev.day;
        }
        const partnerName = ev.partner.split(/[、,]/)[0];
        const pUid = getUidByRoleName(platform, partnerName) || botUid;
        nodes.push({ type: "node", data: { name: ev.partner.split(/[、,]/)[0] || "助手", uin: pUid, content: ev.displayText } });
    });

    nodes.unshift({ type: "node", data: { name: "时间线档案", uin: botUid, content: `📅 共 ${events.length} 条日程，${wechat.length} 个群组` } });

    ws({ action: "send_group_forward_msg", params: { group_id: parseInt(msg.groupId.replace(/[^\d]/g, ""), 10), messages: nodes } }, ctx, msg, "");
};



// ========================
// 辅助函数（若尚未定义）
// ========================
function timeToMinutes(timeStr) {
    const [h, m] = timeStr.split(':').map(Number);
    return h * 60 + m;
}

// ========================
// 📥 手动加入请求指令
// ========================

let cmd_apply_join = {};
cmd_apply_join.solve = async (ctx, msg, cmdArgs) => {
    const enableJoin = cachedGet("enable_join_existing_appointment");
    if (enableJoin !== "true") {
        return seal.replyToSender(ctx, msg, "🚫 当前未启用「加入私约」功能。");
    }

    const targetName = cmdArgs.getArgN(1);
    const rawTime = cmdArgs.getArgN(2);
    if (!targetName || !rawTime) {
        return seal.replyToSender(ctx, msg, "⚠️ 参数不足，正确格式：申请加入 角色名 时间点\n示例：申请加入 张三 14:30");
    }

    const platform = msg.platform;
    const uid = msg.sender.userId.replace(`${platform}:`, "");
    const a_private_group = kvGet("a_private_group", {});
    if (!a_private_group[platform]) a_private_group[platform] = {};

    const sendname = getRoleName(ctx, msg);
    if (!sendname) return seal.replyToSender(ctx, msg, "请先使用「创建新角色」绑定角色");

    const globalDay = cachedGet("global_days");
    if (!globalDay) return seal.replyToSender(ctx, msg, "⚠️ 当前尚未设置全局天数，请先使用 \".设置天数 D1\"");

    const targetUid = getUidByRoleName(platform, targetName);
    if (!targetUid) {
        return seal.replyToSender(ctx, msg, `❌ 角色「${targetName}」未注册，无法发起加入请求。`);
    }
    const targetInfo = a_private_group[platform][targetUid];
    const targetGroupId = targetInfo?.[1];

    let pointTime = rawTime;
    if (/^\d{4}$/.test(rawTime)) {
        pointTime = `${rawTime.slice(0, 2)}:${rawTime.slice(2, 4)}`;
    } else if (!/^\d{2}:\d{2}$/.test(rawTime)) {
        return seal.replyToSender(ctx, msg, "⚠️ 时间格式错误，请使用 HH:MM 或 HHMM（如 14:30 或 1430）");
    }

    let b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
    const targetKey = `${platform}:${targetUid}`;
    const targetSchedules = b_confirmedSchedule[targetKey] || [];

    const matchingSchedule = targetSchedules.find(schedule => {
        if (schedule.day !== globalDay) return false;
        const [startStr, endStr] = schedule.time.split('-');
        const pointMinutes = timeToMinutes(pointTime);
        const startMinutes = timeToMinutes(startStr);
        const endMinutes = timeToMinutes(endStr);
        return pointMinutes >= startMinutes && pointMinutes <= endMinutes;
    });

    if (!matchingSchedule) {
        return seal.replyToSender(ctx, msg, `❌ 未找到「${targetName}」在 ${globalDay} ${pointTime} 附近的有效预约。`);
    }

    if (matchingSchedule.partner && matchingSchedule.partner.includes(sendname)) {
        return seal.replyToSender(ctx, msg, `⚠️ 你已经在「${targetName}」的该时段预约中，无需重复加入。`);
    }
    if (matchingSchedule.partner === "多人小群" && matchingSchedule.group) {
        const gei = kvGet("group_expire_info", {});
        const existingParticipants = gei[matchingSchedule.group]?.participants || [];
        if (existingParticipants.includes(sendname)) {
            return seal.replyToSender(ctx, msg, `⚠️ 你已经在该约会中，无需重复加入。`);
        }
    }

    const fromKey = `${platform}:${uid}`;
    const fromSchedules = b_confirmedSchedule[fromKey] || [];
    const hasConflict = fromSchedules.some(s => timeConflict(globalDay, matchingSchedule.time, s.day, s.time));
    if (hasConflict) {
        return seal.replyToSender(ctx, msg, `⚠️ 你在 ${globalDay} ${matchingSchedule.time} 已有其他安排，无法加入该预约。`);
    }

    let a_lockedSlots = kvGet("a_lockedSlots", {});
    const fromLocked = a_lockedSlots[fromKey]?.[globalDay] || [];
    if (fromLocked.some(lockedTime => timeOverlap(matchingSchedule.time, lockedTime))) {
        return seal.replyToSender(ctx, msg, `⚠️ 你在 ${globalDay} ${matchingSchedule.time} 时段被锁定，无法加入。`);
    }

    let joinRequests = kvGet("join_request_list", []);
    const existingPending = joinRequests.some(req =>
        req.from === sendname &&
        req.to === targetName &&
        req.day === globalDay &&
        req.time === matchingSchedule.time &&
        req.status === "pending"
    );
    if (existingPending) {
        return seal.replyToSender(ctx, msg, `⏳ 你已经向「${targetName}」发起了针对该时段的加入请求，请等待对方处理。`);
    }

    const requestId = Math.random().toString(36).substring(2, 8);
    const joinRequest = {
        id: requestId,
        type: "join",
        from: sendname,
        fromUid: uid,
        to: targetName,
        toUid: targetUid,
        day: globalDay,
        time: matchingSchedule.time,
        place: matchingSchedule.place || "电话",
        targetGroupId: matchingSchedule.group,
        targetSchedule: matchingSchedule,
        status: "pending",
        timestamp: Date.now()
    };
    joinRequests.push(joinRequest);
    kvSet("join_request_list", joinRequests);

    if (targetGroupId) {
        const notifyMsg = seal.newMessage();
        notifyMsg.messageType = "group";
        notifyMsg.groupId = `${platform}-Group:${targetGroupId}`;
        const notifyCtx = seal.createTempCtx(ctx.endPoint, notifyMsg);
        const notice = `📢 加入请求\n\n${sendname} 想加入你正在进行的预约：\n📅 ${globalDay} ${matchingSchedule.time}\n📍 ${matchingSchedule.place || "电话"}\n\n请使用「加入请求」查看详情，然后输入「同意加入 编号」或「拒绝加入 编号」。`;
        seal.replyToSender(notifyCtx, notifyMsg, notice);
    }

    seal.replyToSender(ctx, msg, `✨ 已向「${targetName}」发送加入请求，请等待对方回应。`);
    return seal.ext.newCmdExecuteResult(true);
};

let cmd_join_requests = {};
cmd_join_requests.solve = (ctx, msg, cmdArgs) => {
    const platform = msg.platform;
    const pureUid = getPrimaryUid(platform, msg.sender.userId.replace(`${platform}:`, ""));
    const joinRequests = kvGet("join_request_list", []);
    const myRequests = joinRequests.filter(req => req.toUid === pureUid && req.status === "pending");

    if (myRequests.length === 0) {
        seal.replyToSender(ctx, msg, "📭 当前没有待处理的加入请求。");
        return seal.ext.newCmdExecuteResult(true);
    }

    let rep = "📥 加入请求列表：\n\n";
    myRequests.forEach((req, idx) => {
        rep += `【编号 ${idx + 1}】\n`;
        rep += `发起人：${req.from}\n`;
        rep += `时间：${req.day} ${req.time}\n`;
        rep += `地点：${req.place}\n`;
        rep += `目标群：${req.targetGroupId}\n`;
        rep += `请求ID：${req.id}\n\n`;
    });
    rep += "💡 使用「同意加入 编号」或「拒绝加入 编号」处理。";
    seal.replyToSender(ctx, msg, rep);
    return seal.ext.newCmdExecuteResult(true);
};

let cmd_accept_join = {};
cmd_accept_join.solve = (ctx, msg, cmdArgs) => {
    const enableJoin = cachedGet("enable_join_existing_appointment");
    if (enableJoin !== "true") {
        return seal.replyToSender(ctx, msg, "🚫 当前未启用「加入私约」功能。");
    }

    const idx = parseInt(cmdArgs.getArgN(1)) - 1;
    const platform = msg.platform;
    const pureUid = getPrimaryUid(platform, msg.sender.userId.replace(`${platform}:`, ""));

    let joinRequests = kvGet("join_request_list", []);
    const myPending = joinRequests.filter(req => req.toUid === pureUid && req.status === "pending");
    if (isNaN(idx) || idx < 0 || idx >= myPending.length) {
        return seal.replyToSender(ctx, msg, "❌ 无效的编号，请使用「加入请求」查看。");
    }
    const request = myPending[idx];
    const fullRequest = joinRequests.find(r => r.id === request.id);
    if (!fullRequest) return seal.replyToSender(ctx, msg, "❌ 请求不存在或已过期。");

    const acceptIdx = joinRequests.indexOf(fullRequest);
    if (acceptIdx !== -1) joinRequests.splice(acceptIdx, 1);
    kvSet("join_request_list", joinRequests);

    const a_private_group = kvGet("a_private_group", {});
    const fromUid = getUidByRoleName(platform, fullRequest.from);
    if (!fromUid) {
        seal.replyToSender(ctx, msg, `⚠️ 无法找到发起人「${fullRequest.from}」的信息。`);
        return seal.ext.newCmdExecuteResult(true);
    }
    const targetGroupId = fullRequest.targetGroupId;

    let b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
    const fromKey = `${platform}:${fromUid}`;
    const targetSchedule = fullRequest.targetSchedule;
    const groupId = targetSchedule.group;
    const day = targetSchedule.day;
    const time = targetSchedule.time;

    const relatedEntries = [];
    for (const [key, scheduleList] of Object.entries(b_confirmedSchedule)) {
        for (let ev of scheduleList) {
            if (ev.group === groupId && ev.day === day && ev.time === time) {
                relatedEntries.push({ key, ev });
            }
        }
    }

    const totalAfterJoin = relatedEntries.length + 1;
    const isMultiParty = totalAfterJoin > 2;
    const newPartnerSuffix = "、" + fullRequest.from;
    for (let entry of relatedEntries) {
        if (isMultiParty) {
            entry.ev.partner = "多人小群";
        } else if (!entry.ev.partner.includes(fullRequest.from)) {
            entry.ev.partner += newPartnerSuffix;
        }
    }

    let basePartner;
    if (isMultiParty) {
        basePartner = "多人小群";
    } else {
        basePartner = relatedEntries.length > 0 ? relatedEntries[0].ev.partner : targetSchedule.partner;
        if (!basePartner.includes(fullRequest.from)) basePartner += newPartnerSuffix;
    }
    let groupExpireInfo = kvGet("group_expire_info", {});
    if (!groupExpireInfo[groupId]) {
        seal.replyToSender(ctx, msg, "❌ 该约会群已结束或不存在，无法加入。");
        return seal.ext.newCmdExecuteResult(true);
    }

    const newSchedule = { ...targetSchedule };
    newSchedule.partner = basePartner;
    if (!b_confirmedSchedule[fromKey]) b_confirmedSchedule[fromKey] = [];
    b_confirmedSchedule[fromKey].push(newSchedule);

    kvSet("b_confirmedSchedule", b_confirmedSchedule);

    const existingParts = groupExpireInfo[groupId].participants || [];
    if (!existingParts.includes(fullRequest.from)) {
        groupExpireInfo[groupId].participants = [...existingParts, fullRequest.from];
    }
    kvSet("group_expire_info", groupExpireInfo);

    let groupTimers = kvGet("group_timers", {});
    const timerEntry = groupTimers[groupId];
    if (timerEntry) {
        const now = Date.now();
        if (timerEntry.timerMode === "turn_taking" && timerEntry.participants.length === 2) {
            timerEntry.timerMode = "independent";
            for (const status of Object.values(timerEntry.timerStatus)) {
                if (status.status === "waiting") {
                    status.status = "timing";
                    status.startTime = now;
                    status.repliedTime = null;
                    status.wordCount = 0;
                    status.remindedTimes = 0;
                }
            }
        }
        if (!timerEntry.participants.includes(fullRequest.from)) {
            timerEntry.participants.push(fullRequest.from);
        }
        if (!timerEntry.timerStatus[fullRequest.from]) {
            timerEntry.timerStatus[fullRequest.from] = {
                status: "timing",
                startTime: now,
                repliedTime: null,
                wordCount: 0,
                remindedTimes: 0,
                isInitiator: false
            };
        }
        groupTimers[groupId] = timerEntry;
        kvSet("group_timers", groupTimers);
    }

    const updatedParticipants = groupExpireInfo[groupId]?.participants || [];
    if (updatedParticipants.length > 0) {
        const nameTag = updatedParticipants.length > 2 ? "多人" : updatedParticipants.join("、");
        const newGroupName = `${getCustomTypeLabel(targetSchedule.subtype || "私密")} ${day} ${time} ${targetSchedule.place ? targetSchedule.place + " " : ""}${nameTag}`;
        const renameMsg = seal.newMessage();
        renameMsg.messageType = "group";
        renameMsg.groupId = `${platform}-Group:${targetGroupId}`;
        const renameCtx = seal.createTempCtx(ctx.endPoint, renameMsg);
        setGroupName(renameCtx, renameMsg, targetGroupId, newGroupName);
    }

    const groupMsg = seal.newMessage();
    groupMsg.messageType = "group";
    groupMsg.groupId = `${platform}-Group:${targetGroupId}`;
    const groupCtx = seal.createTempCtx(ctx.endPoint, groupMsg);
    seal.replyToSender(groupCtx, groupMsg, `✨ ${fullRequest.from} 已经到来，正在加入你们的约会。`);

    const fromInfo = a_private_group[platform][fromUid];
    const fromGroupId = fromInfo?.[1];
    if (fromGroupId) {
        const fromMsg = seal.newMessage();
        fromMsg.messageType = "group";
        fromMsg.groupId = `${platform}-Group:${fromGroupId}`;
        const fromCtx = seal.createTempCtx(ctx.endPoint, fromMsg);
        seal.replyToSender(fromCtx, fromMsg, `✅ 你已成功加入 ${fullRequest.to} 的私约，群号：${targetGroupId}\n请自行申请入群。`);
    }

    seal.replyToSender(ctx, msg, `✅ 已同意 ${fullRequest.from} 加入你的私约。`);
    return seal.ext.newCmdExecuteResult(true);
};

let cmd_reject_join = {};
cmd_reject_join.solve = (ctx, msg, cmdArgs) => {
    const idx = parseInt(cmdArgs.getArgN(1)) - 1;
    const platform = msg.platform;
    const pureUid = getPrimaryUid(platform, msg.sender.userId.replace(`${platform}:`, ""));

    let joinRequests = kvGet("join_request_list", []);
    const myPending = joinRequests.filter(req => req.toUid === pureUid && req.status === "pending");
    if (isNaN(idx) || idx < 0 || idx >= myPending.length) {
        return seal.replyToSender(ctx, msg, "❌ 无效的编号，请使用「加入请求」查看。");
    }
    const request = myPending[idx];
    const fullRequest = joinRequests.find(r => r.id === request.id);
    if (!fullRequest) return seal.replyToSender(ctx, msg, "❌ 请求不存在或已过期。");

    const rejectIdx = joinRequests.indexOf(fullRequest);
    if (rejectIdx !== -1) joinRequests.splice(rejectIdx, 1);
    kvSet("join_request_list", joinRequests);

    const a_private_group = kvGet("a_private_group", {});
    const fromUid = getUidByRoleName(platform, fullRequest.from);
    const fromInfo = fromUid ? a_private_group[platform]?.[fromUid] : null;
    if (fromInfo) {
        const fromGroupId = fromInfo[1];
        if (fromGroupId) {
            const fromMsg = seal.newMessage();
            fromMsg.messageType = "group";
            fromMsg.groupId = `${platform}-Group:${fromGroupId}`;
            const fromCtx = seal.createTempCtx(ctx.endPoint, fromMsg);
            seal.replyToSender(fromCtx, fromMsg, `❌ ${fullRequest.to} 拒绝了你的加入请求。`);
        }
    }

    seal.replyToSender(ctx, msg, `✅ 已拒绝 ${fullRequest.from} 的加入请求。`);
    return seal.ext.newCmdExecuteResult(true);
};


// 🔧 新增：设置允许预约时间范围的指令
let cmd_set_allowed_times = seal.ext.newCmdItemInfo();
cmd_set_allowed_times.name = "设置邀约时间";
cmd_set_allowed_times.help = "。设置邀约时间 [时间段1] [时间段2] ...\n示例：。设置邀约时间 09:00-12:00 14:00-18:00";
cmd_set_allowed_times.solve = (ctx, msg, cmdArgs) => {
  if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
    return seal.ext.newCmdExecuteResult(true);
  }
  let timeRanges = [];
  
  // 收集所有时间段参数
  for (let i = 1; i <= cmdArgs.args.length; i++) {
    const arg = cmdArgs.getArgN(i);
    if (arg) {
      // 验证时间格式
      if (!/^(\d{2}):(\d{2})-(\d{2}):(\d{2})$/.test(arg)) {
        seal.replyToSender(ctx, msg, `⚠️ 时间格式错误：「${arg}」\n请使用格式：HH:MM-HH:MM，如 09:00-12:00`);
        return seal.ext.newCmdExecuteResult(true);
      }
      timeRanges.push(arg);
    }
  }
  
  if (timeRanges.length === 0) {
    const currentRanges  = kvGet("allowed_appointment_times", []);
    const blockedByDay   = kvGet("ts_blocked_by_day", {});
    const allowedDurs    = kvGet("ts_allowed_durations", []);
    const currentDay     = cachedGet("global_days") || "";

    const lines = ["📋 邀约时间限制"];

    // 1. 功能时间窗口（allowed_appointment_times）
    lines.push("\n【可约时间段】");
    if (currentRanges.length === 0) {
      lines.push("· 不限（任何时间）");
    } else {
      currentRanges.forEach(r => lines.push(`· ${r}`));
    }

    // 2. 禁约时段（ts_blocked_by_day，当前天 + 全览）
    lines.push("\n【禁约时段（按游戏日）】");
    const dayKeys = Object.keys(blockedByDay);
    if (dayKeys.length === 0) {
      lines.push("· 无");
    } else {
      dayKeys.sort().forEach(d => {
        const hours = blockedByDay[d];
        if (!hours || hours.length === 0) return;
        const tag = d === currentDay ? `${d}（当前）` : d;
        lines.push(`· ${tag}：${hours.map(h => `${String(h).padStart(2,"0")}:00`).join("、")}`);
      });
    }

    // 3. 允许弧长（ts_allowed_durations）
    lines.push("\n【允许弧长】");
    if (allowedDurs.length === 0) {
      lines.push("· 不限");
    } else {
      lines.push(`· ${allowedDurs.map(h => `${h}h`).join("、")}`);
    }

    seal.replyToSender(ctx, msg, lines.join("\n"));
    return seal.ext.newCmdExecuteResult(true);
  }
  
  // 保存设置
  kvSet("allowed_appointment_times", timeRanges);
  seal.replyToSender(ctx, msg, `✅ 已设置允许的邀约时间段：\n${timeRanges.map(range => `· ${range}`).join('\n')}`);
  return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["设置邀约时间"] = cmd_set_allowed_times;

// 🔧 新增：清空允许时间范围的指令
let cmd_clear_allowed_times = seal.ext.newCmdItemInfo();
cmd_clear_allowed_times.name = "清空邀约时间";
cmd_clear_allowed_times.help = "。清空邀约时间 - 清空所有时间限制";
cmd_clear_allowed_times.solve = (ctx, msg, cmdArgs) => {
  if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
    return seal.ext.newCmdExecuteResult(true);
  }
  kvSet("allowed_appointment_times", []);
  seal.replyToSender(ctx, msg, "✅ 已清空邀约时间限制，现在任何时间都允许发起邀约");
  return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["清空邀约时间"] = cmd_clear_allowed_times;


// ========================
// 🏠 群组生命周期管理
// ========================

// 添加群号
let cmd_add_group = seal.ext.newCmdItemInfo();
cmd_add_group.name = "添加群号";
cmd_add_group.help = "。添加群号 群号（多个用逗号隔开）";
cmd_add_group.solve = (ctx, msg, cmdArgs) => {
    if (!msg.isMaster && !isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, `此指令仅限骰主或管理员使用`);
        return seal.ext.newCmdExecuteResult(true);
    }
    let grouplist = cmdArgs.getArgN(1);
    if (!grouplist) { const r = seal.ext.newCmdExecuteResult(true); r.showHelp = true; return r; }
    grouplist = grouplist.replace(/，/g, ",").split(",");
    let group = kvGet("group", []);
    for (let i = 0; i < grouplist.length; i++) {
        if (/^[0-9]+$/.test(grouplist[i]) && !group.includes(grouplist[i])) {
            group.push(grouplist[i]);
        }
    }
    kvSet("group", group);
    seal.replyToSender(ctx, msg, `✅ 已添加群号，当前可用共 ${group.length} 个。`);
    return seal.ext.newCmdExecuteResult(true);
}
ext.cmdMap["添加群号"] = cmd_add_group;

// 移除群号
let cmd_remove_group = seal.ext.newCmdItemInfo();
cmd_remove_group.name = "移除群号";
cmd_remove_group.help = "。移除群号 群号（多个用逗号隔开）";
cmd_remove_group.solve = (ctx, msg, cmdArgs) => {
    if (!msg.isMaster && !isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, `此指令仅限骰主或管理员使用`);
        return seal.ext.newCmdExecuteResult(true);
    }
    let grouplist = cmdArgs.getArgN(1);
    if (!grouplist) { const r = seal.ext.newCmdExecuteResult(true); r.showHelp = true; return r; }
    grouplist = grouplist.replace(/，/g, ",").split(",");
    let group = kvGet("group", []);
    for (let i = 0; i < grouplist.length; i++) {
        let idx = group.indexOf(grouplist[i]);
        if (idx !== -1) group.splice(idx, 1);
    }
    kvSet("group", group);
    seal.replyToSender(ctx, msg, `✅ 指定群号已移除，当前可用共 ${group.length} 个。`);
    return seal.ext.newCmdExecuteResult(true);
}
ext.cmdMap["移除群号"] = cmd_remove_group;

// 查看群号
let cmd_show_group = seal.ext.newCmdItemInfo();
cmd_show_group.name = "查看群号";
cmd_show_group.help = "。查看群号";
cmd_show_group.solve = (ctx, msg, cmdArgs) => {
    if (!msg.isMaster && !isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, `此指令仅限骰主或管理员使用`);
        return seal.ext.newCmdExecuteResult(true);
    }
    let group = kvGet("group", []);
    let rep = `📜 当前可用群号（共 ${group.length} 个）：\n`;
    for (let i = 0; i < group.length; i++) {
        const isOccupied = group[i].endsWith("_占用");
        rep += `• ${isOccupied ? group[i].replace(/_占用$/, "") + " 🔴占用中" : group[i]}\n`;
    }
    seal.replyToSender(ctx, msg, rep.trim());
    return seal.ext.newCmdExecuteResult(true);
}
ext.cmdMap["查看群号"] = cmd_show_group;

// 开启群号组（从 rp_archive 拉取组内 QQ 号批量注入）
let cmd_open_group_set = seal.ext.newCmdItemInfo();
cmd_open_group_set.name = "开启群号组";
cmd_open_group_set.help = "。开启群号组 组名\n从 rp_archive 后台读取该组所有群号，批量加入可用池";
cmd_open_group_set.solve = async (ctx, msg, cmdArgs) => {
    if (!msg.isMaster && !isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, `此指令仅限骰主或管理员使用`);
        return seal.ext.newCmdExecuteResult(true);
    }
    const setName = cmdArgs.getArgN(1);
    if (!setName) { const r = seal.ext.newCmdExecuteResult(true); r.showHelp = true; return r; }
    const base  = (seal.ext.getStringConfig(ext, "RP存档服务器地址") || "").replace(/\/$/, "");
    const token = seal.ext.getStringConfig(ext, "RP存档Token") || "";
    if (!base) {
        seal.replyToSender(ctx, msg, `❌ 未配置 RP 存档服务器地址。`);
        return seal.ext.newCmdExecuteResult(true);
    }
    try {
        const resp = await fetch(`${base}/api/group_set/${encodeURIComponent(setName)}`, {
            headers: { "X-Archive-Token": token }
        });
        if (!resp.ok) {
            seal.replyToSender(ctx, msg, `❌ 服务器返回 ${resp.status}，请检查组名是否正确。`);
            return seal.ext.newCmdExecuteResult(true);
        }
        const data = await resp.json();
        if (!data.ok || !data.group_ids || data.group_ids.length === 0) {
            seal.replyToSender(ctx, msg, `⚠️ 群号组「${setName}」在后台不存在或暂无群号。`);
            return seal.ext.newCmdExecuteResult(true);
        }
        let group = kvGet("group", []);
        let added = 0;
        for (const gid of data.group_ids) {
            if (!group.includes(gid) && !group.includes(gid + "_占用")) {
                group.push(gid);
                added++;
            }
        }
        kvSet("group", group);
        seal.replyToSender(ctx, msg, `✅ 群号组「${setName}」已开启，新注入 ${added} 个群号（共 ${data.group_ids.length} 个），当前可用池共 ${group.length} 个。`);
    } catch (e) {
        seal.replyToSender(ctx, msg, `❌ 请求失败：${e.message || String(e)}`);
    }
    return seal.ext.newCmdExecuteResult(true);
}
ext.cmdMap["开启群号组"] = cmd_open_group_set;

// 关闭群号组（从 rp_archive 拉取组内 QQ 号批量移除，占用中的无法移除）
let cmd_close_group_set = seal.ext.newCmdItemInfo();
cmd_close_group_set.name = "关闭群号组";
cmd_close_group_set.help = "。关闭群号组 组名\n将该组所有群号从可用池移除（占用中的群无法移除）";
cmd_close_group_set.solve = async (ctx, msg, cmdArgs) => {
    if (!msg.isMaster && !isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, `此指令仅限骰主或管理员使用`);
        return seal.ext.newCmdExecuteResult(true);
    }
    const setName = cmdArgs.getArgN(1);
    if (!setName) { const r = seal.ext.newCmdExecuteResult(true); r.showHelp = true; return r; }
    const base  = (seal.ext.getStringConfig(ext, "RP存档服务器地址") || "").replace(/\/$/, "");
    const token = seal.ext.getStringConfig(ext, "RP存档Token") || "";
    if (!base) {
        seal.replyToSender(ctx, msg, `❌ 未配置 RP 存档服务器地址。`);
        return seal.ext.newCmdExecuteResult(true);
    }
    try {
        const resp = await fetch(`${base}/api/group_set/${encodeURIComponent(setName)}`, {
            headers: { "X-Archive-Token": token }
        });
        if (!resp.ok) {
            seal.replyToSender(ctx, msg, `❌ 服务器返回 ${resp.status}，请检查组名是否正确。`);
            return seal.ext.newCmdExecuteResult(true);
        }
        const data = await resp.json();
        if (!data.ok || !data.group_ids || data.group_ids.length === 0) {
            seal.replyToSender(ctx, msg, `⚠️ 群号组「${setName}」在后台不存在或暂无群号。`);
            return seal.ext.newCmdExecuteResult(true);
        }
        let group = kvGet("group", []);
        let removed = 0, skipped = [];
        for (const gid of data.group_ids) {
            if (group.includes(gid + "_占用")) {
                skipped.push(gid);
            } else {
                const idx = group.indexOf(gid);
                if (idx !== -1) { group.splice(idx, 1); removed++; }
            }
        }
        kvSet("group", group);
        let rep = `✅ 群号组「${setName}」已关闭，移除 ${removed} 个群号，当前可用池剩 ${group.length} 个。`;
        if (skipped.length > 0) rep += `\n⚠️ 以下群正在占用中，无法移除：\n${skipped.map(g => `• ${g}`).join("\n")}`;
        seal.replyToSender(ctx, msg, rep);
    } catch (e) {
        seal.replyToSender(ctx, msg, `❌ 请求失败：${e.message || String(e)}`);
    }
    return seal.ext.newCmdExecuteResult(true);
}
ext.cmdMap["关闭群号组"] = cmd_close_group_set;

// 驱逐指定QQ
let cmd_kick_qq = seal.ext.newCmdItemInfo();
cmd_kick_qq.name = "驱逐";
cmd_kick_qq.help = "使用方法：。驱逐 QQ号\n从群号池所有群中踢出指定QQ";
cmd_kick_qq.solve = async (ctx, msg, cmdArgs) => {
    if (!msg.isMaster && !isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, `此指令仅限骰主或管理员使用`);
        return seal.ext.newCmdExecuteResult(true);
    }

    const targetQQ = cmdArgs.getArgN(1);
    if (!targetQQ || !/^\d+$/.test(targetQQ)) {
        const ret = seal.ext.newCmdExecuteResult(true);
        ret.showHelp = true;
        return ret;
    }

    const platform = msg.platform;
    const extras = kvGet("extra_accounts", {});
    // 找到主账号（若 targetQQ 本身是额外账号则找到其主账号）
    const primaryUid = extras[`${platform}:${targetQQ}`] || targetQQ;
    // 收集主账号 + 所有额外账号
    const extraQQs = Object.entries(extras)
        .filter(([k, v]) => k.startsWith(`${platform}:`) && v === primaryUid)
        .map(([k]) => k.replace(`${platform}:`, ""));
    const allTargetQQs = [...new Set([primaryUid, ...extraQQs])];

    const groups = kvGet("group", [])
        .map(g => g.replace(/_占用$/, ""));

    if (groups.length === 0) {
        seal.replyToSender(ctx, msg, `❌ 群号池为空，无群可操作。`);
        return seal.ext.newCmdExecuteResult(true);
    }

    const extraTip = allTargetQQs.length > 1 ? `（含额外账号：${allTargetQQs.filter(q => q !== primaryUid).join("、")}）` : "";
    seal.replyToSender(ctx, msg, `🔍 正在从 ${groups.length} 个群中搜索并踢出 ${targetQQ}${extraTip}...`);

    let countKick = 0;
    let countNotIn = 0;

    for (const gid of groups) {
        const members = await getGroupMembersSilent(gid, ctx, msg);
        const memberIds = members.map(m => m.user_id.toString());
        for (const tqq of allTargetQQs) {
            if (memberIds.includes(tqq)) {
                ws({
                    action: "set_group_kick",
                    params: {
                        group_id: parseInt(gid),
                        user_id: parseInt(tqq)
                    }
                }, ctx, msg, null);
                countKick++;
            } else {
                countNotIn++;
            }
        }
    }

    const result = countKick > 0
        ? `✅ 已向 ${countKick} 个群/账号发出踢出指令（不在其中: ${countNotIn} 次）。`
        : `ℹ️ 该QQ及其额外账号不在群号池的任何群中。`;
    seal.replyToSender(ctx, msg, result);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["驱逐"] = cmd_kick_qq;


let cmd_admin_view_active = {};
cmd_admin_view_active.solve =(ctx, msg, cmdArgs) => {
  if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
    return seal.ext.newCmdExecuteResult(true);
  }

  let dayArg = cmdArgs.getArgN(1);
  if (!dayArg || !/^D\d+$/.test(dayArg)) {
    dayArg = cachedGet("global_days") || "D0";
  }

  const b_confirmedSchedule = kvGet("b_confirmedSchedule", {});

  // 以 group 为唯一键，防止重复
  const groupMap = {};

  for (const uid in b_confirmedSchedule) {
    for (const ev of b_confirmedSchedule[uid]) {
      if (
        ev.day === dayArg &&
        ev.status !== "ended" &&
        ev.group
      ) {
        if (!groupMap[ev.group]) {
          groupMap[ev.group] = ev.subtype || "未知";
        }
      }
    }
  }

  const entries = Object.entries(groupMap);
  if (entries.length === 0) {
    seal.replyToSender(ctx, msg, `📭 ${dayArg} 当前没有进行中的邀约`);
    return seal.ext.newCmdExecuteResult(true);
  }

  let reply = `📌 ${dayArg} 进行中的邀约：\n\n`;
  entries.forEach(([group, subtype], idx) => {
    reply += `${idx + 1}️⃣ ${getCustomTypeLabel(subtype)} ｜ 群号：${group}\n`;
  });

  seal.replyToSender(ctx, msg, reply.trim());
  return seal.ext.newCmdExecuteResult(true);
};


// ========================
// 查看所有活跃微信群（管理员）
// ========================

let cmd_view_wechat_groups = seal.ext.newCmdItemInfo();
cmd_view_wechat_groups.name = "查看微信群";
cmd_view_wechat_groups.help = "。查看微信群 —— 列出所有当前活跃的微信群（管理员专用）";

cmd_view_wechat_groups.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
        return seal.ext.newCmdExecuteResult(true);
    }

    const platform = msg.platform;
    const wechatGroups = kvGet("wechat_groups", {});
    const platformGroups = wechatGroups[platform] || {};

    const active = Object.values(platformGroups).filter(g => g.status === "active");

    if (active.length === 0) {
        seal.replyToSender(ctx, msg, "📭 当前没有活跃的微信群");
        return seal.ext.newCmdExecuteResult(true);
    }

    // 同时检查群池，标出群号是否正确处于占用状态
    const groupList = kvGet("group", []);

    let reply = `💬 当前活跃微信群（共 ${active.length} 个）：\n\n`;
    active.sort((a, b) => (a.created_timestamp || 0) - (b.created_timestamp || 0));
    active.forEach((g, idx) => {
        const inPool = groupList.includes(g.id + "_占用");
        const warn = inPool ? "" : " ⚠️[群池异常]";
        reply += `${idx + 1}. 群号：${g.id}${warn}\n`;
        reply += `   👥 ${g.participants.join("、")}\n`;
        reply += `   📅 创建：${g.created_at}\n`;
        if (g.topic) reply += `   📌 主题：${g.topic}\n`;
        reply += "\n";
    });

    seal.replyToSender(ctx, msg, reply.trim());
    return seal.ext.newCmdExecuteResult(true);
};

ext.cmdMap["查看微信群"] = cmd_view_wechat_groups;

let cmd_grouplist_release = {};

/**
 * 结束微信群（仅清理状态，不发公告）
 */
function endWechatGroup(ctx, msg, gid, platform, uid) {
    const groupList = kvGet("group", []);
    const wechatGroups = kvGet("wechat_groups", {});
    const groupInfo = wechatGroups[platform]?.[gid];
    if (!groupInfo) {
        seal.replyToSender(ctx, msg, "⚠️ 当前群不是微信群，无法结束");
        return false;
    }

    // 获取操作者角色名（仅用于记录）
    const a_private_group = kvGet("a_private_group", {});
    const userRole = a_private_group[platform]?.[uid]?.[0] || "管理员";

    // 更新群状态
    groupInfo.status = "ended";
    groupInfo.ended_at = new Date().toLocaleString("zh-CN", { timeZone: "Asia/Shanghai" });
    groupInfo.ended_by = userRole;
    wechatGroups[platform][gid] = groupInfo;
    kvSet("wechat_groups", wechatGroups);

    // 释放群号
    const groupIndex = groupList.indexOf(gid + "_占用");
    if (groupIndex !== -1) {
        groupList.splice(groupIndex, 1);
        groupList.push(gid);
        kvSet("group", groupList);
    }

    // 【新增：微信群也重置计数】
        let progress = kvGet("group_write_progress", {});
        if (progress[gid]) {
            delete progress[gid];
            kvSet("group_write_progress", progress);
        }

    // 修改群名为"备用"
    setGroupName(ctx, msg, gid, getIdleGroupName());

    // 仅向操作者反馈
    seal.replyToSender(ctx, msg, `✅ 微信群 ${gid} 已结束，群号已释放。`);
    return true;
}

cmd_grouplist_release.solve = (ctx, msg, cmdArgs) => {
    let group = kvGet("group", []);
    let platform = msg.platform;
    let gid = msg.groupId.replace(`${platform}-Group:`, "");
    const uid = msg.sender.userId.replace(`${platform}:`, "");

    // 判断是否为微信群（通过 wechat_groups 数据判断，而非后缀）
    const wechatGroups = kvGet("wechat_groups", {});
    if (wechatGroups[platform]?.[gid]?.status === "active") {
        endWechatGroup(ctx, msg, gid, platform, uid);
        return seal.ext.newCmdExecuteResult(true);
    }

    // 非微信群：原有结束逻辑
    const fullId = `${gid}_占用`;
    if (group.includes(fullId)) {
        // ----- 结束逻辑 -----
        // 将占用状态移除，使该群可复用
        group.splice(group.indexOf(fullId), 1);
        group.push(gid);
        kvSet("group", group);

        // 更新 b_confirmedSchedule 中所有 status 为 ended，并快照 V 数
        let progress = kvGet("group_write_progress", {});
        const finalProgress = progress[gid] ? { ...progress[gid] } : null;

        let b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
        let modified = false;
        let matchCount = 0;
        for (let uidKey in b_confirmedSchedule) {
            for (let ev of b_confirmedSchedule[uidKey]) {
                if (ev.group === gid && ev.status !== "ended") {
                    ev.status = "ended";
                    if (finalProgress) ev.finalProgress = finalProgress;
                    modified = true;
                    matchCount++;
                }
            }
        }
        if (modified) {
            kvSet("b_confirmedSchedule", b_confirmedSchedule);
        }

        // 重置该群的写帖进度计数
        if (progress[gid]) {
            delete progress[gid];
            kvSet("group_write_progress", progress);
        }

        // 存档必须在清除 group_expire_info 之前，否则拿不到 day/time/place
        if (isArchiveEnabled() && getSeasonMode() !== "no_review") {
            postToArchive("/api/session_end", buildSessionArchive(gid, platform, false));
        }

        // 清除到期记录（先取 subtype 供结戏奖励使用，group 号会被复用，事后从 b_confirmedSchedule 反查可能查到旧场次）
        let groupExpireInfo = kvGet("group_expire_info", {});
        const _endedSubtype = groupExpireInfo[gid]?.subtype || "";
        if (groupExpireInfo[gid]) {
            delete groupExpireInfo[gid];
            kvSet("group_expire_info", groupExpireInfo);
            console.log(`[DEBUG] 已清除群组 ${gid} 的到期记录`);
        }

        console.log(`[DEBUG] ${gid} 标记为 ended，更新 ${matchCount} 条记录`);
        seal.replyToSender(ctx, msg, `✅ 本群（${gid}）本轮小群已结束，可再次发起新小群，所有相关记录已标记"已结束"`);
        setGroupName(ctx, msg, ctx.group.groupId, getIdleGroupName());
        const _endedTimer = getGroupTimers()[gid];
        if (_endedTimer) recordPendingLeaveCheck(gid, _endedTimer.subtype, _endedTimer.participants);
        cleanupGroupTimer(gid);
        applyEndGameBonuses(ctx, msg, gid, platform, _endedSubtype);
    } else {
        seal.replyToSender(ctx, msg, `⚠️ 当前群号未处于占用状态，无法结束`);
    }

    return seal.ext.newCmdExecuteResult(true);
};

// 强结单群的核心逻辑：跳过复盘检查，是否发放结戏奖励取决于「设置 互动参数」中的「强结发放奖励」开关。
// 供「强结私约」「一键强结」「取消官约」「取消时间线」共用，不依赖调用方 ctx/msg 是否身处目标群内（仅用 ctx.endPoint 构造目标群临时上下文）。
// releaseTimeline：true 时（「取消官约」「取消时间线」用）视为这场从没真的发生过，直接删掉参与者的时间线记录，
// 让这段时间能重新约；false（「强结私约」「一键强结」用）保持原行为，只把记录标成 ended，仍占着这段时间线
// （多数强结场景是场次已经进行了一部分被打断，时间线上确实"发生过"，不该被后续预约覆盖）。
// 返回 { ok, reason?, isWechat?, rewardGranted? }
function forceEndGroupCore(ctx, msg, gid, platform, operatorUid, releaseTimeline = false) {
    const targetMsg = seal.newMessage();
    targetMsg.messageType = "group";
    targetMsg.groupId = `${platform}-Group:${gid}`;
    const targetCtx = seal.createTempCtx(ctx.endPoint, targetMsg);

    let group = kvGet("group", []);

    // 微信群：复用原有清理函数
    const wechatGroups = kvGet("wechat_groups", {});
    if (wechatGroups[platform]?.[gid]?.status === "active") {
        endWechatGroup(targetCtx, targetMsg, gid, platform, operatorUid);
        return { ok: true, isWechat: true };
    }

    const fullId = `${gid}_占用`;
    if (!group.includes(fullId)) {
        return { ok: false, reason: "未处于占用状态" };
    }

    // 释放群号
    group.splice(group.indexOf(fullId), 1);
    group.push(gid);
    kvSet("group", group);

    // 重置写帖进度
    let progress = kvGet("group_write_progress", {});
    if (progress[gid]) {
        delete progress[gid];
        kvSet("group_write_progress", progress);
    }

    // 更新 b_confirmedSchedule，同时收集参与者 uid
    const a_private_group = kvGet("a_private_group", {});
    let b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
    let modified = false;
    const participantUids = new Set();
    for (let uidKey in b_confirmedSchedule) {
        const events = b_confirmedSchedule[uidKey];
        for (let i = events.length - 1; i >= 0; i--) {
            const ev = events[i];
            if (ev.group !== gid) continue;
            participantUids.add(uidKey);
            if (releaseTimeline) {
                events.splice(i, 1); // 取消：删记录释放时间线，而不是标 ended 继续占着
            } else if (ev.status !== "ended") {
                ev.status = "ended";
            }
            modified = true;
        }
    }
    if (modified) kvSet("b_confirmedSchedule", b_confirmedSchedule);

    // 若 b_confirmedSchedule 没有记录，也尝试从 a_private_group 收集（gid 匹配者）
    if (participantUids.size === 0) {
        Object.entries(a_private_group[platform] || {}).forEach(([uid, data]) => {
            if (data[1] === gid) participantUids.add(uid);
        });
    }

    // 存档必须在清除 group_expire_info 之前，否则拿不到 day/time/place。复盘与正常结束一致，只是中途打断
    if (isArchiveEnabled() && getSeasonMode() !== "no_review") {
        postToArchive("/api/session_end", buildSessionArchive(gid, platform, true));
    }

    // 清除到期记录（先取 subtype 供结戏奖励使用，group 号会被复用，事后从 b_confirmedSchedule 反查可能查到旧场次）
    let groupExpireInfo = kvGet("group_expire_info", {});
    const _endedSubtype = groupExpireInfo[gid]?.subtype || "";
    if (groupExpireInfo[gid]) {
        delete groupExpireInfo[gid];
        kvSet("group_expire_info", groupExpireInfo);
    }

    const _forceEndTimer = getGroupTimers()[gid];
    const _forceEndNames = _forceEndTimer?.participants
        || [...participantUids].map(u => a_private_group[platform]?.[u]?.[0]).filter(Boolean);
    recordPendingLeaveCheck(gid, _forceEndTimer?.subtype, _forceEndNames);

    cleanupGroupTimer(gid);

    // 是否发放结戏奖励由「强结发放奖励」开关决定；开启时复用正常结束的奖励发放路径
    // 取消（releaseTimeline）视为这场从没真的发生过，不发结戏奖励，不看那个开关
    const rewardGranted = releaseTimeline ? false : isForceEndRewardEnabled();
    if (rewardGranted) {
        applyEndGameBonuses(targetCtx, targetMsg, gid, platform, _endedSubtype || _forceEndTimer?.subtype || "");
    } else {
        accumulateToSeasonStats(platform, gid);
        const sessionStats = getSessionStats();
        if (sessionStats[gid]) {
            delete sessionStats[gid];
            saveSessionStats(sessionStats);
        }
    }

    // 在目标群发送提示，@ 所有参与者请其退群
    const atParts = [...participantUids].map(uid => `[CQ:at,qq=${uid}]`).join(" ");
    const targetNotice = releaseTimeline
        ? (atParts ? `${atParts}\n⚠️ 本群已被管理员取消，占用的时间线已释放，请各位退群。` : `⚠️ 本群已被管理员取消，占用的时间线已释放，请各位退群。`)
        : (atParts
            ? `${atParts}\n⚠️ 本群已被管理员强制结束，${rewardGranted ? "已发放结戏奖励" : "不发放结戏奖励"}，请各位退群。`
            : `⚠️ 本群已被管理员强制结束，${rewardGranted ? "已发放结戏奖励" : "不发放结戏奖励"}，请各位退群。`);
    seal.replyToSender(targetCtx, targetMsg, targetNotice);
    setGroupName(targetCtx, targetMsg, gid, getIdleGroupName());

    return { ok: true, isWechat: false, rewardGranted };
}

// 管理员强结指令：跳过复盘检查（复盘存档流程与正常结束一致，只是中途打断），
// 是否发放结戏奖励见「设置 互动参数」中的「强结发放奖励」开关
// 用法：强结私约 [群号]  —— 不填群号则对当前群操作
const cmd_force_end = seal.ext.newCmdItemInfo();
cmd_force_end.name = "强结私约";
cmd_force_end.help = "。强结私约 [群号]（管理员专用）：强制结束指定群，不区分私约/电话/官约/踩点，任意类型都能用（不填群号则当前群）。场次视为「发生过、只是被打断」，参与者这段时间线仍会被占着，不能重新约同一时段；是否发放结戏奖励见「设置 互动参数」的「强结发放奖励」开关，并在目标群 @ 成员提示退群。如果这场从没真的发生、想连时间线一起释放，用「取消官约」/「取消时间线」。";
function buildForceEndSolve(releaseTimeline) {
    return (ctx, msg, cmdArgs) => {
        if (!isUserAdmin(ctx, msg)) {
            seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
            return seal.ext.newCmdExecuteResult(true);
        }

        const platform = msg.platform;
        const argGid = (cmdArgs.getArgN(1) || "").trim();
        const gid = argGid || msg.groupId.replace(`${platform}-Group:`, "");
        const isRemote = !!argGid; // 是否在外部群操作
        const operatorUid = msg.sender.userId.replace(`${platform}:`, "");

        const result = forceEndGroupCore(ctx, msg, gid, platform, operatorUid, releaseTimeline);
        if (!result.ok) {
            seal.replyToSender(ctx, msg, `⚠️ 群号 ${gid} ${result.reason}，无法${releaseTimeline ? "取消" : "结束"}`);
            return seal.ext.newCmdExecuteResult(true);
        }

        // 向发令者确认（在外部群操作时才需要额外回复，在目标群操作时目标群已有消息）
        if (isRemote) {
            const suffix = result.isWechat
                ? `已${releaseTimeline ? "取消" : "强结"}微信群 ${gid}。`
                : releaseTimeline
                    ? `群 ${gid} 已取消，占用的时间线已释放，已在目标群通知成员退群。`
                    : `群 ${gid} 已强制结束，已在目标群通知成员退群（${result.rewardGranted ? "已发放" : "未发放"}结戏奖励）。`;
            seal.replyToSender(ctx, msg, `✅ ${suffix}`);
        }

        return seal.ext.newCmdExecuteResult(true);
    };
}
cmd_force_end.solve = buildForceEndSolve(false);
ext.cmdMap["强结私约"] = cmd_force_end;

// 「取消官约」/「取消时间线」：跟「强结私约」共用同一套底层逻辑，唯一区别是 releaseTimeline=true——
// 这场视为从没真的发生过，直接删掉参与者的时间线记录（而不是标 ended 继续占着），让这段时间能重新约，也不发结戏奖励
const cmd_cancel_timeline = seal.ext.newCmdItemInfo();
cmd_cancel_timeline.name = "取消官约";
cmd_cancel_timeline.help = "。取消官约 [群号]（管理员专用，别名「取消时间线」）：取消指定群，不区分私约/电话/官约/踩点，任意类型都能用（不填群号则当前群）。跟「强结私约」的区别：这场视为从没真的发生过，会释放参与者占用的这段时间线，让这个时段能重新约，也不发结戏奖励。如果场次其实已经进行了一部分、只是被打断，想保留这段时间线的占用，请用「强结私约」。";
cmd_cancel_timeline.solve = buildForceEndSolve(true);
ext.cmdMap["取消官约"] = cmd_cancel_timeline;
ext.cmdMap["取消时间线"] = cmd_cancel_timeline;

// ========================
// 🚨 一键通知 / 一键强结：按「弧长」（单人未回复时长）或「开群」（群开启时长）批量筛选
// ========================

// 弧长口径：group_timers 中处于 timing 状态（即对方在等这个人回复）且已超阈值的参与者
function collectOverdueByArcLength(timers, thresholdMs) {
    const now = Date.now();
    const result = [];
    for (const [gid, timer] of Object.entries(timers)) {
        for (const [name, s] of Object.entries(timer.timerStatus || {})) {
            if (s.status !== "timing") continue;
            const elapsed = now - s.startTime;
            if (elapsed >= thresholdMs) result.push({ gid, timer, name, s, elapsed });
        }
    }
    return result;
}

function collectOverdueGidsByArcLength(thresholdMs) {
    const timers = kvGet("group_timers", {});
    const gids = new Set(collectOverdueByArcLength(timers, thresholdMs).map(e => e.gid));
    return [...gids];
}

// 开群口径：group_expire_info 中距“开群时刻”已超阈值的群。
// 所有建群路径均已记录 acceptTime；此处兜底仅用于本次改动前创建、库里还没有 acceptTime 字段的老群，
// 用 expireTime 反推（expireTime = 开群时刻 + 当时的小群过期时间设置），期间若调整过“小群过期时间”会有偏差
function getGroupOpenedAt(info) {
    if (info.acceptTime) return info.acceptTime;
    return info.expireTime - getStorageInt("group_expire_hours", 48) * 3600000;
}

function collectOverdueByOpenDuration(thresholdMs) {
    const infoMap = kvGet("group_expire_info", {});
    const now = Date.now();
    const result = [];
    for (const [gid, info] of Object.entries(infoMap)) {
        const elapsed = now - getGroupOpenedAt(info);
        if (elapsed >= thresholdMs) result.push({ gid, info, elapsed });
    }
    return result;
}

// 拼出「日期 时间 地点」标签，取不到详情（如群已到期被清理）时兜底回退成纯类型标签
function getOverdueScheduleTimeLabel(timer, gid) {
    const info = kvGet("group_expire_info", {})[gid];
    if (!info || !info.day || !info.time) return getCustomTypeLabel(timer.subtype);
    return [info.day, info.time, info.place].filter(Boolean).join(" ");
}

// 弧长通知：公共群里 @ 提示大家耐心等待的部分，每群单独发，不受个人合并转发影响
function sendOverdueGroupNotice(ctx, timer, gid, name, timeStr) {
    const platform = timer.platform;
    const roleUid2 = getUidByRoleName(platform, name);
    const extras2 = kvGet("extra_accounts", {});
    const allAtUids = roleUid2 && !/^npc_/.test(roleUid2)
        ? [roleUid2, ...Object.entries(extras2)
            .filter(([k, v]) => k.startsWith(`${platform}:`) && v === roleUid2)
            .map(([k]) => k.replace(`${platform}:`, ""))]
        : [];
    const atStr2 = allAtUids.map(u => `[CQ:at,qq=${u}]`).join("") + (allAtUids.length ? "\n" : "");
    const m2 = seal.newMessage(); m2.messageType = "group"; m2.groupId = `${platform}-Group:${gid}`;
    seal.replyToSender(seal.createTempCtx(ctx.endPoint, m2), m2, `${atStr2}🌷 温馨提示：${name} 已经忙碌 ${timeStr} 啦，我们再耐心等一下ta吧～`);
}

// 私聊提醒未回复的人：按人归拢后统一发——只有 1 个超时群时跟原来一样直接发一条；
// 2 个及以上时先发一条汇总（几个超时群/平均超时时长），再把逐条详情合并转发，避免同一个人的小群被刷屏
function flushPersonalOverdueNotices(ctx, platform, pGid, name, entries) {
    if (!pGid || !entries.length) return;
    const m1 = seal.newMessage(); m1.messageType = "group"; m1.groupId = `${platform}-Group:${pGid}`;
    const pCtx = seal.createTempCtx(ctx.endPoint, m1);

    if (entries.length === 1) {
        const { partnerLabel, timeLabel, timeStr } = entries[0];
        const text = `✨ 亲爱的 ${name}，${partnerLabel}在「${timeLabel}」的约会等你 ${timeStr} 啦。如果不忙的话，记得回一下小伙伴们哦～ ❤️`;
        seal.replyToSender(pCtx, m1, text);
        return;
    }

    const avgMs = entries.reduce((sum, e) => sum + e.elapsed, 0) / entries.length;
    const avgH = Math.floor(avgMs / 3600000), avgM = Math.floor((avgMs % 3600000) / 60000);
    const avgStr = avgH > 0 ? `${avgH}h${avgM}m` : `${avgM}m`;
    seal.replyToSender(pCtx, m1, `✨ 亲爱的 ${name}，你有 ${entries.length} 个超时群在等你回复，平均超时 ${avgStr} 啦，记得抽空看看哦～ ❤️`);

    const botUid = ctx.endPoint.userId;
    const gidInt = parseInt(String(pGid).replace(/[^\d]/g, ""), 10);
    const nodes = entries.map(({ partnerLabel, timeLabel, timeStr }) => ({
        type: "node",
        data: { name, uin: botUid, content: `📍 ${timeLabel}\n👥 ${partnerLabel}\n⏱️ 已等待 ${timeStr}` }
    }));
    ws({ action: "send_group_forward_msg", params: { group_id: gidInt, messages: nodes } }, pCtx, m1, "");
}

// 一轮超时提醒的批量入口：entries 为 { gid, timer, name, s, elapsed } 列表。
// 公共群 @ 提示照旧逐条即发；私聊提醒先按人分组，再交给 flushPersonalOverdueNotices 统一处理
function processOverdueBatch(ctx, entries) {
    const priv = kvGet("a_private_group", {});
    const byPerson = new Map();

    entries.forEach(({ gid, timer, name, s, elapsed }) => {
        const platform = timer.platform;
        const h = Math.floor(elapsed / 3600000), m = Math.floor((elapsed % 3600000) / 60000);
        const timeStr = h > 0 ? `${h}h${m}m` : `${m}m`;

        sendOverdueGroupNotice(ctx, timer, gid, name, timeStr);

        const others = (timer.participants || []).filter(p => p !== name);
        const partnerLabel = others.length ? others.join("、") : "大家";
        const timeLabel = getOverdueScheduleTimeLabel(timer, gid);
        const roleUid = getUidByRoleName(platform, name);
        const pGid = roleUid ? priv[platform]?.[roleUid]?.[1] : null;
        if (pGid) {
            const key = `${platform}:${pGid}:${name}`;
            if (!byPerson.has(key)) byPerson.set(key, { platform, pGid, name, entries: [] });
            byPerson.get(key).entries.push({ partnerLabel, timeLabel, timeStr, elapsed });
        }

        s.remindedTimes = (s.remindedTimes || 0) + 1;
    });

    byPerson.forEach(({ platform, pGid, name, entries: personEntries }) => {
        flushPersonalOverdueNotices(ctx, platform, pGid, name, personEntries);
    });
}

function parseBatchThresholdArgs(cmdArgs) {
    const hours = parseFloat(cmdArgs.getArgN(1));
    const typeArg = (cmdArgs.getArgN(2) || "").trim();
    if (isNaN(hours) || hours <= 0 || !["弧长", "开群"].includes(typeArg)) return null;
    return { hours, typeArg, thresholdMs: hours * 3600000 };
}

let cmd_batch_notify = seal.ext.newCmdItemInfo();
cmd_batch_notify.name = "一键通知";
cmd_batch_notify.help = "。一键通知 <小时数> 弧长|开群（管理员专用）\n弧长：通知所有存在单人已超过N小时未回复的群（私聊提醒未回复者，群内@提示大家耐心等待，两边话术不同）\n开群：向所有已开启超过N小时的群发送到期提醒\n例：一键通知 12 弧长";
cmd_batch_notify.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
        return seal.ext.newCmdExecuteResult(true);
    }

    const parsed = parseBatchThresholdArgs(cmdArgs);
    if (!parsed) {
        seal.replyToSender(ctx, msg, "❌ 用法：一键通知 <小时数> 弧长|开群\n例：一键通知 12 弧长");
        return seal.ext.newCmdExecuteResult(true);
    }
    const { hours, typeArg, thresholdMs } = parsed;

    if (typeArg === "弧长") {
        const timers = kvGet("group_timers", {});
        const overdue = collectOverdueByArcLength(timers, thresholdMs);
        if (!overdue.length) {
            seal.replyToSender(ctx, msg, `🌙 没有单人超时 ${hours} 小时以上未回的群。`);
            return seal.ext.newCmdExecuteResult(true);
        }
        processOverdueBatch(ctx, overdue);
        const detail = overdue.map(({ gid, name }) => `群${gid}：${name}`);
        kvSet("group_timers", timers);
        seal.replyToSender(ctx, msg, `💖 已通知 ${overdue.length} 处超时（弧长 ≥${hours}h）：\n${detail.join("\n")}`);
    } else {
        const overdue = collectOverdueByOpenDuration(thresholdMs);
        if (!overdue.length) {
            seal.replyToSender(ctx, msg, `🌙 没有开群超过 ${hours} 小时的群。`);
            return seal.ext.newCmdExecuteResult(true);
        }
        let successCount = 0, failCount = 0;
        overdue.forEach(({ gid, info }) => {
            try {
                const groupMsg = seal.newMessage();
                groupMsg.messageType = "group";
                groupMsg.groupId = `${msg.platform}-Group:${gid}`;
                const groupCtx = seal.createTempCtx(ctx.endPoint, groupMsg);
                const reminderMsg = `⏰ 温馨提示：\n本群已开启超过 ${hours} 小时啦～\n\n📋 群号：${gid}\n• 时间：${info.day || ""} ${info.time || ""}\n• 地点：${info.place || ""}\n\n如果互动已结束，请使用「结束私约」`;
                seal.replyToSender(groupCtx, groupMsg, reminderMsg);
                successCount++;
            } catch (e) {
                failCount++;
            }
        });
        seal.replyToSender(ctx, msg, `📢 开群超时提醒完成（≥${hours}h）！\n✅ 成功：${successCount}\n❌ 失败：${failCount}`);
    }
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["一键通知"] = cmd_batch_notify;

let cmd_batch_force_end = seal.ext.newCmdItemInfo();
cmd_batch_force_end.name = "一键强结";
cmd_batch_force_end.help = "。一键强结 <小时数> 弧长|开群（管理员专用）\n弧长：强制结束所有存在单人已超过N小时未回复的群\n开群：强制结束所有已开启超过N小时的群\n是否发放结戏奖励见「设置 互动参数」的「强结发放奖励」开关\n例：一键强结 12 开群";
cmd_batch_force_end.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
        return seal.ext.newCmdExecuteResult(true);
    }

    const parsed = parseBatchThresholdArgs(cmdArgs);
    if (!parsed) {
        seal.replyToSender(ctx, msg, "❌ 用法：一键强结 <小时数> 弧长|开群\n例：一键强结 12 开群");
        return seal.ext.newCmdExecuteResult(true);
    }
    const { hours, typeArg, thresholdMs } = parsed;

    const platform = msg.platform;
    const operatorUid = msg.sender.userId.replace(`${platform}:`, "");
    const gids = typeArg === "弧长" ? collectOverdueGidsByArcLength(thresholdMs) : collectOverdueByOpenDuration(thresholdMs).map(e => e.gid);

    if (!gids.length) {
        seal.replyToSender(ctx, msg, `🌙 没有符合「${typeArg} ≥${hours}h」条件的群。`);
        return seal.ext.newCmdExecuteResult(true);
    }

    const succeeded = [], failed = [];
    gids.forEach(gid => {
        const result = forceEndGroupCore(ctx, msg, gid, platform, operatorUid);
        if (result.ok) succeeded.push(gid); else failed.push(`${gid}(${result.reason})`);
    });

    let report = `✅ 一键强结完成（${typeArg} ≥${hours}h）\n成功 ${succeeded.length} 个${succeeded.length ? "：" + succeeded.join("、") : ""}`;
    if (failed.length) report += `\n失败 ${failed.length} 个：${failed.join("、")}`;
    seal.replyToSender(ctx, msg, report);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["一键强结"] = cmd_batch_force_end;

// 修改玩家群号（按 uid 直接替换 a_private_group 中的 gid）
let cmd_edit_player_group = seal.ext.newCmdItemInfo();
cmd_edit_player_group.name = "修改玩家群号";
cmd_edit_player_group.help = "。修改玩家群号 QQ号 新群号\n直接修改该玩家登记的私约群号";
cmd_edit_player_group.solve = (ctx, msg, cmdArgs) => {
    if (!msg.isMaster && !isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, `此指令仅限骰主或管理员使用`);
        return seal.ext.newCmdExecuteResult(true);
    }
    const uidArg = (cmdArgs.getArgN(1) || "").trim();
    const newGid = (cmdArgs.getArgN(2) || "").trim();
    if (!uidArg || !newGid) { const r = seal.ext.newCmdExecuteResult(true); r.showHelp = true; return r; }
    if (!/^\d+$/.test(newGid)) {
        seal.replyToSender(ctx, msg, `❌ 新群号必须为纯数字`);
        return seal.ext.newCmdExecuteResult(true);
    }
    const platform = ctx.platform || "QQ";
    const uid = uidArg.replace(`${platform}:`, "");
    const apg = kvGet("a_private_group", {});
    if (!apg[platform] || !apg[platform][uid]) {
        seal.replyToSender(ctx, msg, `❌ 未找到 ${uidArg} 的登记信息`);
        return seal.ext.newCmdExecuteResult(true);
    }
    const roleName = apg[platform][uid][0];
    const oldGid = apg[platform][uid][1];
    apg[platform][uid][1] = newGid;
    kvSet("a_private_group", apg);
    seal.replyToSender(ctx, msg, `✅ 已将「${roleName}」（${uidArg}）的群号从 ${oldGid || "空"} 改为 ${newGid}`);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["修改玩家群号"] = cmd_edit_player_group;

/**
 * 检查指定群号中是否有非NPC的已绑定角色（异步，返回 Promise）
 * @param {string} platform - 平台标识
 * @param {string} gid - 群号（纯数字字符串）
 * @param {Object} ctx - 上下文
 * @param {Object} msg - 原始消息对象
 * @returns {Promise<boolean>} - true: 有非NPC玩家, false: 无
 */
async function checkGroupHasNonNPC(platform, gid, ctx, msg) {
    const members = await getGroupMembersSilent(gid, ctx, msg);
    console.log(`[checkGroupHasNonNPC] 群 ${gid} 获取到成员数: ${members.length}`);
    
    const roleStorage = getRoleStorage();
    const platformRoles = roleStorage[platform] || {};
    const npcList = kvGet("a_npc_list", []);
    
    // --- 1. 读取 noquit 存储 ---
    // 结构预期: { "12345": ["10001", "10002"], "789012": ["10001"] }
    const noquitRecord = kvGet("noquit", {});
    let needSave = false;

    // 构建 QQ -> 角色信息的映射
    const qqToRole = {};
    for (let [uid, info] of Object.entries(platformRoles)) {
        const roleName = info[0];
        if (roleName) qqToRole[uid] = { uid, name: roleName, isNPC: npcList.includes(roleName) };
    }

    let hasNonNPC = false;
    for (let member of members) {
        const qq = member.user_id.toString();
        const role = qqToRole[qq];

        if (role && !role.isNPC) {
            hasNonNPC = true;
            const groupId = platformRoles[role.uid]?.[1];
            if (groupId) {
                // 初始化记录
                if (!noquitRecord[qq]) noquitRecord[qq] = [];

                // 新增群号
                if (!noquitRecord[qq].includes(gid)) {
                    noquitRecord[qq].push(gid);
                    needSave = true;
                    console.log(`[NoQuit] 记录玩家 ${qq} 在群 ${gid} 未退出 (累计群数: ${noquitRecord[qq].length})`);
                }

                const count = noquitRecord[qq].length;

                const remindMsg = seal.newMessage();
                remindMsg.messageType = "group";
                remindMsg.groupId = `${platform}-Group:${groupId}`;
                const remindCtx = seal.createTempCtx(ctx.endPoint, remindMsg);
                seal.replyToSender(remindCtx, remindMsg,
                    `[CQ:at,qq=${qq}] ⚠️ 系统检测到群 ${gid} 将用于私密邀约/心愿等自动建群，请尽快退出，否则可能影响后续流程。（累计未退：${count}）`);
            }
        }
    }
    
    // --- 3. 如果有变动，写入存储 ---
    if (needSave) {
        kvSet("noquit", noquitRecord);
    }

    console.log(`[checkGroupHasNonNPC] 有非NPC玩家: ${hasNonNPC}`);
    return hasNonNPC;
}

/**
 * 分配一个未被占用且群成员中没有非NPC玩家的群号（异步）
 * @param {string} platform - 平台标识
 * @param {Object} ctx - 上下文
 * @param {Object} msg - 原始消息对象
 * @returns {Promise<string|null>} - 分配的群号，若无可用则返回 null
 */
async function allocateGroup(platform, ctx, msg) {
    let groupList = kvGet("group", []);
    let freeGroups = groupList.filter(g => !g.endsWith("_占用"));
    if (freeGroups.length === 0) return null;

    // 随机打乱顺序
    for (let i = freeGroups.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [freeGroups[i], freeGroups[j]] = [freeGroups[j], freeGroups[i]];
    }

    for (let gid of freeGroups) {
        // 先抢占（重新读取防止并发后已被占用），再检查群内成员
        const gl = kvGet("group", []);
        if (!gl.includes(gid)) continue; // 已被其他并发调用占走
        kvSet("group", gl.map(g => g === gid ? gid + "_占用" : g));

        const hasNonNPC = await checkGroupHasNonNPC(platform, gid, ctx, msg);
        if (!hasNonNPC) {
            return gid;
        }
        // 群内有非NPC玩家，释放占用后继续找下一个
        const gl2 = kvGet("group", []);
        kvSet("group", gl2.map(g => g === gid + "_占用" ? gid : g));
    }
    return null;
}

/**
 * 校验并清理 noquit 记录（增强版：增加 NPC 身份自动赦免）
 * @param {string} qq - 玩家QQ号
 * @param {Object} ctx - 上下文
 * @param {Object} msg - 消息对象
 * @returns {Promise<boolean>} - true: 干净/已退出/已转为NPC, false: 仍卡在群里
 */
async function validateAndCleanNoQuit(qq, ctx, msg) {
    const noquitRecord = kvGet("noquit", {});
    
    // 1. 如果该玩家本来就没有记录，直接放行
    if (!noquitRecord[qq] || noquitRecord[qq].length === 0) {
        return true;
    }

    // --- 核心优化：NPC 身份检查 ---
    const platform = msg.platform;
    const roleStorage = getRoleStorage();
    const platformRoles = roleStorage[platform] || {};
    const npcList = kvGet("a_npc_list", []);

    // 新结构：a_private_group[platform][uid] = [roleName, gid]，直接查
    const roleName = platformRoles[qq]?.[0] || null;

    // 如果该角色现在被标记为了 NPC，直接清空其违规记录并放行
    if (roleName && npcList.includes(roleName)) {
        console.log(`[NoQuit] 检测到玩家 ${roleName}(${qq}) 已转为 NPC，自动清空违规记录。`);
        delete noquitRecord[qq];
        kvSet("noquit", noquitRecord);
        return true;
    }
    // ----------------------------

    const stillInGroups = []; // 记录玩家仍然在里面的群号

    // 2. 正常的退群校验逻辑
    for (let gid of noquitRecord[qq]) {
        try {
            const members = await getGroupMembersSilent(gid, ctx, msg);
            const isMember = members.some(m => m.user_id.toString() === qq);
            if (isMember) {
                stillInGroups.push(gid);
            }
        } catch (e) {
            // 获取失败视为已退出
        }
    }

    // 3. 更新存储
    if (stillInGroups.length === 0) {
        delete noquitRecord[qq];
        kvSet("noquit", noquitRecord);
        return true; 
    } else if (stillInGroups.length < noquitRecord[qq].length) {
        noquitRecord[qq] = stillInGroups;
        kvSet("noquit", noquitRecord);
        return false;
    }
    
    return false;
}

/**
 * 封装的 NoQuit 检查拦截器
 * 如果玩家还在违规群中，直接回复并阻止操作
 * @param {string} qq - 玩家ID
 * @param {Object} ctx - 上下文
 * @param {Object} msg - 消息对象
 * @returns {Promise<boolean>} - true: 放行, false: 已拦截
 */
async function checkNoQuitBlocker(qq, ctx, msg) {
    const isClean = await validateAndCleanNoQuit(qq, ctx, msg);
    if (!isClean) {
        seal.replyToSender(ctx, msg, `🚫 检测到您仍有未退出的临时房间，请退出后再试。`);
        return false;
    }
    return true;
}

let cmd_fix_noquit = seal.ext.newCmdItemInfo();
cmd_fix_noquit.name = "更新未退群";
cmd_fix_noquit.solve = async (ctx, msg, cmdArgs) => {
    const platform = msg.platform;
    const roles = (getRoleStorage()[platform] || {});
    const npcs = kvGet("a_npc_list", []);
    const extras = kvGet("extra_accounts", {});

    const arg1 = cmdArgs.getArgN(1);
    // 检查是否包含"驱逐"参数
    const shouldKick = arg1 === "驱逐";
    // 进行中模式：清空所有非NPC的noquit，只扫描未占用的群
    const isInProgress = arg1 === "进行中";

    // 根据主账号 uid 获取其所有额外账号 QQ 列表
    const getExtraQQs = (primaryQQ) => Object.entries(extras)
        .filter(([k, v]) => k.startsWith(`${platform}:`) && v === primaryQQ)
        .map(([k]) => k.replace(`${platform}:`, ""));

    if (isInProgress) {
        seal.replyToSender(ctx, msg, "🔍 进行中模式：正在清空非NPC未退群记录并扫描空闲群...");

        const rawGroups = kvGet("group", []);
        // 只扫描未占用的群（跳过含 _占用 后缀的）
        const freeGroups = rawGroups.filter(g => !g.endsWith("_占用"));

        // 清空所有非NPC玩家的 noquit 记录
        const noquit = kvGet("noquit", {});
        for (const qq of Object.keys(noquit)) {
            const roleName = roles[qq]?.[0];
            if (roleName && !npcs.includes(roleName)) {
                delete noquit[qq];
            }
        }

        let countUpdate = 0;
        for (let gid of freeGroups) {
            const members = await getGroupMembersSilent(gid, ctx, msg);
            for (let m of members) {
                const qq = m.user_id.toString();
                const roleName = roles[qq]?.[0];
                if (roleName && !npcs.includes(roleName)) {
                    if (!noquit[qq]) noquit[qq] = [];
                    if (!noquit[qq].includes(gid)) {
                        noquit[qq].push(gid);
                        countUpdate++;
                    }
                }
            }
        }

        kvSet("noquit", noquit);
        seal.replyToSender(ctx, msg, `✅ 进行中扫描完成！\n已清空并重建非NPC未退群记录\n空闲群扫描新增: ${countUpdate} 条记录`);
        return seal.ext.newCmdExecuteResult(true);
    }

    seal.replyToSender(ctx, msg, "🔍 正在扫描全服...");

    const groups = kvGet("group", []).map(g => g.replace(/_占用$/, ""));
    const noquit = kvGet("noquit", {});

    let countUpdate = 0; // 新增记录数
    let countKick = 0;   // 尝试踢人计数

    // 遍历所有群
    for (let gid of groups) {
        const members = await getGroupMembersSilent(gid, ctx, msg);
        for (let m of members) {
            const qq = m.user_id.toString();
            // 找角色名（新结构 key=uid，value[0]=roleName）
            const roleName = roles[qq]?.[0];

            // 如果是玩家且不是NPC
            if (roleName && !npcs.includes(roleName)) {
                if (!noquit[qq]) {
                    noquit[qq] = [];
                }
                if (!noquit[qq].includes(gid)) {
                    noquit[qq].push(gid);
                    countUpdate++;
                }

                // 驱逐模式：本次扫描到还在群里就踢出（含额外账号）
                if (shouldKick) {
                    const allKickQQs = [qq, ...getExtraQQs(qq)];
                    for (const kqq of allKickQQs) {
                        try {
                            await ws({
                                action: "set_group_kick",
                                params: {
                                    group_id: parseInt(gid),
                                    user_id: parseInt(kqq)
                                }
                            }, ctx, msg, null);
                            countKick++;
                        } catch (e) {
                            console.error(`[踢人] 发送指令失败:`, e);
                        }
                    }
                }
            }
        }
    }

    // 只有数据有变更才保存
    if (countUpdate > 0) {
        kvSet("noquit", noquit);
    }

    // 根据模式回复不同的消息
    if (shouldKick) {
        seal.replyToSender(ctx, msg, `✅ 扫描并驱逐完成！\n新增记录: ${countUpdate} 人\n执行踢出: ${countKick} 人`);
    } else {
        seal.replyToSender(ctx, msg, `✅ 扫描完成，新增 ${countUpdate} 条违规记录。(如需驱逐请加"驱逐"参数)`);
    }

    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["更新未退群"] = cmd_fix_noquit;

// ========================
// 🗑️ 清空季度数据
// ========================
// 「清空季度数据」要清空的全部本地存储 key（仅保留 a_adminList / adminPassword）。
// 提到顶层常量，方便 check_clear_keys_coverage.py 之类的脚本静态核对：
// 凡是代码里 kvGet/kvSet/cachedGet/cachedSet 写过的季度相关 key，理论上都该出现在这里，
// 否则清空季度时会漏清（这份清单历史上已经因为漏加新 key 出过至少两次 bug）。
const CLEAR_KEYS = [
    // ── 角色 / 季度 ──
    "a_private_group",       "a_npc_list",            "a_generic_npc_list",
    "a_lockedSlots",
    "a_wishPool",            "a_quick_official_plan", "extra_accounts",
    "feature_user_blocklist","noquit",                "season_show_name",
    "season_mode",           "season_schedule_start", "season_schedule_end",
    "season_supplement_end", "season_created_at",     "love_show_name",
    // ── 约会 / 日程 ──
    "appointmentList",       "b_MultiGroupRequest",   "b_confirmedSchedule",
    "join_request_list",     "allowed_appointment_times",
    "appointment_coin_cost", "appointment_duration_config",
    "auto_merge_duplicate_private","enable_join_existing_appointment",
    "group",                 "group_expire_info",     "group_timers",
    "group_session_stats",   "group_write_progress",  "pending_leave_check",
    "fupan_routing_enabled", "fupan_routing_groups",
    // ── 统计 / 计数 ──
    "interaction_counts",    "user_stats",            "global_days",
    "season_player_stats",   "auto_day_reset_enabled","auto_day_last_reset",
    "global_gift_cooldowns", "global_gift_stats",
    "global_chaos_letter_counts",    "drift_bottles",
    "pretel_list",            "pretel_picks",          "pretel_mode",           "pretel_collection",
    "pretel_show_gender",
    "lovemail_day_counts",   "lovemail_pool",
    "letter_day_counts",     "wish_daily_post_counts","wish_daily_pick_counts",
    "a_meetingCount_call",   "a_meetingCount_chaosletter",
    "a_meetingCount_directletter", "a_meetingCount_gift",
    "a_meetingCount_letter", "a_meetingCount_lovemail",
    "a_meetingCount_official","a_meetingCount_private",
    "a_meetingCount_secretletter","a_meetingCount_wish",
    "a_meetingCount_relation",
    // ── 角色属性 / 档案 ──
    "sys_char_profiles",     "sys_character_attrs",   "sys_attr_presets",
    "rpg_attr_defs",
    // ── 物品 / 背包 / 商城 ──
    "item_registry",         "item_currencies",       "item_usage_log",
    "global_inventories",    "player_draw_records",   "player_equipments",
    "player_pity_counters",  "player_level",          "player_level_history",
    "shop_listings",         "secondhand_market",     "market_config",
    "pool_definitions",      "pool_draw_config",      "pool_schemas",       "presets",
    "craft_recipes",         "attack_defense_config", "attack_defense_data",
    "equipment_config",      "equipment_registry",    "equipment_slots",
    "equipment_slot_names",  "level_up_rules",        "max_level",
    // ── 道具效果 ──
    "phone_tap_effects",     "sms_tap_effects",       "sms_echo_wall_effects",
    "letter_quill_pen_effects","letter_telescope_effects","letter_pending_quill_pens",
    "apply_item_expose_rate","apply_item_hours",      "apply_item_notification",
    "item_tracker_show_partner","item_tracker_success_rate","item_tracker_time_restrict",
    // ── 礼品店 ──
    "preset_gifts",          "gift_sightings",        "shop_personal_display",
    "shop_refresh_hours",    "shop_gift_catalog_on_receive",
    "sighting_daily_count",  "sighting_system_config",
    // ── 拍卖 ──
    "auction_items",         "auction_allow_anon",    "auction_broadcast",
    "auction_currency",      "auction_show_top_bidder",
    // ── 地点 ──
    "available_places",      "place_keys",            "place_system_config",
    // ── 信件 / 心动信 ──
    "lovemail_default_limit","lovemail_day_limits",   "lovemail_delivery_time",
    "lovemail_expose",       "lovemail_expose_chance","letter_public_send",
    "allow_custom_letter_sign","chaos_letter_config", "mailCooldown",
    "direct_letter_cooldown","direct_letter_daily_limit","direct_letter_min_chars",
    "direct_letter_reward",
    // ── 礼物 ──
    "gift_public_send",      "allow_custom_gift_sign","drop_hide_receiver",
    "giftCooldown",          "giftDailyLimit",        "giftMode",
    "giftPublicChance",
    // ── 心愿 ──
    "wish_bounty_enabled",   "wish_coin_cost",        "wish_public_send",
    "wish_max_concurrent",   "wish_daily_post_limit", "wish_daily_pick_limit",
    // ── 关系线 ──
    "relationship_lines",    "relationship_system_enabled",
    "max_relationships_per_user","max_detail_chars",
    "max_detail_count",      "max_rel_total_chars",  "forward_split_threshold",
    // ── 社交 / 论坛 / 晚餐 ──
    "forum_posts",           "forum_max_length",      "dinner_system_data",
    "wechat_groups",
    // ── 收集 / 写帖 ──
    "sys_info_collection",   "sys_info_projects",     "projects",
    "sys_info_private_projects",
    // ── Binary Tag / 目击 ──
    "sys_binary_tags",
    // ── 时段窗口配置 ──
    "ts_allowed_durations",  "ts_blocked_by_day",     "ts_feature_windows",
    "ts_strict_hour_match",
    // ── 临时数据（点歌/审计中转）──
    "temp_audit_owner",      "temp_song_dgr",         "temp_song_ly",
    "temp_source_group_name","temp_target_gid",       "temp_task_type",
    // ── 系统设置 ──
    "global_feature_toggle", "custom_message_templates",
    "allow_private_rooms",   "announceFrequency",     "monitor_settings",
    "background_group_id",   "song_group_id",         "adminAnnounceGroupId",
    "end_game_bonus_templates","end_game_draw_config",
    "end_season_report_enabled","group_expire_hours", "idle_group_name",
];

let cmd_reset_season_data = seal.ext.newCmdItemInfo();
cmd_reset_season_data.name = "清空季度数据";
cmd_reset_season_data.help = `用法：。清空季度数据 [确认]
扫描所有群，确认无玩家残留后清空本季度全部玩家数据。
加「确认」参数可跳过残留检查，强制清空。`;
cmd_reset_season_data.solve = async (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
        return seal.ext.newCmdExecuteResult(true);
    }

    const force = (cmdArgs.getArgN(1) || "").trim() === "确认";
    const platform = msg.platform;
    const roles = getRoleStorage()[platform] || {};
    const npcs = kvGet("a_npc_list", []);
    const groups = kvGet("group", []).map(g => g.replace(/_占用$/, ""));

    if (!force) {
        seal.replyToSender(ctx, msg, "🔍 正在扫描各群残留玩家，请稍候…");
        const remaining = [];
        for (const gid of groups) {
            const members = await getGroupMembersSilent(gid, ctx, msg);
            for (const m of members) {
                const qq = m.user_id.toString();
                const roleName = roles[qq]?.[0];
                if (roleName && !npcs.includes(roleName)) {
                    if (!remaining.find(r => r.qq === qq)) {
                        remaining.push({ name: roleName, qq });
                    }
                }
            }
        }
        if (remaining.length > 0) {
            const list = remaining.map(r => `· ${r.name}（${r.qq}）`).join("\n");
            seal.replyToSender(ctx, msg,
                `⚠️ 以下 ${remaining.length} 名玩家仍在群内，请先执行「更新未退群 驱逐」再清空：\n${list}\n\n` +
                `如需跳过检查强制清空，发送「。清空季度数据 确认」`
            );
            return seal.ext.newCmdExecuteResult(true);
        }
    }

    // 存档同步：清空前先把所有仍标记为进行中的场次在存档端标记结束，否则网页端「当前占用群」
    // 会永远停留在清空前的最后一批数据（清空只动本地存储，不会通知存档服务器关闭这些场次）
    if (isArchiveEnabled() && getSeasonMode() !== "no_review") {
        const stillOpenGroups = kvGet("group_expire_info", {});
        for (const gid of Object.keys(stillOpenGroups)) {
            try {
                postToArchive("/api/session_end", buildSessionArchive(gid, platform, true));
            } catch (e) {
                console.error(`[清空季度数据] 存档同步群 ${gid} 结束状态失败: ${e.message}`);
            }
        }
    }

    // 清空全部数据（仅保留 a_adminList / adminPassword）——具体清单见文件顶部的 CLEAR_KEYS 常量
    for (const key of CLEAR_KEYS) {
        cachedSet(key, "");
    }

    // changriRPG 自有存储
    const rpgExt = seal.ext.find("changriRPG");
    if (rpgExt) rpgExt.storageSet("scheduled_collections", "");

    // 长日晚餐自有存储（数据存在 dinner_system 命名空间，不在 changri 里）
    const dinnerExt = seal.ext.find("dinner_system");
    if (dinnerExt) {
        for (const k of ["dinner_system_data", "guard_game_state", "guard_game_locations"]) {
            dinnerExt.storageSet(k, "");
        }
    }

    seal.replyToSender(ctx, msg,
        `✅ 季度数据已全量清空\n仅保留：管理员列表、密令。\n\n` +
        `现在可以执行：\n。创建新季度 恋综名 复盘/不复盘 MMDD-MMDD`
    );
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["清空季度数据"] = cmd_reset_season_data;

// --- 辅助提取：统一的角色信息获取 ---
const getRoleDetails = (platform, name) => {
    // name is a roleName; look up the uid first, then get gid
    const privateGroups = kvGet("a_private_group", {});
    const uid = getUidByRoleName(platform, name);
    if (!uid) return { uid: null, gid: null };
    const info = privateGroups?.[platform]?.[uid] || [];
    return { uid, gid: info[1] };
};

// 戏文格式提示：与 extractRoleContent 支持的三种握手格式保持一致，接通类通知统一带上这条
const RP_FORMAT_TIP = "✍️ 戏文格式：首行「角色名」+ 换行/空格/冒号（：或:）+ 正文，其余视为闲聊，不计入存档与字数";

// 约会/电话/官约类建群后的通用操作指引（含戏文格式提示），电话/私约额外带"结束互动"提示
function buildAppointmentGuide(gid, day, { includeEnd = false } = {}) {
    const endLine = includeEnd ? `\n结束互动 ➜ 在约会群发「结束私约」` : "";
    return `\n\n${RP_FORMAT_TIP}\n修改时间 ➜ 修改时间线 ${day} 新时间\n不想参加 ➜ 拒绝时间线 ${gid}${endLine}`;
}

// 建群前置：分配群号+算好过期时间。私约/电话/官约/官电/独自踩点共用，
// 避免"暂无可调用的群号"这条错误文案和过期时间的计算方式散落在多处、改一处忘一处。
async function beginGroupCreation(platform, ctx, msg) {
    const gid = await allocateGroup(platform, ctx, msg);
    if (!gid) {
        seal.replyToSender(ctx, msg, "❌ 暂无可调用的群号，请联系管理员扩容群池。");
        return null;
    }
    const expireHours = getStorageInt("group_expire_hours", 48);
    const expireTime = Date.now() + expireHours * 3600000;
    const timeStr = new Date(expireTime).toLocaleString("zh-CN", { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
    return { gid, expireTime, timeStr };
}

// 建群后的公共副作用：写日程/过期信息、通知参与者、发公告改群名、触发目击检测+互动计数+结戏计时器。
// 私约/电话/官约/官电/独自踩点原先各自重写一份这套流程——官约/官电因此漏掉了 triggerSightingCheck
// （官方建的群永远不会触发"偶遇"提示），独自踩点则漏了 recordMeetingAndAnnounce（互动计数/播报）。
// 统一到这里后，以后新增副作用（比如已删掉的 .ext all on 提示）只用改一处，不会再漏改。
// noticeText 为空则不发参与者私聊通知（独自踩点没有"别人"要通知）；
// partnerFor(name) 缺省时用"多人小群/对方名字/（独自）"这套私约默认逻辑，官约/官电传自己的措辞。
function finishGroupCreation({ platform, ctx, msg, gid, expireTime, groupData, participants, groupAnnouncement, finalGroupName, noticeText, partnerFor }) {
    const resolvePartner = partnerFor || ((name) =>
        participants.length > 2 ? "多人小群" : (participants.find(n => n !== name) || "（独自）"));

    // 1. 准备数据落盘
    const b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
    const groupInfo = kvGet("group_expire_info", {});

    participants.forEach(name => {
        const uid = getUidByRoleName(platform, name);
        if (!uid) return;
        const key = `${platform}:${uid}`;
        if (!b_confirmedSchedule[key]) b_confirmedSchedule[key] = [];
        b_confirmedSchedule[key].push({
            day: groupData.day,
            time: groupData.time,
            place: groupData.place,
            partner: resolvePartner(name),
            subtype: groupData.subtype,
            group: gid,
            status: "active"
        });
    });

    groupInfo[gid] = { ...groupData, participants, expireTime, acceptTime: Date.now() };
    kvSet("b_confirmedSchedule", b_confirmedSchedule);
    kvSet("group_expire_info", groupInfo);

    // 2. 向参与者的绑定群发送私聊通知（跳过 groupData.sendname——发起人由指令回执告知；
    //    官约/官电没有 sendname 这个概念，所以谁都不跳过，全员都会收到）
    if (noticeText) {
        participants.forEach(name => {
            if (name === groupData.sendname) return;
            const { uid, gid: bindGid } = getRoleDetails(platform, name);
            if (uid && bindGid) {
                const m = seal.newMessage();
                m.messageType = "group";
                m.groupId = `${platform}-Group:${bindGid}`;
                const tempCtx = seal.createTempCtx(ctx.endPoint, m);
                seal.replyToSender(tempCtx, m, `[CQ:at,qq=${uid}]\n${typeof noticeText === "function" ? noticeText(name) : noticeText}`);
            }
        });
    }

    // 3. 目标群公告+改名
    const targetMsg = seal.newMessage();
    targetMsg.messageType = "group";
    targetMsg.groupId = `${platform}-Group:${gid}`;
    const targetCtx = seal.createTempCtx(ctx.endPoint, targetMsg);
    seal.replyToSender(targetCtx, targetMsg, groupAnnouncement);
    setGroupName(targetCtx, targetMsg, gid, finalGroupName);

    // 4. 其他系统触发
    triggerSightingCheck(platform, groupData.day, groupData.time, groupData.place, participants, gid, groupData.subtype, ctx, msg);
    recordMeetingAndAnnounce(groupData.subtype, platform, ctx, ctx.endPoint);
    if (groupData.subtype) initGroupTimer(platform, gid, groupData.subtype, participants, participants[0]);
}

async function finalizeGroupCreation(platform, ctx, msg, groupData, participants) {
    const alloc = await beginGroupCreation(platform, ctx, msg);
    if (!alloc) return false;
    const { gid, expireTime, timeStr } = alloc;

    // 构建群名：2人显示名字，多于2人显示"多人"
    const participantsText = participants.join("、");
    const groupNameTag = participants.length > 2 ? "多人" : participantsText;
    const finalGroupName = `${getCustomTypeLabel(groupData.subtype)} ${groupData.day} ${groupData.time} ${groupNameTag}`;

    // 构建通知文案
    const otherNames = participants.filter(n => n !== groupData.sendname);
    const multiLine = participants.length > 2
        ? `\n同行：${otherNames.join("、")}`
        : (otherNames.length === 1 ? "" : "");

    const guide = buildAppointmentGuide(gid, groupData.day, { includeEnd: true });

    // 发给各参与者私群的邀请通知（保留"邀你"措辞）
    let noticeText;
    if (groupData.subtype === "电话") {
        const typeLabel = getCustomTypeLabel("电话");
        const titleLine = groupData.title ? ` · ${groupData.title}` : "";
        const peersLine = participants.length > 2 ? `\n同话：${otherNames.join("、")}` : "";
        noticeText = applyMsgTemplate("phone_notice", {
            发起者: groupData.sendname, 日期: groupData.day, 时间: groupData.time,
            标题: groupData.title || "", 同话: otherNames.join("、"),
            群号: gid, 有效期: timeStr, 操作指引: guide.trim()
        }) || `📞 ${typeLabel}\n\n${groupData.sendname} 邀你接听${typeLabel}${titleLine}\n🕐 ${groupData.day} ${groupData.time}${peersLine}\n\n频段：${gid}\n有效至 ${timeStr}${guide}`;
    } else {
        const typeLabel = getCustomTypeLabel(groupData.subtype);
        noticeText = applyMsgTemplate("private_notice", {
            发起者: groupData.sendname, 日期: groupData.day, 时间: groupData.time,
            地点: groupData.place, 同行: otherNames.join("、"),
            群号: gid, 有效期: timeStr, 操作指引: guide.trim()
        }) || `💌 ${typeLabel}\n\n${groupData.sendname} 约你 ${groupData.day} ${groupData.time} 在 ${groupData.place} 相见${multiLine}\n\n群号：${gid}\n有效至 ${timeStr}${guide}`;
    }

    // 发到约会群本身的公告（列出全部参与者，去掉"邀你"措辞）
    let groupAnnouncement;
    if (groupData.subtype === "电话") {
        const typeLabel = getCustomTypeLabel("电话");
        const titleLine = groupData.title ? ` · ${groupData.title}` : "";
        groupAnnouncement = applyMsgTemplate("phone_announcement", {
            标题: groupData.title || "", 日期: groupData.day, 时间: groupData.time,
            参与者: participantsText, 群号: gid, 有效期: timeStr, 操作指引: guide.trim()
        }) || `📞 ${typeLabel}已接通${titleLine}\n\n🕐 ${groupData.day} ${groupData.time}\n👥 参与者：${participantsText}\n\n频段：${gid}\n有效至 ${timeStr}${guide}`;
    } else {
        const typeLabel = getCustomTypeLabel(groupData.subtype);
        groupAnnouncement = applyMsgTemplate("private_announcement", {
            日期: groupData.day, 时间: groupData.time, 地点: groupData.place,
            参与者: participantsText, 群号: gid, 有效期: timeStr, 操作指引: guide.trim()
        }) || `💌 ${typeLabel}已确认\n\n📅 ${groupData.day} ${groupData.time}\n📍 ${groupData.place}\n👥 参与者：${participantsText}\n\n群号：${gid}\n有效至 ${timeStr}${guide}`;
    }

    finishGroupCreation({ platform, ctx, msg, gid, expireTime, groupData, participants, groupAnnouncement, finalGroupName, noticeText });
    return gid;
}

// ========================
// ⏰ 查看到期群指令（精简版）
// ========================

let cmd_view_expired_groups = seal.ext.newCmdItemInfo();
cmd_view_expired_groups.name = "查看到期群";
cmd_view_expired_groups.help = "查看所有已到期群组\n。查看到期群 - 查看所有已到期群组\n。查看到期群 提醒 - 向所有已到期群组发送到期提醒";

cmd_view_expired_groups.solve = (ctx, msg, cmdArgs) => {
    try {
        if (!isUserAdmin(ctx, msg)) return seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。"), seal.ext.newCmdExecuteResult(true);
        const platform = msg.platform;
        const action = cmdArgs.getArgN(1);
        const now = Date.now();
        
        // 读取并解析存储
        const groupExpireInfo = kvGet("group_expire_info", {});
        
        // 核心修改：[indexKey, info] 对应 ["239689865", {对象内容}]
        const expiredGroups = [];
        for (const [indexKey, info] of Object.entries(groupExpireInfo)) {
            if (now > info.expireTime) {
                expiredGroups.push({ indexKey, ...info });
            }
        }
        
        const formatTime = (ts) => new Date(ts).toLocaleString("zh-CN", { year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit' });
        
        // 1. 查看列表
        if (!action) {
            if (!expiredGroups.length) return seal.replyToSender(ctx, msg, "📭 当前没有已到期的群组。"), seal.ext.newCmdExecuteResult(true);
            if (!msg.groupId) return seal.replyToSender(ctx, msg, "⚠️ 请在群内使用此指令。"), seal.ext.newCmdExecuteResult(true);
            const botUid = ctx.endPoint.userId;
            const nodes = [];
            nodes.push({ type: "node", data: { name: "到期群总览", uin: botUid, content: `⏰ 已到期群组列表（共 ${expiredGroups.length} 个）\n💡 使用「。查看到期群 提醒」向到期群发送消息` } });
            expiredGroups.forEach(g => {
                const overdue = (now - g.expireTime) / 60000;
                const overdueDays = Math.floor(overdue / 1440), overdueHours = Math.floor((overdue % 1440) / 60), overdueMins = Math.floor(overdue % 60);
                const overdueStr = `${overdueDays?`${overdueDays}天`:''}${overdueHours?`${overdueHours}小时`:''}${overdueMins}分钟`;
                const content = `📌 群号：${g.indexKey}\n类型：${getCustomTypeLabel(g.subtype || '') || '小群'}\n时间：${g.day} ${g.time}\n地点：${g.place}\n参与者：${g.participants.join('、')}\n到期时间：${formatTime(g.expireTime)}\n已超时：${overdueStr}`;
                nodes.push({ type: "node", data: { name: g.participants.join('、') || "未知", uin: botUid, content } });
            });
            ws({ action: "send_group_forward_msg", params: { group_id: parseInt(msg.groupId.replace(/[^\d]/g, ""), 10), messages: nodes } }, ctx, msg, "");
            return seal.ext.newCmdExecuteResult(true);
        }
        
        // 2. 发送提醒
        if (action === "提醒") {
            if (!expiredGroups.length) return seal.replyToSender(ctx, msg, "📭 当前没有已到期的群组，无需提醒。"), seal.ext.newCmdExecuteResult(true);
            let successCount = 0, failCount = 0;
            
            for (const group of expiredGroups) {
                try {
                    const groupMsg = seal.newMessage();
                    groupMsg.messageType = "group";
                    // 关键：发消息必须用内部真正的 gid
                    groupMsg.groupId = `${platform}-Group:${group.indexKey}`;
                    
                    const groupCtx = seal.createTempCtx(ctx.endPoint, groupMsg);
                    const reminderMsg = `⏰ 温馨提示：\n本群互动时间已经超时了哦～\n\n📋 记录号：${group.indexKey}\n• 时间：${group.day} ${group.time}\n• 地点：${group.place}\n\n如果互动已结束，请使用「结束私约」`;
                    
                    seal.replyToSender(groupCtx, groupMsg, reminderMsg);
                    successCount++;
                } catch (e) {
                    failCount++;
                }
            }
            return seal.replyToSender(ctx, msg, `📢 提醒发送完成！\n✅ 成功：${successCount}\n❌ 失败：${failCount}`), seal.ext.newCmdExecuteResult(true);
        }
        
        return seal.replyToSender(ctx, msg, "⚠️ 参数错误。"), seal.ext.newCmdExecuteResult(true);
    } catch (error) {
        console.log(`[异常] .查看到期群: ${error.stack}`);
        return seal.replyToSender(ctx, msg, "⚠️ 执行出错，请检查后台日志。"), seal.ext.newCmdExecuteResult(true);
    }
};

ext.cmdMap["查看到期群"] = cmd_view_expired_groups;

// ========================
// 🩺 约会数据体检：核对 group（群号池）/ group_expire_info / group_timers /
// b_confirmedSchedule 四份并行存储是否一致。只诊断+清理"能安全判定为垃圾"的记录，
// 不改动任何现有创建/结束流程，也绝不碰仍在占用中的群号本身。
// ========================
let cmd_appointment_healthcheck = seal.ext.newCmdItemInfo();
cmd_appointment_healthcheck.name = "约会数据体检";
cmd_appointment_healthcheck.help = "⚠️【维护工具·请勿随意使用】仅在怀疑约会相关数据异常时使用，正常运营无需执行\n核对约会相关的四份存储是否一致，排查孤儿占用/残留记录\n用法：\n。约会数据体检        仅报告问题\n。约会数据体检 修复   报告并清理可安全判定为垃圾的残留记录（不影响占用中的群）";
cmd_appointment_healthcheck.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
        return seal.ext.newCmdExecuteResult(true);
    }
    const shouldFix = cmdArgs.getArgN(1) === "修复";

    const rawPool = kvGet("group", []);
    const occupiedSet = new Set(rawPool.filter(g => g.endsWith("_占用")).map(g => g.replace(/_占用$/, "")));
    const freeSet = new Set(rawPool.filter(g => !g.endsWith("_占用")));

    const expireInfo = kvGet("group_expire_info", {});
    const timers = kvGet("group_timers", {});
    const schedule = kvGet("b_confirmedSchedule", {});

    // 1. 孤儿占用：群号占用中，但 expire_info 和 timers 都没有 —— 无法自动判断是否仍在真实使用，只报告
    const orphanOccupied = [...occupiedSet].filter(gid => !expireInfo[gid] && !timers[gid]);

    // 2. 占用中但只有一半记录（可能是创建流程中途出错）—— 无法确定哪份是对的，只报告
    const partialOccupied = [...occupiedSet].filter(gid =>
        (expireInfo[gid] && !timers[gid]) || (!expireInfo[gid] && timers[gid])
    );

    // 3. 已释放（空闲池）但仍挂着 expire_info/timers —— 池状态是权威来源，这部分是确定的垃圾，可安全清理
    const staleExpireInfo = [...freeSet].filter(gid => expireInfo[gid]);
    const staleTimers = [...freeSet].filter(gid => timers[gid]);

    // 4. b_confirmedSchedule 里状态非 ended，但指向的群早已不在占用中 —— 可安全标记为 ended
    const staleScheduleEntries = [];
    for (const [uidKey, events] of Object.entries(schedule)) {
        (events || []).forEach((ev, idx) => {
            if (ev.group && ev.status !== "ended" && !occupiedSet.has(ev.group)) {
                staleScheduleEntries.push({ uidKey, idx, gid: ev.group });
            }
        });
    }

    const lines = ["🩺 约会数据体检报告", "━".repeat(14)];
    lines.push(`占用中群号：${occupiedSet.size} 个 ｜ 空闲群号：${freeSet.size} 个`);
    lines.push("");
    lines.push(`🔴 孤儿占用（占用中但两边记录都没有，无法自动判断是否仍在使用，需人工核实）：${orphanOccupied.length}`);
    if (orphanOccupied.length) lines.push(orphanOccupied.map(g => `  · 群号 ${g}`).join("\n"));
    lines.push("");
    lines.push(`🟡 记录不全（占用中但只有一半记录，可能创建流程中途出错）：${partialOccupied.length}`);
    if (partialOccupied.length) lines.push(partialOccupied.map(g =>
        `  · 群号 ${g}（${expireInfo[g] ? "有 expire_info / 缺 timer" : "有 timer / 缺 expire_info"}）`
    ).join("\n"));
    lines.push("");
    lines.push(`🟢 空闲群号仍有残留记录（可安全清理）：expire_info ${staleExpireInfo.length} 条，timers ${staleTimers.length} 条`);
    if (staleExpireInfo.length) lines.push(`  expire_info 残留：${staleExpireInfo.join("、")}`);
    if (staleTimers.length) lines.push(`  timers 残留：${staleTimers.join("、")}`);
    lines.push("");
    lines.push(`🟢 日程仍标"进行中"但对应群已不在占用中（可安全标记为已结束）：${staleScheduleEntries.length} 条`);

    if (shouldFix) {
        let fixedCount = 0;
        if (staleExpireInfo.length) {
            // 同样要在删本地记录前通知存档端结束场次，否则网页端「当前占用群」会留下这批永久卡住的孤儿记录
            if (isArchiveEnabled() && getSeasonMode() !== "no_review") {
                staleExpireInfo.forEach(g => {
                    try { postToArchive("/api/session_end", buildSessionArchive(g, msg.platform, true)); }
                    catch (e) { console.error(`[约会数据体检] 存档同步群 ${g} 结束状态失败: ${e.message}`); }
                });
            }
            staleExpireInfo.forEach(g => delete expireInfo[g]);
            kvSet("group_expire_info", expireInfo);
            fixedCount += staleExpireInfo.length;
        }
        if (staleTimers.length) {
            staleTimers.forEach(g => delete timers[g]);
            kvSet("group_timers", timers);
            fixedCount += staleTimers.length;
        }
        if (staleScheduleEntries.length) {
            staleScheduleEntries.forEach(({ uidKey, idx }) => { schedule[uidKey][idx].status = "ended"; });
            kvSet("b_confirmedSchedule", schedule);
            fixedCount += staleScheduleEntries.length;
        }
        lines.push("", `✅ 已清理 ${fixedCount} 条可安全判定的残留记录。孤儿占用/记录不全未自动处理，请人工核实后视情况用「强结私约 群号」处理。`);
    } else if (staleExpireInfo.length || staleTimers.length || staleScheduleEntries.length) {
        lines.push("", `💡 以上标🟢的问题可用「。约会数据体检 修复」自动清理`);
    }

    seal.replyToSender(ctx, msg, lines.join("\n"));
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["约会数据体检"] = cmd_appointment_healthcheck;

// ========================
// 🛠️ 维护工具说明：汇总列出所有"一次性修复/诊断"类管理员指令，跟日常玩法指令分开陈列，
// 避免误触——这些指令只应在确认对应数据确实异常时才使用。
// ========================
let cmd_maintenance_tools = seal.ext.newCmdItemInfo();
cmd_maintenance_tools.name = "维护工具说明";
cmd_maintenance_tools.help = "【管理员】列出系统里所有维护/修复类指令，均非日常玩法指令，仅在确认数据异常时使用";
cmd_maintenance_tools.solve = (ctx, msg) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
        return seal.ext.newCmdExecuteResult(true);
    }
    const text = [
        "🛠️ 【系统维护工具一览】",
        "以下均为诊断/修复类指令，不是日常玩法指令，仅在确认对应数据出现异常时才需要使用，正常运营请勿随意调用：",
        "",
        "• 。约会数据体检 [修复] —— 核对约会相关四份存储是否一致（长日系统）",
        "• 。修复耗时统计 [角色名] —— 清除异常回复耗时统计（长日社交）",
        "• 。修复商城货币 —— 修正商城/二手市场挂单的货币 code（长日RPG）",
        "",
        "如无法确定是否需要执行，请先用不带参数的诊断/报告模式查看情况，或联系开发者确认后再操作。"
    ].join("\n");
    seal.replyToSender(ctx, msg, text);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["维护工具说明"] = cmd_maintenance_tools;

// ========================
// 📖 长日菜单：分模块的总入口，替代"不知道有什么指令只能一条条问"的现状。
// 每个子系统下面只列 3~5 个高频入口指令，详细列表交给各子系统自己的帮助指令 /
// 。help <扩展名>，避免把 200+ 条指令堆成一面墙。
// ========================
let cmd_menu = seal.ext.newCmdItemInfo();
cmd_menu.name = "长日菜单";
cmd_menu.help = "。长日菜单 —— 查看长日将尽系统的分类总览，不知道有什么功能时从这里开始";
cmd_menu.solve = (ctx, msg) => {
    const text = [
        "🎮 【长日将尽 · 系统菜单】",
        "本系统含 9 个子模块，下面按类别列出高频入口，完整指令表请找管理员要《长日系统指令手册》，或用「。help 扩展名」查看某个子系统的全部指令。",
        "",
        "👤 角色与社交　（扩展名：长日将尽 / 长日社交）",
        "　邀约、时间线、地点、论坛、关系线、点赞点踩",
        "　入口：。发起官约　。地点　。发帖　。拉线",
        "",
        "🎭 出场与季度　（扩展名：出场系统 / 季度管理系统）",
        "　入口：。开始出场　。季度指南",
        "",
        "🎲 RPG 养成　（扩展名：RPG系统）",
        "　背包、装备、技能、抽卡、商城、交易",
        "　入口：。背包　。抽取　。商城",
        "",
        "🍽️ 晚餐　（扩展名：晚餐系统）",
        "　入座",
        "　入口：。开始晚餐",
        "",
        "✉️ 写信综　（扩展名：长日写信综）",
        "　入口：。写信综指南",
        "",
        "🔔 闹钟提醒　（扩展名：长日闹钟）",
        "　入口：。加百列闹钟帮助",
        "",
        "⚙️ 设置与同步　（扩展名：长日设置）",
        "　RP 存档、群号组、天数管理",
        "　入口：。设置",
        "",
        "🔑 管理员工具",
        "　权限管理、维护/修复工具（仅限确认数据异常时使用）",
        "　入口：。授予管理员　。维护工具说明",
        "",
        "🌐 网页版更新日志/指令手册/许愿墙　入口：。长日网址",
    ].join("\n");
    seal.replyToSender(ctx, msg, text);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["长日菜单"] = cmd_menu;

// ========================
// 🌐 一键唤出网页版系统主页（更新日志/指令手册）、许愿墙、玩家指南的链接。
// 这几个页面都跟着 RP存档 一起部署在同一个 Flask 静态目录下，网址直接从
// 「RP存档服务器地址」拼，不用管理员再单独配一份地址、也不怕两边配置漂移。
// ========================
let cmd_web_links = seal.ext.newCmdItemInfo();
cmd_web_links.name = "长日网址";
cmd_web_links.help = "。长日网址 —— 一键获取系统主页（更新日志+指令手册）、许愿墙、玩家指南的网页链接";
cmd_web_links.solve = (ctx, msg) => {
    const base = (seal.ext.getStringConfig(ext, "RP存档服务器地址") || "").replace(/\/$/, "");
    if (!base) {
        seal.replyToSender(ctx, msg, "❌ 尚未配置「RP存档服务器地址」，无法生成网址，请联系管理员配置。");
        return seal.ext.newCmdExecuteResult(true);
    }
    const docs = `${base}/static/docs`;
    const text = [
        "🌐 【长日将尽 · 系统网址】",
        `📖 系统主页（更新日志 + 指令手册）：\n${docs}/changri_hub.html`,
        `🌟 许愿墙（提交想法/查看采纳进度）：\n${docs}/changri_wishes.html`,
        `🧭 玩家指南（新手向导）：\n${docs}/player_guide.html`,
    ].join("\n\n");
    seal.replyToSender(ctx, msg, text);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["长日网址"] = cmd_web_links;

function getIdleGroupName() {
    return (cachedGet("idle_group_name") || "").trim() || "备用";
}

function setGroupName(ctx, msg, groupId, groupName) {
    // 1. 检查使用条件
    const triggerCondition = seal.ext.getStringConfig(ext, "群管插件使用需要满足的条件");
    const fmtCondition = parseInt(seal.format(ctx, `{${triggerCondition}}`));
    
    if (fmtCondition !== 1) {
        seal.replyToSender(ctx, msg, `当前不满足使用条件，无法使用群管功能`);
        console.log('不满足群管插件使用条件，无法设置群名');
        return seal.ext.newCmdExecuteResult(true);
    }

    // 3. 参数验证
    if (!groupName || groupName.trim() === '') {
        seal.replyToSender(ctx, msg, `请输入需要设置的群名`);
        return seal.ext.newCmdExecuteResult(true);
    }
    
    // 4. 提取群号（处理不同格式）
    let groupIdNum;
    if (typeof groupId === 'string') {
        const match = groupId.match(/:(\d+)/);
        if (match && match[1]) {
            groupIdNum = match[1];
        } else {
            // 如果没有冒号格式，假设已经是纯数字
            groupIdNum = groupId;
        }
    } else {
        // 如果是数字，转换为字符串
        groupIdNum = groupId.toString();
    }
    
    // 5. 发送WebSocket请求
    const postData = {
        "action": "set_group_name",
        "params": {
            group_id: groupIdNum,
            group_name: groupName,
        }
    };
    
    const successreply = `已修改群名为${groupName}。`;
    // 改群名会经腾讯服务器中转，偶发比其他 OneBot 动作慢，超时放宽到 8 秒避免误判断开
    return ws(postData, ctx, msg, successreply, undefined, 8000);
}

// 命令版本（如果需要保留命令）
const cmdgroupname = seal.ext.newCmdItemInfo();
cmdgroupname.name = "设置加百列群名";
cmdgroupname.help = "设置加百列群名，.设置加百列群名 【群名】";
cmdgroupname.solve = (ctx, msg, cmdArgs) => {
    const groupName = cmdArgs.getArgN(1);

      if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, `⚠️ 此乃管理权限之事，非管理员者不得。`);
    return seal.ext.newCmdExecuteResult(true);
  }
    
    if (!groupName) {
        const ret = seal.ext.newCmdExecuteResult(true);
        ret.showHelp = true;
        return ret;
    }
    
    return setGroupName(ctx, msg, ctx.group.groupId, groupName);
};

ext.cmdMap["设置加百列群名"] = cmdgroupname;
const cmdSpecialTitle = seal.ext.newCmdItemInfo();
cmdSpecialTitle.name = "群头衔更改";
cmdSpecialTitle.help = "群头衔功能，可用.群头衔 内容 指令来更改。 .群头衔 权限切换来切换可发布者的身份，默认为管理员与群主才能更改头衔（master和白名单例外），切换后为所有人都可以更改。无论哪种权限，管理员和群主可以通过@某人代改。";
cmdSpecialTitle.allowDelegate = true;
cmdSpecialTitle.solve = (ctx, msg, cmdArgs) => {
    const fmtCondition = parseInt(seal.format(ctx, `{${seal.ext.getStringConfig(ext, "群管插件使用需要满足的条件")}}`));
    if (fmtCondition !== 1) return seal.replyToSender(ctx, msg, `当前不满足使用条件，无法使用群管功能`), seal.ext.newCmdExecuteResult(true);

    let val = cmdArgs.getArgN(1);
    ctx.delegateText = "";
    if (val === "help") return seal.ext.newCmdExecuteResult(true);

    if (!val) return seal.replyToSender(ctx, msg, `请输入头衔内容`), seal.ext.newCmdExecuteResult(true);

    if (val === "权限切换" && ctx.privilegeLevel > 45) {
        whiteList = whiteList === 1 ? 0 : 1;
        seal.replyToSender(ctx, msg, whiteList === 1 ? `权限已切换为管理员与群主可更改` : `权限已切换为所有人可更改`);
        return seal.ext.newCmdExecuteResult(true);
    }

    if (ctx.privilegeLevel < 45 && whiteList === 1) {
        return seal.replyToSender(ctx, msg, `❌ 权限不足，无法修改群头衔，当前只有管理员与群主可修改群头衔`), seal.ext.newCmdExecuteResult(true);
    }

    let mctx = seal.getCtxProxyFirst(ctx, cmdArgs);
    let userQQ = mctx.player.userId.split(":")[1];
    if (ctx.privilegeLevel < 45 && mctx.player.userId !== ctx.player.userId) {
        return seal.replyToSender(ctx, msg, `❌ 权限不足，无法修改他人群头衔。`), seal.ext.newCmdExecuteResult(true);
    }

    const groupContent = val;
    const contentLength = Array.from(groupContent).reduce((len, c) => len + (/[\u0020-\u007E]/.test(c) ? 0.5 : /[\u4e00-\u9fa5]/.test(c) ? 1 : 0), 0);
    if (contentLength > 6) return seal.replyToSender(ctx, msg, "头衔长度不能超过六个字符。"), seal.ext.newCmdExecuteResult(true);

    const groupQQ = ctx.group.groupId.match(/:(\d+)/)[1];
    const postData = { action: "set_group_special_title", params: { group_id: parseInt(groupQQ, 10), user_id: parseInt(userQQ, 10), special_title: groupContent.toString() } };
    return ws(postData, ctx, msg, `群头衔更改成功。`);
};
ext.cmdMap["群头衔"] = cmdSpecialTitle;


// ========================
// 📢 群公告发布函数
// ========================

let whiteList = 0;
let noticeWhiteList = 0;

function setGroupNotice(ctx, msg, groupId, content, skipPermissionCheck = false) {
    const triggerCondition = seal.ext.getStringConfig(ext, "群管插件使用需要满足的条件");
    const fmtCondition = parseInt(seal.format(ctx, `{${triggerCondition}}`));

    if (fmtCondition !== 1) {
        seal.replyToSender(ctx, msg, `当前不满足使用条件，无法使用群管功能`);
        return seal.ext.newCmdExecuteResult(true);
    }

    if (!skipPermissionCheck) {
        if (ctx.privilegeLevel < 45 && noticeWhiteList === 1) {
            seal.replyToSender(ctx, msg, `❌ 权限不足，无法发布群公告`);
            return seal.ext.newCmdExecuteResult(true);
        }
    }

    let groupIdNum;
    if (typeof groupId === 'string') {
        const match = groupId.match(/:(\d+)/);
        groupIdNum = match ? match[1] : groupId;
    } else {
        groupIdNum = groupId.toString();
    }

    let contentClean = seal.format(ctx, content.replace(/\[CQ:[^\]]*\]/g, ""));
    let postData = {
        "action": "_send_group_notice",
        "params": {
            group_id: groupIdNum,
            content: contentClean,
        }
    };

    let regex = /\[CQ:image,file=(.*?),url=(.*?)\]/;
    let imgMatch = content.match(regex);
    if (imgMatch) {
        postData.params.image = imgMatch[2];
    }

    const successreply = `群公告发送成功。`;
    return ws(postData, ctx, msg, successreply);
}

// ========================
// 📢 群公告发布指令（简化版）
// ========================

let cmdGroupNotice = seal.ext.newCmdItemInfo();
cmdGroupNotice.name = "群公告发布";
cmdGroupNotice.help =
    "。群公告发布 内容 - 发布群公告（支持图片）\n" +
    "。群公告发布 权限切换 - 切换发布权限（管理员可用）\n" +
    "注：预设模板已移除，请直接输入内容。";

cmdGroupNotice.solve = function(ctx, msg, cmdArgs) {
    if (cmdArgs.getArgN(1) === "权限切换") {
        if (ctx.privilegeLevel > 45) {
            noticeWhiteList = noticeWhiteList === 1 ? 0 : 1;
            seal.replyToSender(ctx, msg,
                noticeWhiteList === 1 ?
                `权限已切换为管理员与群主可发布` :
                `权限已切换为所有人都可发布`
            );
        } else {
            seal.replyToSender(ctx, msg, `❌ 权限不足，无法切换权限`);
        }
        return seal.ext.newCmdExecuteResult(true);
    }

    const matchResult = (msg.message || "").match(/^[。.]群公告发布\s+(.+)$/s);
    if (!matchResult || !matchResult[1]) {
        seal.replyToSender(ctx, msg, `请输入公告内容。示例：。群公告发布 今晚8点有活动`);
        return seal.ext.newCmdExecuteResult(true);
    }

    const content = matchResult[1].trim();
    return setGroupNotice(ctx, msg, ctx.group.groupId, content);
};

ext.cmdMap["群公告发布"] = cmdGroupNotice;

let cmd_view_schedule_other = seal.ext.newCmdItemInfo();
cmd_view_schedule_other.name = "查看他人时间线";
cmd_view_schedule_other.help = "。查看他人时间线 角色名 —— 管理员专属，查看指定角色的全部时间安排";

cmd_view_schedule_other.solve = (ctx, msg, cmdArgs) => {
  const role = cmdArgs.getArgN(1);
  const platform = msg.platform;
  const uid = msg.sender.userId;
  const a_private_group = kvGet("a_private_group", {});

  if (!role) {
    seal.replyToSender(ctx, msg, "📌 请注明需查看的角色名，例如：\n.查看他人时间线 玛丽");
    return seal.ext.newCmdExecuteResult(true);
  }

  if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, `⚠️ 此乃管理权限之事，非管理员者不得窥探他人行迹`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const targetUid = getUidByRoleName(platform, role);
  if (!targetUid) {
    seal.replyToSender(ctx, msg, `⚠️ 找不到角色「${role}」，请确认其已完成绑定`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const key = `${platform}:${targetUid}`;
  const schedule = kvGet("b_confirmedSchedule", {});

  if (!schedule[key] || schedule[key].length === 0) {
    seal.replyToSender(ctx, msg, `📭 ${role} 目前尚无任何已确认的会晤安排`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const sorted = schedule[key].slice().sort((a, b) => {
    const getMin = s => parseInt(s.time.split("-")[0].replace(":", ""));
    if (a.day !== b.day) return parseInt(a.day.slice(1)) - parseInt(b.day.slice(1));
    return getMin(a) - getMin(b);
  });

  const grouped = {};
  for (let item of sorted) {
    if (!grouped[item.day]) grouped[item.day] = [];
    grouped[item.day].push(item);
  }

  let rep = `📜 ${role} 的密约行程如下所列：\n`;
  for (let day of Object.keys(grouped).sort((a, b) => parseInt(a.slice(1)) - parseInt(b.slice(1)))) {
    rep += `\n📅【${day}】\n`;
    for (let ev of grouped[day]) {
      let marker = ev.subtype === "电话" ? "📞" : "🤫";
      rep += `${marker} ${ev.time} —— ${ev.partner}（${getCustomTypeLabel(ev.subtype)}小群）\n`;
    }
  }

  seal.replyToSender(ctx, msg, rep.trim());
  return seal.ext.newCmdExecuteResult(true);
};

ext.cmdMap["查看他人时间线"] = cmd_view_schedule_other;

// 统一时间锁定指令
let cmd_time_lock = seal.ext.newCmdItemInfo();
cmd_time_lock.name = "时间锁定";
cmd_time_lock.help = `
时间锁定 [操作] [目标] [日期] [时间] —— 管理员管理角色时间锁定状态

参数说明：
• 操作：锁定/解锁
• 目标：单个角色名 / 多个角色名用/分隔 / 全体
• 日期：D1, D2, D3...（格式：D+数字）
• 时间：14:00-16:00（格式：开始时间-结束时间）

示例：
。时间锁定 锁定 角色A D3 14:00-16:00
。时间锁定 锁定 角色A/角色B/角色C D3 14:00-16:00
。时间锁定 锁定 全体 D3 14:00-16:00
。时间锁定 解锁 角色A D3 14:00-16:00
。时间锁定 解锁 全体 D3 14:00-16:00
。时间锁定 解锁 角色A/角色B D3 14:00-16:00
`;

cmd_time_lock.solve = function(ctx, msg, argv) {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
        return seal.ext.newCmdExecuteResult(true);
    }

    const operation = argv.getArgN(1); // 锁定/解锁
    const target = argv.getArgN(2);    // 角色名/角色A/角色B/全体
    const day = argv.getArgN(3);       // D1, D2...
    const time = argv.getArgN(4);      // 14:00-16:00

    // 参数验证
    if (!operation || !target || !day || !time) {
        const ret = seal.ext.newCmdExecuteResult(true);
        ret.showHelp = true;
        return ret;
    }

    if (operation !== "锁定" && operation !== "解锁") {
        seal.replyToSender(ctx, msg, "⚠️ 操作参数错误：必须是「锁定」或「解锁」");
        return seal.ext.newCmdExecuteResult(true);
    }

    if (!/^D\d+$/.test(day)) {
        seal.replyToSender(ctx, msg, "⚠️ 日期格式错误：必须是D+数字，如D1, D2, D3...");
        return seal.ext.newCmdExecuteResult(true);
    }

    if (!isValidTimeFormat(time)) {
        seal.replyToSender(ctx, msg, "⚠️ 时间格式错误：必须是HH:MM-HH:MM格式，如14:00-16:00");
        return seal.ext.newCmdExecuteResult(true);
    }

    const platform = msg.platform;
    let a_private_group = kvGet("a_private_group", {});
    let a_lockedSlots = kvGet("a_lockedSlots", {});

    // 获取目标角色列表（roleNames 用于显示，内部转换为 uid 操作）
    let targetRoles = [];

    if (target === "全体") {
        // 获取当前平台所有角色名
        if (a_private_group[platform]) {
            targetRoles = Object.values(a_private_group[platform]).map(v => v[0]).filter(Boolean);
        }
        if (targetRoles.length === 0) {
            seal.replyToSender(ctx, msg, "⚠️ 当前平台没有任何绑定的角色");
            return seal.ext.newCmdExecuteResult(true);
        }
    } else if (target.includes("/")) {
        // 多个角色，用/分隔
        targetRoles = target.replace(/，/g, "/").split("/").map(n => n.trim()).filter(Boolean);
    } else {
        // 单个角色
        targetRoles = [target];
    }

    // 处理每个角色
    let successList = [];
    let failList = [];
    let notFoundList = [];
    let alreadyList = []; // 已经锁定/解锁的状态

    for (let roleName of targetRoles) {
        // 新结构：通过 roleName 反查 uid
        const uid = getUidByRoleName(platform, roleName);
        if (!uid) {
            notFoundList.push(roleName);
            continue;
        }

        const key = `${platform}:${uid}`;

        // 执行锁定或解锁操作
        if (operation === "锁定") {
            if (!a_lockedSlots[key]) a_lockedSlots[key] = {};
            if (!a_lockedSlots[key][day]) a_lockedSlots[key][day] = [];
            
            if (a_lockedSlots[key][day].includes(time)) {
                alreadyList.push(`⚠️「${roleName}」已锁定 ${day} ${time}`);
            } else {
                a_lockedSlots[key][day].push(time);
                successList.push(`✅「${roleName}」已锁定 ${day} ${time}`);
            }
        } else { // 解锁操作
            if (a_lockedSlots[key] && a_lockedSlots[key][day]) {
                const index = a_lockedSlots[key][day].indexOf(time);
                if (index !== -1) {
                    a_lockedSlots[key][day].splice(index, 1);
                    // 清理空数组和空对象
                    if (a_lockedSlots[key][day].length === 0) delete a_lockedSlots[key][day];
                    if (Object.keys(a_lockedSlots[key]).length === 0) delete a_lockedSlots[key];
                    successList.push(`✅「${roleName}」已解锁 ${day} ${time}`);
                } else {
                    alreadyList.push(`⚠️「${roleName}」未锁定 ${day} ${time}`);
                }
            } else {
                alreadyList.push(`⚠️「${roleName}」未锁定 ${day} ${time}`);
            }
        }
    }

    // 保存数据
    kvSet("a_lockedSlots", a_lockedSlots);

    // 构建回复消息
    let resultMsg = "";
    
    if (successList.length > 0) {
        resultMsg += `📋 ${operation}操作成功（${successList.length}个）：\n`;
        resultMsg += successList.join("\n") + "\n\n";
    }
    
    if (alreadyList.length > 0) {
        resultMsg += `ℹ️ 无需操作（${alreadyList.length}个）：\n`;
        resultMsg += alreadyList.join("\n") + "\n\n";
    }
    
    if (notFoundList.length > 0) {
        resultMsg += `❌ 未找到角色（${notFoundList.length}个）：\n`;
        resultMsg += notFoundList.map(name => `「${name}」`).join("、") + "\n\n";
    }
    
    if (failList.length > 0) {
        resultMsg += `⚠️ 操作失败（${failList.length}个）：\n`;
        resultMsg += failList.join("\n");
    }

    // 如果没有任何操作结果，显示提示
    if (successList.length === 0 && alreadyList.length === 0 && 
        notFoundList.length === 0 && failList.length === 0) {
        resultMsg = "⚠️ 未执行任何操作，请检查参数";
    }

    seal.replyToSender(ctx, msg, resultMsg.trim());
    return seal.ext.newCmdExecuteResult(true);
};

// 替换原有的四个指令
ext.cmdMap["时间锁定"] = cmd_time_lock;

// ========================
// 🛡️ 管理员系统
// ========================

let cmd_grant_admin = seal.ext.newCmdItemInfo();
cmd_grant_admin.name = "授予管理员";
cmd_grant_admin.help = "。授予管理员 QQ号 密码（输入正确密码后将该QQ设为临时管理员）";

cmd_grant_admin.solve = (ctx, msg, cmdArgs) => {
  const targetQQ = cmdArgs.getArgN(1);
  const inputPass = cmdArgs.getArgN(2);
  const platform = msg.platform;

  if (!targetQQ || !inputPass) {
    seal.replyToSender(ctx, msg, "请输入授权格式，例如：.授予管理员 123456789 newyork");
    return seal.ext.newCmdExecuteResult(true);
  }

  const ADMIN_SECRET = getAdminPassword();

  if (inputPass.trim() !== ADMIN_SECRET) {
    seal.replyToSender(ctx, msg, "❌ 密码错误，无法授权管理员");
    return seal.ext.newCmdExecuteResult(true);
  }

  const uid = `${platform}:${targetQQ}`;
  let a_adminList = kvGet("a_adminList", {});
  if (!a_adminList[platform]) a_adminList[platform] = [];

  if (!a_adminList[platform].includes(targetQQ)) {
    a_adminList[platform].push(targetQQ);
    kvSet("a_adminList", a_adminList);
    seal.replyToSender(ctx, msg, `✅ 成功将 ${targetQQ} 设为 ${platform} 平台的临时管理员`);
  } else {
    seal.replyToSender(ctx, msg, `⚠️ ${targetQQ} 已是管理员`);
  }
  return seal.ext.newCmdExecuteResult(true);
};

ext.cmdMap["授予管理员"] = cmd_grant_admin;


let cmd_set_admin_pass = seal.ext.newCmdItemInfo();
cmd_set_admin_pass.name = "更改密令";  // 法语：更改密码
cmd_set_admin_pass.help = "。更改密令 旧密码 新密码（需验证旧密码）";

cmd_set_admin_pass.solve = (ctx, msg, cmdArgs) => {
  const oldPass = cmdArgs.getArgN(1);
  const newPass = cmdArgs.getArgN(2);

  if (!oldPass || !newPass) {
    seal.replyToSender(ctx, msg, "⚠️ 格式：。更改密令 旧密码 新密码");
    return seal.ext.newCmdExecuteResult(true);
  }

  const ADMIN_SECRET = getAdminPassword();
  if (oldPass.trim() !== ADMIN_SECRET) {
    seal.replyToSender(ctx, msg, "❌ 旧密码错误，无法更改密令");
    return seal.ext.newCmdExecuteResult(true);
  }

  if (newPass.length < 4) {
    seal.replyToSender(ctx, msg, "⚠️ 新密码至少需要4位");
    return seal.ext.newCmdExecuteResult(true);
  }

  kvSet("adminPassword", newPass);
  seal.replyToSender(ctx, msg, "✅ 管理员密码已成功更新");
  return seal.ext.newCmdExecuteResult(true);
};

ext.cmdMap["更改密令"] = cmd_set_admin_pass;


let cmd_revoke_admin = seal.ext.newCmdItemInfo();
cmd_revoke_admin.name = "收回管理员";
cmd_revoke_admin.help = "。收回管理员 QQ号 密码（输入正确密码可撤销管理员身份）";

cmd_revoke_admin.solve = (ctx, msg, cmdArgs) => {
  const targetUid = cmdArgs.getArgN(1);
  const inputPass = cmdArgs.getArgN(2);
  const platform = msg.platform;

  if (!targetUid || !inputPass) {
    seal.replyToSender(ctx, msg, "请输入完整参数：。撤销管理员 QQ号 密码");
    return seal.ext.newCmdExecuteResult(true);
  }

  const ADMIN_SECRET = getAdminPassword();

  if (inputPass.trim() !== ADMIN_SECRET) {
    seal.replyToSender(ctx, msg, "❌ 密码错误，无法撤销管理员");
    return seal.ext.newCmdExecuteResult(true);
  }

  let a_adminList = kvGet("a_adminList", {});
  if (!a_adminList[platform]) {
    seal.replyToSender(ctx, msg, "⚠️ 当前平台无管理员记录");
    return seal.ext.newCmdExecuteResult(true);
  }

  const newList = a_adminList[platform].filter(id => id !== targetUid);
  if (newList.length === a_adminList[platform].length) {
    seal.replyToSender(ctx, msg, `⚠️ 用户 ${targetUid} 并非管理员`);
    return seal.ext.newCmdExecuteResult(true);
  }

  a_adminList[platform] = newList;
  kvSet("a_adminList", a_adminList);
  seal.replyToSender(ctx, msg, `✅ 已撤销 ${targetUid} 的管理员身份`);
  return seal.ext.newCmdExecuteResult(true);
};

ext.cmdMap["收回管理员"] = cmd_revoke_admin;

let cmd_list_admins = seal.ext.newCmdItemInfo();
cmd_list_admins.name = "管理员列表";
cmd_list_admins.help = "。管理员列表（显示当前所有平台下的临时管理员）";

cmd_list_admins.solve = (ctx, msg) => {
  if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, "只有管理员可以查看管理员列表");
    return seal.ext.newCmdExecuteResult(true);
  }

  const a_adminList = kvGet("a_adminList", {});
  let rep = "📋 当前所有平台的管理员清单：\n";

  const platforms = Object.keys(a_adminList);
  if (platforms.length === 0) {
    rep += "（暂无记录）";
  } else {
    for (let plat of platforms) {
      const ids = a_adminList[plat];
      if (ids.length === 0) continue;
      rep += `\n【${plat}】\n`;
      for (let id of ids) {
        rep += `- ${plat}:${id}\n`;
      }
    }
  }

  seal.replyToSender(ctx, msg, rep.trim());
  return seal.ext.newCmdExecuteResult(true);
};

ext.cmdMap["管理员列表"] = cmd_list_admins;

let cmd_clear_admin = seal.ext.newCmdItemInfo();
cmd_clear_admin.name = "清空管理员";
cmd_clear_admin.help = "。清空管理员 密码（输入正确密码可清空所有平台管理员）";

cmd_clear_admin.solve = (ctx, msg, cmdArgs) => {
  const input = cmdArgs.getArgN(1);

  if (!input) {
    seal.replyToSender(ctx, msg, "请输入密码，例如：.清空管理员 anton");
    return seal.ext.newCmdExecuteResult(true);
  }

  const ADMIN_SECRET = getAdminPassword();

  if (input.trim() !== ADMIN_SECRET) {
    seal.replyToSender(ctx, msg, "❌ 密码错误，无法清空管理员列表");
    return seal.ext.newCmdExecuteResult(true);
  }

  kvSet("a_adminList", {});
  seal.replyToSender(ctx, msg, "✅ 所有平台的临时管理员已被清空");
  return seal.ext.newCmdExecuteResult(true);
};

ext.cmdMap["清空管理员"] = cmd_clear_admin;

let cmd_view_locks = seal.ext.newCmdItemInfo();
cmd_view_locks.name = "查看锁定";
cmd_view_locks.help = "。查看锁定 角色名（管理员/骰主可用）";

cmd_view_locks.solve = (ctx, msg, cmdArgs) => {
  if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, `只有管理员或骰主可以查看角色锁定状态`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const name = cmdArgs.getArgN(1);
  if (!name) {
    seal.replyToSender(ctx, msg, `请输入角色名，如：查看锁定 安托万`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const platform = msg.platform;
  const uid = getUidByRoleName(platform, name);
  if (!uid) {
    seal.replyToSender(ctx, msg, `未找到角色「${name}」，请确认其是否已绑定`);
    return;
  }

  const key = `${platform}:${uid}`;
  const a_lockedSlots = kvGet("a_lockedSlots", {});

  if (!a_lockedSlots[key] || Object.keys(a_lockedSlots[key]).length === 0) {
    seal.replyToSender(ctx, msg, `✅ 角色「${name}」当前没有任何被锁定的时间段`);
    return seal.ext.newCmdExecuteResult(true);
  }

  let rep = `📋 ${name} 的锁定时间段如下：\n`;
  const days = Object.keys(a_lockedSlots[key]).sort((a, b) => parseInt(a.slice(1)) - parseInt(b.slice(1)));
  for (let day of days) {
    rep += `\n【${day}】\n`;
    for (let t of a_lockedSlots[key][day]) {
      rep += `- ${t}\n`;
    }
  }

  seal.replyToSender(ctx, msg, rep.trim());
  return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["查看锁定"] = cmd_view_locks;

// ========================
// 🚫 拉黑（玩家自助单方面屏蔽，不需要管理员操作）
// ========================
let cmd_block_person = seal.ext.newCmdItemInfo();
cmd_block_person.name = "拉黑";
cmd_block_person.help = "。拉黑 角色名 [静默/不静默]\n屏蔽指定角色对你发起的短信/礼物/私约/电话/微信/漂流瓶回信联系，不影响你主动联系对方。\n默认不静默——对方联系你时会被明确告知「已拒绝TA的联络」。\n写「静默」则对方察觉不到自己被拉黑：短信/礼物/漂流瓶回信会看到和正常送达一样的成功提示；私约/电话/微信因为要占用真实群号，做不到伪装建群，会看到一个不说明原因的「发起失败」。\n随时可用「取消拉黑 角色名」解除，用「拉黑列表」查看自己拉黑了谁。";
cmd_block_person.solve = (ctx, msg, cmdArgs) => {
    const platform = msg.platform;
    const uid = msg.sender.userId.replace(`${platform}:`, "");
    const sendname = getRoleName(ctx, msg);
    if (!sendname) {
        seal.replyToSender(ctx, msg, "请先使用「创建新角色」绑定角色");
        return seal.ext.newCmdExecuteResult(true);
    }
    const targetName = cmdArgs.getArgN(1);
    if (!targetName) {
        seal.replyToSender(ctx, msg, "⚠️ 格式：拉黑 角色名 [静默/不静默]\n例：拉黑 张三\n例：拉黑 张三 静默");
        return seal.ext.newCmdExecuteResult(true);
    }
    if (targetName === sendname) {
        seal.replyToSender(ctx, msg, "❌ 不能拉黑自己");
        return seal.ext.newCmdExecuteResult(true);
    }
    const targetUid = getUidByRoleName(platform, targetName);
    if (!targetUid) {
        seal.replyToSender(ctx, msg, `❌ 未找到角色「${targetName}」`);
        return seal.ext.newCmdExecuteResult(true);
    }
    const silent = (cmdArgs.getArgN(2) || "").trim() === "静默";

    const blockerUid = getPrimaryUid(platform, uid);
    let bl = kvGet("sys_blocklist", {});
    if (!bl[platform]) bl[platform] = {};
    if (!bl[platform][blockerUid]) bl[platform][blockerUid] = {};
    bl[platform][blockerUid][targetUid] = { silent, since: Date.now(), blockerName: sendname, blockedName: targetName };
    kvSet("sys_blocklist", bl);

    seal.replyToSender(ctx, msg, `🚫 已拉黑「${targetName}」（${silent ? "静默" : "不静默"}模式），TA 之后发起的短信/礼物/私约/电话/微信/漂流瓶回信都不会再送达你。\n随时可用「取消拉黑 ${targetName}」解除。`);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["拉黑"] = cmd_block_person;

let cmd_unblock_person = seal.ext.newCmdItemInfo();
cmd_unblock_person.name = "取消拉黑";
cmd_unblock_person.help = "。取消拉黑 角色名";
cmd_unblock_person.solve = (ctx, msg, cmdArgs) => {
    const platform = msg.platform;
    const uid = msg.sender.userId.replace(`${platform}:`, "");
    const sendname = getRoleName(ctx, msg);
    if (!sendname) {
        seal.replyToSender(ctx, msg, "请先使用「创建新角色」绑定角色");
        return seal.ext.newCmdExecuteResult(true);
    }
    const targetName = cmdArgs.getArgN(1);
    if (!targetName) {
        seal.replyToSender(ctx, msg, "⚠️ 格式：取消拉黑 角色名");
        return seal.ext.newCmdExecuteResult(true);
    }
    const targetUid = getUidByRoleName(platform, targetName);
    if (!targetUid) {
        seal.replyToSender(ctx, msg, `❌ 未找到角色「${targetName}」`);
        return seal.ext.newCmdExecuteResult(true);
    }
    const blockerUid = getPrimaryUid(platform, uid);
    let bl = kvGet("sys_blocklist", {});
    if (!bl[platform]?.[blockerUid]?.[targetUid]) {
        seal.replyToSender(ctx, msg, `❓ 你并没有拉黑「${targetName}」`);
        return seal.ext.newCmdExecuteResult(true);
    }
    delete bl[platform][blockerUid][targetUid];
    kvSet("sys_blocklist", bl);
    seal.replyToSender(ctx, msg, `✅ 已取消拉黑「${targetName}」`);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["取消拉黑"] = cmd_unblock_person;

let cmd_view_blocklist = seal.ext.newCmdItemInfo();
cmd_view_blocklist.name = "拉黑列表";
cmd_view_blocklist.help = "。拉黑列表 —— 查看自己当前拉黑了哪些人";
cmd_view_blocklist.solve = (ctx, msg) => {
    const platform = msg.platform;
    const uid = msg.sender.userId.replace(`${platform}:`, "");
    const sendname = getRoleName(ctx, msg);
    if (!sendname) {
        seal.replyToSender(ctx, msg, "请先使用「创建新角色」绑定角色");
        return seal.ext.newCmdExecuteResult(true);
    }
    const blockerUid = getPrimaryUid(platform, uid);
    const bl = kvGet("sys_blocklist", {});
    const mine = bl[platform]?.[blockerUid] || {};
    const entries = Object.values(mine);
    if (!entries.length) {
        seal.replyToSender(ctx, msg, "📋 你当前没有拉黑任何人");
        return seal.ext.newCmdExecuteResult(true);
    }
    const lines = entries.map(e => `- ${e.blockedName}（${e.silent ? "静默" : "不静默"}）`).join("\n");
    seal.replyToSender(ctx, msg, `📋 你拉黑的人：\n${lines}`);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["拉黑列表"] = cmd_view_blocklist;

let cmd_block_user_feature = seal.ext.newCmdItemInfo();
cmd_block_user_feature.name = "功能权限";
cmd_block_user_feature.help = "。功能权限 角色名 功能 开启/关闭\n功能：礼物/发起邀约/寄信/心愿/心动信/论坛/抽取/全部";

cmd_block_user_feature.solve = (ctx, msg, cmdArgs) => {
  if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
    return seal.ext.newCmdExecuteResult(true);
  }
  const roleName = cmdArgs.getArgN(1);
  const featureName = cmdArgs.getArgN(2);
  const action = cmdArgs.getArgN(3);

  if (!roleName || !featureName || !action) {
    const ret = seal.ext.newCmdExecuteResult(true);
    ret.showHelp = true;
    return ret;
  }

  const featureMap = {
    "礼物": "enable_general_gift",
    "发起邀约": "enable_general_appointment",
    "寄信": "enable_chaos_letter",
    "心愿": "enable_wish_system",
    "心动信": "enable_lovemail",
    "论坛": "enable_forum",
    "抽取": "enable_item_draw"
  };

  const value = (action === "开启") ? true : (action === "关闭") ? false : null;
  if (value === null) {
    seal.replyToSender(ctx, msg, `⚠️ 状态应为：开启 / 关闭`);
    return seal.ext.newCmdExecuteResult(true);
  }

  // 新结构：feature_user_blocklist[uid] 而非 [roleName]
  const platform = msg.platform;
  const targetUid = getUidByRoleName(platform, roleName);
  if (!targetUid) {
    seal.replyToSender(ctx, msg, `❌ 找不到角色「${roleName}」`);
    return seal.ext.newCmdExecuteResult(true);
  }

  let blockMap = kvGet("feature_user_blocklist", {});
  if (!blockMap[targetUid]) blockMap[targetUid] = {};

  if (featureName === "全部") {
    for (const key of Object.values(featureMap)) blockMap[targetUid][key] = value;
    kvSet("feature_user_blocklist", blockMap);
    const status = value ? "✅ 已开启" : "🚫 已关闭";
    seal.replyToSender(ctx, msg, `${status} 全部功能：${roleName}`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const key = featureMap[featureName];
  if (!key) {
    seal.replyToSender(ctx, msg, `⚠️ 功能名可选：礼物 / 发起邀约 / 寄信 / 心愿 / 心动信 / 论坛 / 抽取 / 全部`);
    return seal.ext.newCmdExecuteResult(true);
  }

  blockMap[targetUid][key] = value;
  kvSet("feature_user_blocklist", blockMap);

  const status = value ? "✅ 已开启" : "🚫 已关闭";
  seal.replyToSender(ctx, msg, `${status} ${featureName} 功能：${roleName}`);
  return seal.ext.newCmdExecuteResult(true);
};

ext.cmdMap["功能权限"] = cmd_block_user_feature;

let cmd_view_user_feature = seal.ext.newCmdItemInfo();
cmd_view_user_feature.name = "查看功能权限";
cmd_view_user_feature.help = "。查看功能权限 —— 查看所有被设定过功能开关的角色与状态";

cmd_view_user_feature.solve = (ctx, msg, cmdArgs) => {
  if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
    return seal.ext.newCmdExecuteResult(true);
  }
  let blockMap = kvGet("feature_user_blocklist", {});

  if (Object.keys(blockMap).length === 0) {
    seal.replyToSender(ctx, msg, "📭 当前尚无任何角色设定功能权限。");
    return seal.ext.newCmdExecuteResult(true);
  }

  const featureLabelMap = {
    enable_general_gift: "礼物",
    enable_general_appointment: "发起邀约",
    enable_chaos_letter: "寄信",
    enable_wish_system: "心愿",
    enable_lovemail: "心动信",
    enable_forum: "论坛",
    enable_item_draw: "抽取"
  };


  let lines = [];

  // 新结构：blockMap[uid]，显示时转为 roleName
  for (let uid in blockMap) {
    const displayName = resolveUidToNameAnyPlatform(uid);
    let userFeatures = blockMap[uid];
    let statusList = [];

    for (let key in userFeatures) {
      let status = userFeatures[key] ? "✅开启" : "🚫关闭";
      let label = featureLabelMap[key] || key;
      statusList.push(`${label}：${status}`);
    }

    if (statusList.length > 0) {
      lines.push(`【${displayName}】→ ${statusList.join("，")}`);
    }
  }

  if (lines.length === 0) {
    seal.replyToSender(ctx, msg, "📭 所有角色当前均为默认状态，无权限限制。");
    return seal.ext.newCmdExecuteResult(true);
  }

  seal.replyToSender(ctx, msg, `📜 功能权限状态如下：\n\n${lines.join("\n")}`);
  return seal.ext.newCmdExecuteResult(true);
};

ext.cmdMap["查看功能权限"] = cmd_view_user_feature;

// ========================
// 🕊️ 寄信与关系线系统
// ========================
// ── 寄信 · 前置校验：功能开关/自寄/收件人存在/冷却/每日上限 ──
// 全部通过返回投递所需状态对象；任一项拦截时已回复玩家并返回 null
function chaosLetterPrecheck(ctx, msg, platform, sendname, toname) {
    const config = kvGet("global_feature_toggle", {});
    if (config.enable_chaos_letter === false) {
        seal.replyToSender(ctx, msg, "🕊️ 寄信功能已关闭。");
        return null;
    }

    // 真实角色名（sendname 可能是自定义署名，realSendname 始终是绑定角色）
    const realSendname = getRoleName(ctx, msg) || sendname;

    if (toname === realSendname) {
        seal.replyToSender(ctx, msg, "📱 短信不可发给自己。");
        return null;
    }

    const a_private_group = kvGet("a_private_group", {});
    const toUidForLetter = getUidByRoleName(platform, toname);
    if (!toUidForLetter) {
        seal.replyToSender(ctx, msg, `❌ 未找到收信人：${toname}`);
        return null;
    }

    // 🎲 读取混乱配置
    const defaultConfig = {
        misdelivery: 0, blackoutText: 0, loseContent: 0, antonymReplace: 0,
        reverseOrder: 0, mistakenSignature: 0, tornPage: 0, dailyLimit: 5, publicChance: 50
    };
    const chaosConfig = { ...defaultConfig, ...kvGet("chaos_letter_config", {}) };

    // ⏳ 冷却与次数检查 (使用发送者的主账号 UID)
    const uid = getPrimaryUid(platform, msg.sender.userId.replace(`${platform}:`, ""));
    const cooldownKey = `chaos_letter_cooldown_${platform}:${uid}`;
    const lastSent = parseInt(cachedGet(cooldownKey) || "0");
    const now = Date.now();
    const mailCooldownMin = getStorageInt("mailCooldown", 60);

    if (now - lastSent < mailCooldownMin * 60 * 1000) {
        const rem = Math.ceil((mailCooldownMin * 60 * 1000 - (now - lastSent)) / 60000);
        seal.replyToSender(ctx, msg, `⏳ 鸽子正在休息，请 ${rem} 分钟后再试`);
        return null;
    }

    const gameDay = cachedGet("global_days") || "D0";
    const globalChaosCounts = kvGet("global_chaos_letter_counts", {});
    const userKey = `${platform}:${uid}`;
    let userRec = globalChaosCounts[userKey] || { day: gameDay, count: 0 };
    if (userRec.day !== gameDay) userRec = { day: gameDay, count: 0 };

    if (userRec.count >= chaosConfig.dailyLimit) {
        seal.replyToSender(ctx, msg, `🕊️ 今日寄信次数已达上限(${chaosConfig.dailyLimit})`);
        return null;
    }

    return { realSendname, a_private_group, toUidForLetter, chaosConfig, uid, cooldownKey, now, gameDay, globalChaosCounts, userKey, userRec };
}

// ── 寄信 · 内容侵蚀：错字替换/内容丢失/涂黑（按概率独立触发）──
function applyChaosErosion(contentOriginal, chaosConfig) {
    let content = contentOriginal;
    const chaosCharPool = ["梦", "影", "幻", "虚", "无", "断", "零", "终", "念", "尘", "迹", "雾", "嘘", "寂"];

    if (Math.random() < (chaosConfig.antonymReplace / 100)) {
        let textArray = content.split('');
        const replaceCount = Math.floor(textArray.length * (0.15 + Math.random() * 0.1));
        for (let i = 0; i < replaceCount; i++) {
            textArray[Math.floor(Math.random() * textArray.length)] = chaosCharPool[Math.floor(Math.random() * chaosCharPool.length)];
        }
        content = textArray.join('');
    }
    if (Math.random() < (chaosConfig.loseContent / 100) && content.length > 5) {
        content = content.slice(0, Math.floor(content.length * 0.7)) + "……";
    }
    if (Math.random() < (chaosConfig.blackoutText / 100)) {
        const blackout = ["◼︎", "█", "■", "▮"];
        content = content.split('').map(c => Math.random() < 0.2 ? blackout[Math.floor(Math.random() * blackout.length)] : c).join('');
    }
    if (Math.random() < (chaosConfig.reverseOrder / 100)) {
        // 按句切分（保留标点），打乱重排；若洗牌后恰好原样则强制轮转一句
        const parts = content.match(/[^。！？!?\n]+[。！？!?\n]*/g) || [];
        if (parts.length > 1) {
            const original = parts.join('');
            for (let i = parts.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                const tmp = parts[i]; parts[i] = parts[j]; parts[j] = tmp;
            }
            let shuffled = parts.join('');
            if (shuffled === original) shuffled = parts.slice(1).join('') + parts[0];
            content = shuffled;
        }
    }
    return content;
}

// ── 寄信 · 落款混乱（新结构：keys 是 uid，values[0] 是 roleName）──
function pickChaosSignature(chaosConfig, a_private_group, platform, sendname) {
    let finalSignature = `落款：${sendname}`;
    if (Math.random() < (chaosConfig.mistakenSignature / 100)) {
        const allRoleNames = Object.values(a_private_group[platform] || {}).map(v => v[0]).filter(n => n && n !== sendname);
        if (allRoleNames.length) finalSignature = `落款：${allRoleNames[Math.floor(Math.random() * allRoleNames.length)]}`;
    }
    return finalSignature;
}

// ── 寄信 · 误投：按概率把收件人换成其他角色 ──
function pickChaosRecipient(chaosConfig, a_private_group, platform, toname, toUidForLetter) {
    let trueRecipientName = toname;
    let trueRecipientUid = toUidForLetter;
    if (Math.random() < (chaosConfig.misdelivery / 100)) {
        const otherEntries = Object.entries(a_private_group[platform] || {}).filter(([, v]) => v[0] !== toname);
        if (otherEntries.length) {
            const pick = otherEntries[Math.floor(Math.random() * otherEntries.length)];
            trueRecipientUid = pick[0];
            trueRecipientName = pick[1][0];
        }
    }
    return { trueRecipientName, trueRecipientUid };
}

// ── 寄信 · 残页：信被撕成两半，后半页（含落款）误投给随机第三人 ──
function pickTornPage(chaosConfig, a_private_group, platform, senderUid, trueRecipientUid, content) {
    if (Math.random() >= (chaosConfig.tornPage / 100)) return null;
    if (content.length < 10) return null; // 太短，撕不出两半
    const others = Object.entries(a_private_group[platform] || {})
        .filter(([u, v]) => u !== String(senderUid) && u !== String(trueRecipientUid) && v && v[0]);
    if (!others.length) return null;
    const pick = others[Math.floor(Math.random() * others.length)];
    const cut = Math.ceil(content.length / 2);
    return {
        firstHalf: content.slice(0, cut),
        secondHalf: content.slice(cut),
        holderUid: pick[0],
        holderName: pick[1][0],
        holderGid: pick[1][1],
    };
}

// ── 寄信 · 主流程：校验 → 侵蚀 → 落款/误投/残页 → 投递/存档/计数/公开 ──
async function handleNaturalChaosLetter(ctx, msg, platform, sendname, toname, contentOriginal) {
    const st = chaosLetterPrecheck(ctx, msg, platform, sendname, toname);
    if (!st) return;
    const { realSendname, a_private_group, toUidForLetter, chaosConfig, uid, cooldownKey, now, gameDay, globalChaosCounts, userKey, userRec } = st;

    const erodedContent = applyChaosErosion(contentOriginal, chaosConfig);
    const finalSignature = pickChaosSignature(chaosConfig, a_private_group, platform, sendname);
    const { trueRecipientName, trueRecipientUid } = pickChaosRecipient(chaosConfig, a_private_group, platform, toname, toUidForLetter);

    // 拉黑检查：无论是本人指定收件人还是被系统随机错投，只要最终收件人拉黑了发送者就拦截，
    // 保护的是"实际会看到内容的人"，不是发送者当初打算投给谁
    const smsSenderUid = getPrimaryUid(platform, uid);
    const smsBlockEntry = getBlockEntry(platform, trueRecipientUid, smsSenderUid);
    if (smsBlockEntry) {
        if (smsBlockEntry.silent) {
            // 静默拉黑：伪装成功，连每日次数/冷却都照常消耗，避免"怎么不限次数了"暴露拉黑
            cachedSet(cooldownKey, now.toString());
            userRec.count += 1;
            globalChaosCounts[userKey] = userRec;
            kvSet("global_chaos_letter_counts", globalChaosCounts);
            const receiptText = `🕊️ 信件已由鸽子衔往 ${toname} 处。今日已发 ${userRec.count}/${chaosConfig.dailyLimit}。\n${RECALL_RECEIPT_HINT}`;
            // 静默拉黑也照常记一笔发错撤回（无投递），撤回时的回复跟正常短信一样，不暴露拉黑
            trackSentItem({
                type: "sms", platform, senderUid: smsSenderUid, senderGid: msg.groupId.replace(`${platform}-Group:`, ""),
                toName: toname, cmdMsgId: getMsgRawId(msg), cmdText: msg.message, cmdAt: now, receiptText, sentAt: now, deliveries: [],
                undo: { userKey, day: userRec.day, cooldownKey, cooldownAt: now }
            });
            seal.replyToSender(ctx, msg, receiptText);
        } else {
            seal.replyToSender(ctx, msg, `❌ ${trueRecipientName} 已拒绝你的联络。`);
        }
        return;
    }

    // 残页触发时：收件人只拿到前半页（无落款），后半页连同落款落到第三人手里
    const torn = pickTornPage(chaosConfig, a_private_group, platform, uid, trueRecipientUid, erodedContent);
    const content = torn ? torn.firstHalf + "\n（信纸的后半页不知去向……）" : erodedContent;
    const recipientSignature = torn ? "（落款在缺失的后半页上）" : finalSignature;

    const targetEntry = a_private_group[platform]?.[trueRecipientUid];
    if (!targetEntry) {
        seal.replyToSender(ctx, msg, "❌ 短信投递失败：找不到收件人所在群组。");
        return;
    }
    const newmsg = seal.newMessage();
    newmsg.messageType = "group";
    newmsg.groupId = `${platform}-Group:${targetEntry[1]}`;
    const newctx = seal.createTempCtx(ctx.endPoint, newmsg);

    const notice = applyMsgTemplate("sms_notice", {
        "收件人": trueRecipientName, "收件人QQ": trueRecipientUid,
        "内容": content, "落款": recipientSignature
    }) || `[CQ:at,qq=${trueRecipientUid}]\n📱 ${trueRecipientName}，你收到一条短信：\n「${content}」\n\n${recipientSignature}`;
    seal.replyToSender(newctx, newmsg, notice);
    recordInteractionStat(platform, sendname, trueRecipientName, "sms");
    // 发错撤回：记下每一处投递，撤回时去这些群里找回并删除
    const recallDeliveries = [{ gid: String(targetEntry[1]), snippet: content, at: Date.now() }];

    // 残页的后半页投递给第三人（带落款）
    if (torn) {
        const holderEntry = a_private_group[platform]?.[torn.holderUid];
        if (holderEntry) {
            const tMsg = seal.newMessage();
            tMsg.messageType = "group";
            tMsg.groupId = `${platform}-Group:${holderEntry[1]}`;
            const tCtx = seal.createTempCtx(ctx.endPoint, tMsg);
            seal.replyToSender(tCtx, tMsg,
                `[CQ:at,qq=${torn.holderUid}]\n🍂 ${torn.holderName}，一页残破的信纸飘落到你手里：\n「……${torn.secondHalf}」\n\n${finalSignature}`);
            recallDeliveries.push({ gid: String(holderEntry[1]), snippet: torn.secondHalf, at: Date.now() });
        }
    }

    // 提前判断是否公开（需在存档前确定，以便写入 hide_receiver）
    const hideReceiverOnDrop = cachedGet("drop_hide_receiver") === "true";
    const letterPublicEnabled = kvGet("letter_public_send", false);
    const adminGidForSms = kvGet("adminAnnounceGroupId", null);
    const isPublicSms = letterPublicEnabled && adminGidForSms &&
        (Math.floor(Math.random() * 100) + 1 <= chaosConfig.publicChance);

    // 短信实时存档（timestamp 同时记进发错撤回记录，撤回时按它精确删存档条目）
    const smsArchiveTs = Date.now();
    if (isArchiveEnabled()) {
        const isMisdelivered    = trueRecipientName !== toname;
        const isContentChaos    = content !== contentOriginal;
        const isSignatureChaos  = finalSignature !== `落款：${sendname}`;
        postToArchive("/api/event", {
            type:            "sms",
            from_role:       realSendname,
            from_custom_name: sendname !== realSendname ? sendname : undefined,
            from_qq:         uid,
            to_role:         trueRecipientName,
            to_qq:           trueRecipientUid,
            content:         contentOriginal,
            extra_info: {
                delivered:          content,
                signature:          finalSignature,
                intended_to:        toname,
                is_misdelivered:    isMisdelivered,
                is_content_chaos:   isContentChaos,
                is_signature_chaos: isSignatureChaos,
                is_torn:            !!torn,
                torn_holder:        torn ? torn.holderName : undefined,
                torn_second_half:   torn ? torn.secondHalf : undefined,
                is_chaos:           isMisdelivered || isContentChaos || isSignatureChaos || !!torn,
                isPublic:           isPublicSms,
                hide_receiver:      isPublicSms && hideReceiverOnDrop
            },
            game_day:   gameDay,
            session_id: "",
            timestamp:  smsArchiveTs
        });
    }

    // 7. 更新数据
    cachedSet(cooldownKey, now.toString());
    userRec.count += 1;
    globalChaosCounts[userKey] = userRec;
    kvSet("global_chaos_letter_counts", globalChaosCounts);

    const smsReceiptText = `🕊️ 信件已由鸽子衔往 ${toname} 处。今日已发 ${userRec.count}/${chaosConfig.dailyLimit}。\n${RECALL_RECEIPT_HINT}`;
    seal.replyToSender(ctx, msg, smsReceiptText);

    // 公开逻辑
    if (isPublicSms) {
        const pMsg = seal.newMessage();
        pMsg.messageType = "group";
        pMsg.groupId = `${platform}-Group:${adminGidForSms}`;
        const pCtx = seal.createTempCtx(ctx.endPoint, pMsg);
        const publicContent = chaosConfig.publicShowEffect ? content : contentOriginal;
        const publicTo = hideReceiverOnDrop ? "某人" : toname;
        seal.replyToSender(pCtx, pMsg, applyMsgTemplate("sms_broadcast", {
            "发送者": sendname, "收件人": publicTo, "内容": publicContent
        }) || `💌 公开信件：\n「${sendname}」→「${publicTo}」\n内容：「${publicContent}」`);
        recallDeliveries.push({ gid: String(adminGidForSms), snippet: publicContent, at: Date.now() });
    }

    trackSentItem({
        type: "sms", platform, senderUid: smsSenderUid, senderGid: msg.groupId.replace(`${platform}-Group:`, ""),
        toName: toname, cmdMsgId: getMsgRawId(msg), cmdText: msg.message, cmdAt: now, receiptText: smsReceiptText, sentAt: Date.now(),
        deliveries: recallDeliveries,
        stat: { from: sendname, to: trueRecipientName, type: "sms", skipReceived: false },
        archive: { type: "sms", from_role: realSendname, to_role: trueRecipientName, timestamp: smsArchiveTs },
        undo: { userKey, day: userRec.day, cooldownKey, cooldownAt: now }
    });

    if (typeof recordMeetingAndAnnounce === "function") {
        recordMeetingAndAnnounce("寄信", platform, ctx, ctx.endPoint);
    }
}

// ========================
// 🏢 官约与目击系统
// ========================

let cmd_create_official_appointment = seal.ext.newCmdItemInfo();
cmd_create_official_appointment.name = "发起官约";
cmd_create_official_appointment.help = "。发起官约 D1 14:00-15:00 地点 参与者1/参与者2/...（管理员专用，自动创建官方约会群组）";

cmd_create_official_appointment.solve = async (ctx, msg, cmdArgs) => {
  if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, `只有管理员可以发起官约`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const day = cmdArgs.getArgN(1);
  const time = cmdArgs.getArgN(2);
  const place = cmdArgs.getArgN(3);
  const participantsRaw = cmdArgs.getArgN(4);

  if (!day || !time || !place || !participantsRaw) {
    seal.replyToSender(ctx, msg, `格式：。发起官约 D1 14:00-15:00 地点 参与者1/参与者2/...`);
    return seal.ext.newCmdExecuteResult(true);
  }

  if (!isValidTimeFormat(time)) {
    seal.replyToSender(ctx, msg, `请输入合法的时间格式，如 14:00-16:00，且结束时间需大于开始时间`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const participants = participantsRaw.replace(/，/g, "/").split("/").map(n => n.trim()).filter(Boolean);

  const dupNames = [...new Set(participants.filter((n, i) => participants.indexOf(n) !== i))];
  if (dupNames.length > 0) {
    seal.replyToSender(ctx, msg, `参与者列表中有重复的名字：${dupNames.join("、")}，请检查后重新发送`);
    return seal.ext.newCmdExecuteResult(true);
  }
  const platform = msg.platform;
  const a_private_group = kvGet("a_private_group", {});
  const a_lockedSlots = kvGet("a_lockedSlots", {});
  const b_confirmedSchedule = kvGet("b_confirmedSchedule", {});

  if (!a_private_group[platform]) {
    seal.replyToSender(ctx, msg, `当前平台没有绑定任何角色`);
    return seal.ext.newCmdExecuteResult(true);
  }

  let validParticipants = [];
  let invalidParticipants = [];

  for (let name of participants) {
    if (getUidByRoleName(platform, name)) {
      validParticipants.push(name);
    } else {
      invalidParticipants.push(name);
    }
  }

  if (invalidParticipants.length > 0) {
    seal.replyToSender(ctx, msg, `以下参与者未找到：${invalidParticipants.join("、")}`);
    return seal.ext.newCmdExecuteResult(true);
  }

  // 检查时间冲突逻辑
  let conflictParticipants = [];
  for (let name of validParticipants) {
    const uid = getUidByRoleName(platform, name);
    const key = `${platform}:${uid}`;
    const locked = a_lockedSlots[key]?.[day] || [];
    if (locked.some(slot => timeOverlap(slot, time))) {
      conflictParticipants.push(`${name}（被锁定）`);
      continue;
    }
    const schedule = b_confirmedSchedule[key] || [];
    if (schedule.some(ev => ev.day === day && timeOverlap(ev.time, time))) {
      conflictParticipants.push(`${name}（已有安排）`);
      continue;
    }
  }

  if (conflictParticipants.length > 0) {
    seal.replyToSender(ctx, msg, `以下参与者时间冲突：\n${conflictParticipants.join("\n")}`);
    return seal.ext.newCmdExecuteResult(true);
  }

  // 分配群号+建群公共副作用（写日程/过期信息/公告改名/目击检测/互动计数/计时器，见 finishGroupCreation）
  const alloc = await beginGroupCreation(platform, ctx, msg);
  if (!alloc) return seal.ext.newCmdExecuteResult(true);
  const { gid, expireTime, timeStr } = alloc;

  const groupData = { day, time, place, subtype: "官约" };
  const groupNameTag = validParticipants.length > 2 ? "多人" : validParticipants.join("、");
  const finalGroupName = `${getCustomTypeLabel("官约")} ${day} ${time} ${place} ${groupNameTag}`;
  const officialGuide = buildAppointmentGuide(gid, day);
  const groupAnnouncement = `🎖️ 官约已确认\n\n📅 ${day} ${time}\n📍 ${place}\n👥 参与者：${validParticipants.join("、")}\n\n群号：${gid}\n有效至 ${timeStr}${officialGuide}`;
  const noticeText = `🎖️ 官约通知\n\n📅 ${day} ${time}\n📍 ${place}\n👥 参与者：${validParticipants.join("、")}\n\n💬 官约群号：${gid}`;

  finishGroupCreation({
      platform, ctx, msg, gid, expireTime, groupData,
      participants: validParticipants,
      groupAnnouncement, finalGroupName, noticeText,
      partnerFor: () => `官约（${validParticipants.join("、")}）`
  });

  seal.replyToSender(ctx, msg, `✅ 官约创建成功！群号：${gid}`);
  return seal.ext.newCmdExecuteResult(true);
};

ext.cmdMap["发起官约"] = cmd_create_official_appointment;

// ========================
// 📞 官电系统
// ========================

let cmd_create_official_call = seal.ext.newCmdItemInfo();
cmd_create_official_call.name = "发起官电";
cmd_create_official_call.help = "。发起官电 D1 14:00-15:00 参与者1/参与者2/...（管理员专用，自动创建官方电话群组）";

cmd_create_official_call.solve = async (ctx, msg, cmdArgs) => {
  if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, `只有管理员可以发起官电`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const day = cmdArgs.getArgN(1);
  const time = cmdArgs.getArgN(2);
  const participantsRaw = cmdArgs.getArgN(3);

  if (!day || !time || !participantsRaw) {
    seal.replyToSender(ctx, msg, `格式：。发起官电 D1 14:00-15:00 参与者1/参与者2/...`);
    return seal.ext.newCmdExecuteResult(true);
  }

  if (!isValidTimeFormat(time)) {
    seal.replyToSender(ctx, msg, `请输入合法的时间格式，如 14:00-16:00，且结束时间需大于开始时间`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const participants = participantsRaw.replace(/，/g, "/").split("/").map(n => n.trim()).filter(Boolean);
  const platform = msg.platform;
  const a_private_group = kvGet("a_private_group", {});
  const a_lockedSlots = kvGet("a_lockedSlots", {});
  const b_confirmedSchedule = kvGet("b_confirmedSchedule", {});

  if (!a_private_group[platform]) {
    seal.replyToSender(ctx, msg, `当前平台没有绑定任何角色`);
    return seal.ext.newCmdExecuteResult(true);
  }

  let validParticipants = [];
  let invalidParticipants = [];

  for (let name of participants) {
    if (getUidByRoleName(platform, name)) {
      validParticipants.push(name);
    } else {
      invalidParticipants.push(name);
    }
  }

  if (invalidParticipants.length > 0) {
    seal.replyToSender(ctx, msg, `以下参与者未找到：${invalidParticipants.join("、")}`);
    return seal.ext.newCmdExecuteResult(true);
  }

  let conflictParticipants = [];
  for (let name of validParticipants) {
    const uid = getUidByRoleName(platform, name);
    const key = `${platform}:${uid}`;
    const locked = a_lockedSlots[key]?.[day] || [];
    if (locked.some(slot => timeOverlap(slot, time))) {
      conflictParticipants.push(`${name}（被锁定）`);
      continue;
    }
    const schedule = b_confirmedSchedule[key] || [];
    if (schedule.some(ev => ev.day === day && timeOverlap(ev.time, time))) {
      conflictParticipants.push(`${name}（已有安排）`);
      continue;
    }
  }

  if (conflictParticipants.length > 0) {
    seal.replyToSender(ctx, msg, `以下参与者时间冲突：\n${conflictParticipants.join("\n")}`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const alloc = await beginGroupCreation(platform, ctx, msg);
  if (!alloc) return seal.ext.newCmdExecuteResult(true);
  const { gid, expireTime, timeStr } = alloc;

  const groupData = { day, time, place: "电话", subtype: "电话" };
  const groupNameTag = validParticipants.length > 2 ? "多人" : validParticipants.join("、");
  const finalGroupName = `官电 ${day} ${time} ${groupNameTag}`;
  const callGuide = buildAppointmentGuide(gid, day);
  const groupAnnouncement = `📞 官电已确认\n\n📅 ${day} ${time}\n👥 参与者：${validParticipants.join("、")}\n\n群号：${gid}\n有效至 ${timeStr}${callGuide}`;
  const noticeText = `📞 官电通知\n\n📅 ${day} ${time}\n👥 参与者：${validParticipants.join("、")}\n\n💬 官电群号：${gid}`;

  finishGroupCreation({
      platform, ctx, msg, gid, expireTime, groupData,
      participants: validParticipants,
      groupAnnouncement, finalGroupName, noticeText,
      partnerFor: () => `官电（${validParticipants.join("、")}）`
  });

  seal.replyToSender(ctx, msg, `✅ 官电创建成功！群号：${gid}`);
  return seal.ext.newCmdExecuteResult(true);
};

ext.cmdMap["发起官电"] = cmd_create_official_call;

// ========================
// 📞 前置电话：管理员安排一份"暗中名单"（编号↔角色名，玩家不可见），
// 玩家凭编号表达"想接谁的电话"的意向（不知道编号对应谁），管理员据此批量牵线、建电话小群。
// 场次不占用真实日程时间线，统一用哨兵天数 D100（timeConflict 只按 day 字符串精确匹配，
// D100 不会跟任何真实天数冲突）；建好的群其余部分（结束/字数结算/结戏奖励等）
// 跟普通电话小群完全一样，需要结束时照常用「强结私约」「取消官约」按群号操作。
// ========================
function getPretelList() {
    return kvGet("pretel_list", {});
}
function savePretelList(list) {
    kvSet("pretel_list", list);
}
function getPretelPicks() {
    return kvGet("pretel_picks", {});
}
function savePretelPicks(picks) {
    kvSet("pretel_picks", picks);
}
// 模式："不收集"＝管理员用「设置前置电话名单」手动录入；"收集"＝玩家自助用「前置电话收集」提交，
// 收齐后随机打乱分配编号。不设置也能直接用「设置前置电话名单」（等价于「不收集」）。
function getPretelMode() {
    return kvGet("pretel_mode", "不收集");
}
function savePretelMode(mode) {
    kvSet("pretel_mode", mode);
}
function getPretelCollection() {
    return kvGet("pretel_collection", []);
}
function savePretelCollection(list) {
    kvSet("pretel_collection", list);
}
function getPretelShowGender() {
    return kvGet("pretel_show_gender", false);
}
function savePretelShowGender(v) {
    kvSet("pretel_show_gender", v);
}
// 当前平台已注册且未被标记为 NPC 的角色数量，用作"收集齐了没有"的判断基准
function getPretelEligibleCount(platform) {
    const storage = getRoleStorage()[platform] || {};
    const npcList = kvGet("a_npc_list", []);
    return Object.values(storage).filter(entry => entry[0] && !npcList.includes(entry[0])).length;
}
function shuffleArray(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

let cmd_pretel_toggle_mode = seal.ext.newCmdItemInfo();
cmd_pretel_toggle_mode.name = "开启前置电话";
cmd_pretel_toggle_mode.help = `【管理员】开启新一轮前置电话，选择本轮名单产生方式+是否显示性别（会清空上一轮的名单/收集内容/选择记录）
开启前置电话 收集/不收集 显示性别/不显示性别
收集   —— 玩家自助用「前置电话收集 内容」提交，收齐后随机打乱分配编号
不收集 —— 管理员自己用「设置前置电话名单」手动录入编号↔角色名
显示性别 —— 「查看前置电话收集」每条内容前会带上该角色的性别，方便按喜好挑，仍不会透露是谁
示例：开启前置电话 收集 显示性别`;
cmd_pretel_toggle_mode.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) return seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
    const mode = cmdArgs.getArgN(1);
    const genderMode = cmdArgs.getArgN(2);
    if (mode !== "收集" && mode !== "不收集") {
        return seal.replyToSender(ctx, msg, "格式：开启前置电话 收集/不收集 显示性别/不显示性别");
    }
    if (genderMode !== "显示性别" && genderMode !== "不显示性别") {
        return seal.replyToSender(ctx, msg, "格式：开启前置电话 收集/不收集 显示性别/不显示性别");
    }
    savePretelMode(mode);
    savePretelShowGender(genderMode === "显示性别");
    savePretelList({});
    savePretelPicks({});
    savePretelCollection([]);
    return seal.replyToSender(ctx, msg, `✅ 已开启新一轮前置电话，模式：${mode}，${genderMode}。上一轮的名单/收集内容/选择记录已清空。`);
};
ext.cmdMap["开启前置电话"] = cmd_pretel_toggle_mode;

let cmd_pretel_set_list = seal.ext.newCmdItemInfo();
cmd_pretel_set_list.name = "设置前置电话名单";
cmd_pretel_set_list.help = `【管理员】设置前置电话的暗中名单（编号↔角色名，玩家看不到这份对照），会覆盖上一轮名单并清空所有人已选的意向
仅"不收集"模式下可用（默认即为此模式，或先「开启前置电话 不收集」切换）
格式：每行一条「编号 角色名」，支持多行一次性录入
示例：
设置前置电话名单
1 张三
2 李四
3 王五`;
cmd_pretel_set_list.solve = (ctx, msg) => {
    if (!isUserAdmin(ctx, msg)) return seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
    if (getPretelMode() !== "不收集") {
        return seal.replyToSender(ctx, msg, "❌ 当前是「收集」模式，名单由玩家自助提交产生。要手动录入请先「开启前置电话 不收集」。");
    }

    const rawMsg = (msg.rawMessage || msg.message || "").trim();
    const msgLines = rawMsg.split(/\r?\n/);
    const firstRest = msgLines[0].replace(/^设置前置电话名单\s*/, "").trim();
    const lines = [...(firstRest ? [firstRest] : []), ...msgLines.slice(1).map(l => l.trim()).filter(Boolean)];
    if (!lines.length) return seal.replyToSender(ctx, msg, cmd_pretel_set_list.help);

    const platform = msg.platform;
    const list = {};
    const invalid = [];
    for (const line of lines) {
        const m = line.match(/^(\d+)\s+(.+)$/);
        if (!m) { invalid.push(line); continue; }
        const [, num, name] = m;
        if (!getUidByRoleName(platform, name)) { invalid.push(line); continue; }
        list[num] = name;
    }
    if (invalid.length) {
        return seal.replyToSender(ctx, msg, `❌ 以下行格式错误或角色不存在，未保存任何内容：\n${invalid.join("\n")}`);
    }

    savePretelList(list);
    savePretelPicks({});
    return seal.replyToSender(ctx, msg,
        `✅ 前置电话名单已设置，共 ${Object.keys(list).length} 个编号（具体对应关系仅你可见）。\n已清空所有人此前的选择，请让玩家重新选。`);
};
ext.cmdMap["设置前置电话名单"] = cmd_pretel_set_list;

let cmd_pretel_view = seal.ext.newCmdItemInfo();
cmd_pretel_view.name = "查看前置电话";
cmd_pretel_view.help = "【管理员】查看当前所有玩家的前置电话选择（已解码为真实角色名，仅管理员可见）";
cmd_pretel_view.solve = (ctx, msg) => {
    if (!isUserAdmin(ctx, msg)) return seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
    const list = getPretelList();
    const picks = getPretelPicks();
    if (!Object.keys(list).length) return seal.replyToSender(ctx, msg, "❌ 当前没有前置电话名单，用「设置前置电话名单」先设置。");
    const pickerNames = Object.keys(picks).filter(n => picks[n] && picks[n].length);
    if (!pickerNames.length) return seal.replyToSender(ctx, msg, "📭 暂无人做出选择。");
    const lines = pickerNames.map(name => {
        const targets = picks[name].map(num => `${list[num] || "?"}(${num})`).join("、");
        return `${name} 选了：${targets}`;
    });
    return seal.replyToSender(ctx, msg, `📞 前置电话选择一览（共 ${pickerNames.length} 人已选）：\n${lines.join("\n")}`);
};
ext.cmdMap["查看前置电话"] = cmd_pretel_view;

let cmd_pretel_arrange = seal.ext.newCmdItemInfo();
cmd_pretel_arrange.name = "安排前置电话";
cmd_pretel_arrange.help = `【管理员】根据玩家的前置电话选择批量牵线、创建电话小群
安排前置电话 只连双选   —— 只有互选（A选了B的编号，B也选了A的编号）才连线
安排前置电话 都选       —— 只要有一方选了对方就连线
一次性建好本轮所有电话小群，并各给参与者发一条汇总提醒；执行后会清空本轮选择记录，避免重复安排。`;
cmd_pretel_arrange.solve = async (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) return seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
    const mode = cmdArgs.getArgN(1);
    if (mode !== "只连双选" && mode !== "都选") {
        return seal.replyToSender(ctx, msg, "格式：安排前置电话 只连双选 / 安排前置电话 都选");
    }

    const platform = msg.platform;
    const list = getPretelList();
    const picks = getPretelPicks();
    if (!Object.keys(list).length) return seal.replyToSender(ctx, msg, "❌ 当前没有前置电话名单。");

    // 反查角色名对应的编号，用于"只连双选"判断对方是否也选了自己
    const nameToNum = {};
    for (const [num, name] of Object.entries(list)) nameToNum[name] = num;

    // 收集配对，key 用两个名字排序拼接去重，避免 A→B / B→A 被算成两条
    const pairs = new Map();
    for (const [picker, nums] of Object.entries(picks)) {
        for (const num of nums) {
            const target = list[num];
            if (!target || target === picker) continue;
            const targetNum = nameToNum[picker];
            const targetPickedPicker = targetNum ? (picks[target] || []).includes(targetNum) : false;
            const connect = mode === "都选" ? true : targetPickedPicker;
            if (!connect) continue;
            const key = [picker, target].sort().join("↔");
            if (!pairs.has(key)) pairs.set(key, [picker, target].sort());
        }
    }

    if (!pairs.size) return seal.replyToSender(ctx, msg, "📭 按当前模式没有可连接的配对。");

    const day = "D100";
    const time = "00:00-23:59";
    const a_private_group = kvGet("a_private_group", {});
    const callCountByName = {};
    const createdGroups = [];
    const failedPairs = [];
    // 只清掉真正建成群的那两个人对应的选择；建群失败（含群号池耗尽后中断的剩余配对）的
    // 选择原样保留，避免一次意外就把大家的选择全部冲掉、事后只能让所有人重新选
    const remainingPicks = JSON.parse(JSON.stringify(picks));
    const consumePick = (name, otherName) => {
        const num = nameToNum[otherName];
        if (num && remainingPicks[name]) {
            remainingPicks[name] = remainingPicks[name].filter(n => n !== num);
        }
    };

    const pairList = [...pairs.values()];
    for (let i = 0; i < pairList.length; i++) {
        const [nameA, nameB] = pairList[i];
        const uidA = getUidByRoleName(platform, nameA);
        const uidB = getUidByRoleName(platform, nameB);
        if (!uidA || !uidB) { failedPairs.push(`${nameA}↔${nameB}（角色未找到）`); continue; }

        const gid = await allocateGroup(platform, ctx, msg);
        if (!gid) {
            for (let j = i; j < pairList.length; j++) {
                failedPairs.push(`${pairList[j][0]}↔${pairList[j][1]}（群号池已空）`);
            }
            break;
        }

        const validParticipants = [nameA, nameB];
        const b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
        for (const name of validParticipants) {
            const uid = getUidByRoleName(platform, name);
            const key = `${platform}:${uid}`;
            if (!b_confirmedSchedule[key]) b_confirmedSchedule[key] = [];
            b_confirmedSchedule[key].push({
                day, time, partner: validParticipants.find(n => n !== name),
                subtype: "电话", place: "电话", group: gid, status: "active"
            });
        }
        kvSet("b_confirmedSchedule", b_confirmedSchedule);

        const acceptTime = Date.now();
        const expireHours = getStorageInt("group_expire_hours", 48);
        const expireTime = acceptTime + expireHours * 60 * 60 * 1000;
        let groupInfo = kvGet("group_expire_info", {});
        groupInfo[gid] = { acceptTime, expireTime, participants: validParticipants, subtype: "电话", day, time, place: "电话" };
        kvSet("group_expire_info", groupInfo);

        const finalGroupName = `前置电话 ${validParticipants.join("、")}`;
        const targetMsg = seal.newMessage();
        targetMsg.messageType = "group";
        targetMsg.groupId = `${platform}-Group:${gid}`;
        const targetCtx = seal.createTempCtx(ctx.endPoint, targetMsg);
        setGroupName(targetCtx, targetMsg, gid, finalGroupName);

        const callGuide = buildAppointmentGuide(gid, day);
        seal.replyToSender(targetCtx, targetMsg,
            `📞 前置电话已接通\n\n👥 ${validParticipants.join("、")}\n\n群号：${gid}\n有效至 ${new Date(expireTime).toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" })}${callGuide}`);

        for (const name of validParticipants) {
            const nameUid = getUidByRoleName(platform, name);
            const boundGroupId = nameUid ? a_private_group[platform]?.[nameUid]?.[1] : null;
            callCountByName[name] = (callCountByName[name] || 0) + 1;
            if (!boundGroupId) continue;
            const newmsg = seal.newMessage();
            newmsg.messageType = "group";
            newmsg.groupId = `${platform}-Group:${boundGroupId}`;
            const newctx = seal.createTempCtx(ctx.endPoint, newmsg);
            seal.replyToSender(newctx, newmsg, `[CQ:at,qq=${nameUid}]\n📞 你有一通前置电话已接通\n\n💬 群号：${gid}`);
        }

        if (typeof initGroupTimer === "function") {
            initGroupTimer(platform, gid, "电话", validParticipants, validParticipants[0]);
        }
        createdGroups.push(gid);
        consumePick(nameA, nameB);
        consumePick(nameB, nameA);
    }

    // 每人再发一条本轮汇总提醒
    for (const [name, count] of Object.entries(callCountByName)) {
        const nameUid = getUidByRoleName(platform, name);
        const boundGroupId = nameUid ? a_private_group[platform]?.[nameUid]?.[1] : null;
        if (!boundGroupId) continue;
        const summaryMsg = seal.newMessage();
        summaryMsg.messageType = "group";
        summaryMsg.groupId = `${platform}-Group:${boundGroupId}`;
        const summaryCtx = seal.createTempCtx(ctx.endPoint, summaryMsg);
        seal.replyToSender(summaryCtx, summaryMsg, `[CQ:at,qq=${nameUid}]\n📞 你共有 ${count} 个前置电话待接听，去对应的群里看看吧～`);
    }

    savePretelPicks(remainingPicks);

    let report = `✅ 已按「${mode}」安排 ${createdGroups.length} 个前置电话（涉及 ${Object.keys(callCountByName).length} 人）。`;
    if (failedPairs.length) report += `\n⚠️ 以下未能建群，相关选择已保留、修好问题后可重新「安排前置电话」补建：\n${failedPairs.join("\n")}`;
    return seal.replyToSender(ctx, msg, report);
};
ext.cmdMap["安排前置电话"] = cmd_pretel_arrange;

// ========================
// 🛠️ 人工登记（海豹掉线应急用）
// ========================
// 场景：海豹中途掉线，管理员已经人工手动拉群处理了私约/官约/电话，
// 恢复后需要把这场记录补进系统，让「时间线」查得到、群里的到期/复盘计时器也照常跑。
// 不建群、不改群名、不发任何通知——群是人工已经弄好的，这里只回填数据。

let cmd_manual_backfill = seal.ext.newCmdItemInfo();
cmd_manual_backfill.name = "人工登记";
cmd_manual_backfill.help = "。人工登记 类型 群号 D几 时间段 [地点] 参与者1/参与者2/...（管理员专用，海豹掉线期间人工处理完私约/官约/电话后，用此指令补齐参与者时间线并启动该群的计时器（含复盘所需的场次开始时间）；只回填数据，不建群/不改群名/不发通知；类型支持 私约/官约/电话，电话类型省略地点）";

cmd_manual_backfill.solve = async (ctx, msg, cmdArgs) => {
  if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, `只有管理员可以使用人工登记`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const typeArg = cmdArgs.getArgN(1);
  const subtypeMap = { "私约": "私密", "私密": "私密", "官约": "官约", "电话": "电话" };
  const subtype = subtypeMap[typeArg];
  if (!subtype) {
    seal.replyToSender(ctx, msg, `⚠️ 类型不支持，请使用：私约 / 官约 / 电话\n格式：。人工登记 类型 群号 D几 时间段 [地点] 参与者1/参与者2/...`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const gid = cmdArgs.getArgN(2);
  const day = cmdArgs.getArgN(3);
  const time = cmdArgs.getArgN(4);
  const place = subtype === "电话" ? "电话" : cmdArgs.getArgN(5);
  const participantsRaw = subtype === "电话" ? cmdArgs.getArgN(5) : cmdArgs.getArgN(6);

  if (!gid || !day || !time || !participantsRaw || (subtype !== "电话" && !place)) {
    const example = subtype === "电话"
      ? `。人工登记 电话 群号 D1 14:00-15:00 张三/李四`
      : `。人工登记 ${typeArg} 群号 D1 14:00-15:00 地点 张三/李四`;
    seal.replyToSender(ctx, msg, `⚠️ 参数不足，正确格式：\n${example}`);
    return seal.ext.newCmdExecuteResult(true);
  }

  if (!/^\d+$/.test(gid)) {
    seal.replyToSender(ctx, msg, `群号需为纯数字`);
    return seal.ext.newCmdExecuteResult(true);
  }

  if (!isValidTimeFormat(time)) {
    seal.replyToSender(ctx, msg, `请输入合法的时间格式，如 14:00-16:00，且结束时间需大于开始时间`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const participants = participantsRaw.replace(/，/g, "/").split("/").map(n => n.trim()).filter(Boolean);
  const dupNames = [...new Set(participants.filter((n, i) => participants.indexOf(n) !== i))];
  if (dupNames.length > 0) {
    seal.replyToSender(ctx, msg, `参与者列表中有重复的名字：${dupNames.join("、")}，请检查后重新发送`);
    return seal.ext.newCmdExecuteResult(true);
  }
  if (participants.length < 2) {
    seal.replyToSender(ctx, msg, `参与者至少需要2人`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const platform = msg.platform;
  const a_private_group = kvGet("a_private_group", {});
  if (!a_private_group[platform]) {
    seal.replyToSender(ctx, msg, `当前平台没有绑定任何角色`);
    return seal.ext.newCmdExecuteResult(true);
  }

  let validParticipants = [];
  let invalidParticipants = [];
  for (let name of participants) {
    if (getUidByRoleName(platform, name)) {
      validParticipants.push(name);
    } else {
      invalidParticipants.push(name);
    }
  }
  if (invalidParticipants.length > 0) {
    seal.replyToSender(ctx, msg, `以下参与者未找到：${invalidParticipants.join("、")}`);
    return seal.ext.newCmdExecuteResult(true);
  }

  // 该群号是否已有登记中的场次，避免覆盖正在进行中的记录
  const groupExpireInfo = kvGet("group_expire_info", {});
  if (groupExpireInfo[gid]) {
    const existing = groupExpireInfo[gid];
    seal.replyToSender(ctx, msg, `⚠️ 群号 ${gid} 已有登记中的记录（${existing.subtype} ${existing.day} ${existing.time}），如需覆盖请先「强结私约 ${gid}」`);
    return seal.ext.newCmdExecuteResult(true);
  }

  // 时间冲突检查，口径同「发起官约」
  const a_lockedSlots = kvGet("a_lockedSlots", {});
  const b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
  let conflictParticipants = [];
  for (let name of validParticipants) {
    const uid = getUidByRoleName(platform, name);
    const key = `${platform}:${uid}`;
    const locked = a_lockedSlots[key]?.[day] || [];
    if (locked.some(slot => timeOverlap(slot, time))) {
      conflictParticipants.push(`${name}（被锁定）`);
      continue;
    }
    const schedule = b_confirmedSchedule[key] || [];
    if (schedule.some(ev => timeConflict(day, time, ev.day, ev.time))) {
      conflictParticipants.push(`${name}（已有安排）`);
    }
  }
  if (conflictParticipants.length > 0) {
    seal.replyToSender(ctx, msg, `以下参与者时间冲突：\n${conflictParticipants.join("\n")}`);
    return seal.ext.newCmdExecuteResult(true);
  }

  // 群号若还在空闲池里，标记占用，避免之后被自动分配系统二次派发
  const groupPool = kvGet("group", []);
  if (groupPool.includes(gid)) {
    kvSet("group", groupPool.map(g => g === gid ? gid + "_占用" : g));
  }

  // --- 登记时间线 ---
  for (let name of validParticipants) {
    const uid = getUidByRoleName(platform, name);
    const key = `${platform}:${uid}`;
    if (!b_confirmedSchedule[key]) b_confirmedSchedule[key] = [];
    const partner = subtype === "官约"
      ? `官约（${validParticipants.join("、")}）`
      : (validParticipants.length > 2 ? "多人小群" : validParticipants.find(n => n !== name));
    b_confirmedSchedule[key].push({
      day, time, place, partner, subtype, group: gid, status: "active"
    });
  }
  kvSet("b_confirmedSchedule", b_confirmedSchedule);

  // --- 群过期/计时信息 ---
  const acceptTime = Date.now();
  const expireHours = getStorageInt("group_expire_hours", 48);
  const expireTime = acceptTime + expireHours * 60 * 60 * 1000;
  groupExpireInfo[gid] = {
    acceptTime, expireTime, participants: validParticipants,
    subtype, day, time, place
  };
  kvSet("group_expire_info", groupExpireInfo);

  // --- 启动该群的状态计时器（含复盘要用的场次开始时间）---
  if (typeof initGroupTimer === "function") {
    initGroupTimer(platform, gid, subtype, validParticipants, validParticipants[0]);
  }

  const placeLine = subtype !== "电话" ? ` 📍 ${place}` : "";
  seal.replyToSender(ctx, msg, `✅ 已为群 ${gid} 补登记 ${getCustomTypeLabel(subtype)}\n📅 ${day} ${time}${placeLine}\n👥 参与者：${validParticipants.join("、")}\n（仅回填时间线与计时器数据，未发送任何通知）`);
  return seal.ext.newCmdExecuteResult(true);
};

ext.cmdMap["人工登记"] = cmd_manual_backfill;

// ========================
// 📋 Binary Tag 管理
// ========================

let cmd_modify_tag = seal.ext.newCmdItemInfo();
cmd_modify_tag.name = "修改tag";
cmd_modify_tag.help = "。修改tag tag名字 种类1:姓名1，姓名2 种类2:姓名3，姓名4（管理员专用，创建/更新 binary tag 并分配玩家）";

cmd_modify_tag.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "只有管理员可以使用此功能");
        return seal.ext.newCmdExecuteResult(true);
    }

    const tagName = cmdArgs.getArgN(1);
    const rest = cmdArgs.args.slice(1).join(' ').trim();
    if (!tagName || !rest) {
        seal.replyToSender(ctx, msg, "格式：。修改tag tag名字 种类1:姓名1，姓名2 种类2:姓名3，姓名4");
        return seal.ext.newCmdExecuteResult(true);
    }

    // 解析 "种类1:姓名1，姓名2 种类2:姓名3，姓名4"
    const catPattern = /([^\s：:]+)[：:]\s*([^：:]+?)(?=\s+[^\s：:]+[：:]|$)/g;
    const catMatches = [...rest.matchAll(catPattern)];

    if (catMatches.length < 2) {
        seal.replyToSender(ctx, msg, "格式错误：需要至少两个种类。\n格式：。修改tag tag名字 种类1:姓名1，姓名2 种类2:姓名3，姓名4");
        return seal.ext.newCmdExecuteResult(true);
    }

    const tags = store.get("sys_binary_tags");
    tags[tagName] = {};
    for (const m of catMatches) {
        const catName = m[1].trim();
        const names = m[2].trim().split(/[，,、\s]+/).map(s => s.trim()).filter(Boolean);
        tags[tagName][catName] = names;
    }
    store.set("sys_binary_tags", tags);

    let reply = `✅ 已更新 tag「${tagName}」：\n`;
    for (const [cat, names] of Object.entries(tags[tagName])) {
        reply += `  · ${cat}：${names.join("、")}\n`;
    }
    seal.replyToSender(ctx, msg, reply.trim());
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["修改tag"] = cmd_modify_tag;

// 📋 便捷官约：计划官约 + 执行官约
// ========================

let cmd_plan_official = seal.ext.newCmdItemInfo();
cmd_plan_official.name = "计划官约";
cmd_plan_official.help = "。计划官约 tag名字/无 组数 D几 时间段 地点1，地点2，...（管理员专用，生成官约分组方案）";

cmd_plan_official.solve = (ctx, msg, cmdArgs) => {
  if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, `只有管理员可以使用此功能`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const tagArg     = cmdArgs.getArgN(1);
  const groupCount = parseInt(cmdArgs.getArgN(2));
  const day        = cmdArgs.getArgN(3);
  const time       = cmdArgs.getArgN(4);
  const placesRaw  = cmdArgs.getArgN(5);

  if (!tagArg || isNaN(groupCount) || groupCount <= 0 || !day || !time || !placesRaw) {
    seal.replyToSender(ctx, msg, `格式：。计划官约 tag名字/无 组数 D几 时间段 地点1，地点2，...\n示例：。计划官约 贵族 2 D1 14:00-16:00 咖啡厅，公园\n示例：。计划官约 无 2 D1 14:00-16:00 咖啡厅，公园`);
    return seal.ext.newCmdExecuteResult(true);
  }

  if (!isValidTimeFormat(time)) {
    seal.replyToSender(ctx, msg, `请输入合法的时间格式，如 14:00-16:00，且结束时间需大于开始时间`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const wantTag = (tagArg !== "无");
  const platform = msg.platform;

  // 解析地点（支持中英文逗号）
  const places = placesRaw.replace(/,/g, "，").split("，").map(p => p.trim()).filter(Boolean);
  if (places.length !== groupCount) {
    seal.replyToSender(ctx, msg, `❌ 建设不成功：地点数量（${places.length}）与组数（${groupCount}）不一致，请确保地点和组数相同`);
    return seal.ext.newCmdExecuteResult(true);
  }

  // 获取所有非NPC玩家
  const apg = store.get("a_private_group")[platform] || {};
  const npcList = kvGet("a_npc_list", []);
  const allPlayers = Object.entries(apg)
    .map(([uid, val]) => ({ uid, name: val[0] }))
    .filter(p => p.name && !npcList.includes(p.name));

  if (allPlayers.length === 0) {
    seal.replyToSender(ctx, msg, `❌ 当前平台没有非NPC玩家`);
    return seal.ext.newCmdExecuteResult(true);
  }
  if (groupCount > allPlayers.length) {
    seal.replyToSender(ctx, msg, `❌ 组数(${groupCount})不能大于玩家总数(${allPlayers.length})`);
    return seal.ext.newCmdExecuteResult(true);
  }

  // 检查所有玩家的时间冲突
  const a_lockedSlots      = kvGet("a_lockedSlots", {});
  const b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
  let conflictPlayers = [];
  for (let p of allPlayers) {
    const key = `${platform}:${p.uid}`;
    const locked = a_lockedSlots[key]?.[day] || [];
    if (locked.some(slot => timeOverlap(slot, time))) {
      conflictPlayers.push(`${p.name}（被锁定）`);
      continue;
    }
    const schedule = b_confirmedSchedule[key] || [];
    if (schedule.some(ev => ev.day === day && timeOverlap(ev.time, time))) {
      conflictPlayers.push(`${p.name}（已有安排）`);
    }
  }
  if (conflictPlayers.length > 0) {
    seal.replyToSender(ctx, msg, `❌ 建设不成功：以下玩家时间冲突：\n${conflictPlayers.join("\n")}`);
    return seal.ext.newCmdExecuteResult(true);
  }

  // 分组（Fisher-Yates 洗牌）
  const shuffle = arr => {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  };

  let groups = Array.from({ length: groupCount }, () => []);
  if (wantTag) {
    const allTags = store.get("sys_binary_tags");
    const tagData = allTags[tagArg];
    if (!tagData || Object.keys(tagData).length === 0) {
      seal.replyToSender(ctx, msg, `❌ 未找到 tag「${tagArg}」，请先使用「。修改tag」创建`);
      return seal.ext.newCmdExecuteResult(true);
    }

    const nameToPlayer = {};
    for (const p of allPlayers) nameToPlayer[p.name] = p;

    const buckets = Object.values(tagData).map(names =>
      shuffle(names.filter(n => nameToPlayer[n]).map(n => nameToPlayer[n]))
    );

    const assignedNames = new Set(Object.values(tagData).flat());
    const unassigned = shuffle(allPlayers.filter(p => !assignedNames.has(p.name)));

    const maxLen = Math.max(...buckets.map(b => b.length), 0);
    const indices = buckets.map(() => 0);
    for (let r = 0; r < maxLen; r++) {
      for (let b = 0; b < buckets.length; b++) {
        if (indices[b] < buckets[b].length) {
          groups[r % groupCount].push(buckets[b][indices[b]++].name);
        }
      }
    }
    unassigned.forEach((p, idx) => { groups[idx % groupCount].push(p.name); });
  } else {
    shuffle(allPlayers).forEach((p, idx) => { groups[idx % groupCount].push(p.name); });
  }

  // 保存方案
  const planGroups = groups.map((members, i) => ({ participants: members, place: places[i] }));
  const plan = { platform, day, time, groupCount, groups: planGroups };
  kvSet("a_quick_official_plan", plan);

  // 展示方案
  let resp = `📋 官约方案已生成${wantTag ? `（${tagArg} 交替模式）` : ""}：\n`;
  resp += `📅 ${day} ${time}\n━━━━━━━━━━━━━━\n`;
  planGroups.forEach((g, i) => {
    resp += `第 ${i + 1} 组 📍${g.place}：${g.participants.join("、")}\n`;
  });
  resp += `━━━━━━━━━━━━━━\n✅ 方案已保存，使用「。执行官约」一键发起所有官约`;
  seal.replyToSender(ctx, msg, resp);
  return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["计划官约"] = cmd_plan_official;

// ---

let cmd_execute_official = seal.ext.newCmdItemInfo();
cmd_execute_official.name = "执行官约";
cmd_execute_official.help = "。执行官约（管理员专用，一键执行已保存的官约方案）";

cmd_execute_official.solve = async (ctx, msg, cmdArgs) => {
  if (!isUserAdmin(ctx, msg)) {
    seal.replyToSender(ctx, msg, `只有管理员可以执行官约`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const plan = kvGet("a_quick_official_plan", null);
  if (!plan) {
    seal.replyToSender(ctx, msg, `❌ 没有已保存的官约方案，请先使用「。计划官约」生成方案`);
    return seal.ext.newCmdExecuteResult(true);
  }

  if (plan.platform !== msg.platform) {
    seal.replyToSender(ctx, msg, `❌ 保存的方案属于其他平台，请重新计划`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const { day, time, groups } = plan;
  const platform = msg.platform;
  const apg = store.get("a_private_group");

  // 执行前再次校验时间冲突（防止方案过期）
  const a_lockedSlots = kvGet("a_lockedSlots", {});
  const b_confirmedSchedule_check = kvGet("b_confirmedSchedule", {});
  let conflictPlayers = [];
  for (let g of groups) {
    for (let name of g.participants) {
      const uid = getUidByRoleName(platform, name);
      if (!uid) continue;
      const key = `${platform}:${uid}`;
      const locked = a_lockedSlots[key]?.[day] || [];
      if (locked.some(slot => timeOverlap(slot, time))) {
        conflictPlayers.push(`${name}（被锁定）`);
        continue;
      }
      const schedule = b_confirmedSchedule_check[key] || [];
      if (schedule.some(ev => ev.day === day && timeOverlap(ev.time, time))) {
        conflictPlayers.push(`${name}（已有安排）`);
      }
    }
  }
  if (conflictPlayers.length > 0) {
    seal.replyToSender(ctx, msg, `❌ 执行失败，方案可能已过期，以下玩家时间冲突：\n${conflictPlayers.join("\n")}\n请重新「。计划官约」`);
    return seal.ext.newCmdExecuteResult(true);
  }

  const expireHours = getStorageInt("group_expire_hours", 48);
  const formatTime = (ts) => new Date(ts).toLocaleString("zh-CN", { year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit' });

  let results = [];
  let failed  = [];

  for (let i = 0; i < groups.length; i++) {
    const { participants, place } = groups[i];

    // 验证参与者仍然存在
    const invalidP = participants.filter(n => !getUidByRoleName(platform, n));
    if (invalidP.length > 0) {
      failed.push(`第${i + 1}组：找不到玩家 ${invalidP.join("、")}`);
      continue;
    }

    // 分配群号
    const gid = await allocateGroup(platform, ctx, msg);
    if (!gid) {
      failed.push(`第${i + 1}组：暂无可用群号`);
      continue;
    }

    const acceptTime = Date.now();
    const expireTime = acceptTime + expireHours * 60 * 60 * 1000;

    // 更新日程（每次重新读写，避免多组之间覆盖）
    const bcs = kvGet("b_confirmedSchedule", {});
    for (let name of participants) {
      const uid = getUidByRoleName(platform, name);
      const key = `${platform}:${uid}`;
      if (!bcs[key]) bcs[key] = [];
      bcs[key].push({ day, time, partner: `官约（${participants.join("、")}）`, subtype: "官约", place, group: gid, status: "active" });
    }
    kvSet("b_confirmedSchedule", bcs);

    // 记录群组过期信息
    const groupInfo = kvGet("group_expire_info", {});
    groupInfo[gid] = { acceptTime, expireTime, participants, subtype: "官约", day, time, place };
    kvSet("group_expire_info", groupInfo);

    // 改群名
    const groupNameTag = participants.length > 2 ? "多人" : participants.join("、");
    const finalGroupName = `${getCustomTypeLabel("官约")} ${day} ${time} ${place} ${groupNameTag}`;
    const targetMsg = seal.newMessage();
    targetMsg.messageType = "group";
    targetMsg.groupId = `${platform}-Group:${gid}`;
    const targetCtx = seal.createTempCtx(ctx.endPoint, targetMsg);
    setGroupName(targetCtx, targetMsg, gid, finalGroupName);

    // 向戏群发公告
    const execGuide = buildAppointmentGuide(gid, day);
    const execExpireStr = new Date(expireTime).toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
    seal.replyToSender(targetCtx, targetMsg, `🎖️ 官约已确认\n\n📅 ${day} ${time}\n📍 ${place}\n👥 参与者：${participants.join("、")}\n\n群号：${gid}\n有效至 ${execExpireStr}${execGuide}`);

    // 向每位参与者的绑定群发送通知
    for (let name of participants) {
      const uid = getUidByRoleName(platform, name);
      const boundGroupId = uid ? apg[platform]?.[uid]?.[1] : null;
      if (!boundGroupId) continue;
      const newmsg = seal.newMessage();
      newmsg.messageType = "group";
      newmsg.groupId = `${platform}-Group:${boundGroupId}`;
      const newctx = seal.createTempCtx(ctx.endPoint, newmsg);
      seal.replyToSender(newctx, newmsg, `[CQ:at,qq=${uid}]\n🎖️ 官约通知\n\n📅 ${day} ${time}\n📍 ${place}\n👥 参与者：${participants.join("、")}\n\n💬 官约群号：${gid}`);
    }

    // 启动计时器
    if (typeof initGroupTimer === "function") {
      initGroupTimer(platform, gid, "官约", participants, participants[0]);
    }

    recordMeetingAndAnnounce("官约", platform, ctx, ctx.endPoint);
    results.push(`第${i + 1}组 [${gid}]：${participants.join("、")} @ ${place}`);
  }

  // 清空方案
  kvSet("a_quick_official_plan", null);

  let resp = `✅ 便捷官约执行完毕！\n━━━━━━━━━━━━━━\n`;
  if (results.length > 0) resp += results.join("\n");
  if (failed.length > 0)  resp += `\n\n❌ 以下组失败：\n${failed.join("\n")}`;
  seal.replyToSender(ctx, msg, resp);
  return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["执行官约"] = cmd_execute_official;

// ========================
// 👀 目击报告系统 v1.1
// ========================

function getSightingConfig() {
    const defaultConfig = {
        enabled: false,
        send_to_all: true,
        max_reports_per_day: 5,
        trigger_chance: 50,
        include_ended_meetings: false,
        time_overlap_threshold: 0.3
    };
    const config = kvGet("sighting_system_config", {});
    return { ...defaultConfig, ...config };
}

function setSightingConfig(config) {
    kvSet("sighting_system_config", config);
}

function getPlaceSystemConfig() {
    const defaultConfig = { enabled: false, require_key_by_default: false };
    const config = kvGet("place_system_config", {});
    return { ...defaultConfig, ...config };
}

function isSightingEnabled() {
    if (!getSightingConfig().enabled) return false;
    if (!getPlaceSystemConfig().enabled) return false;
    return true;
}

function getUserSightingCountToday(platform, uid) {
    const today = new Date().toISOString().slice(0, 10);
    const sightingCount = kvGet("sighting_daily_count", {});
    return (sightingCount[today] || {})[`${platform}:${uid}`] || 0;
}

function incrementUserSightingCountToday(platform, uid) {
    const today = new Date().toISOString().slice(0, 10);
    const sightingCount = kvGet("sighting_daily_count", {});
    for (const date of Object.keys(sightingCount)) {
        if (date !== today) delete sightingCount[date];
    }
    if (!sightingCount[today]) sightingCount[today] = {};
    sightingCount[today][`${platform}:${uid}`] = (sightingCount[today][`${platform}:${uid}`] || 0) + 1;
    kvSet("sighting_daily_count", sightingCount);
}

function shouldSendSightingReport(platform, roleName) {
    const sightingConfig = getSightingConfig();
    const uid = getUidByRoleName(platform, roleName);
    const todayCount = uid ? getUserSightingCountToday(platform, uid) : 0;
    if (todayCount >= sightingConfig.max_reports_per_day) return false;
    return Math.random() * 100 < (sightingConfig.trigger_chance ?? 50);
}

function calculateTimeOverlapRatio(time1, time2) {
    const [start1, end1] = parseStartEnd(time1);
    const [start2, end2] = parseStartEnd(time2);
    const overlapStart = Math.max(start1, start2);
    const overlapEnd = Math.min(end1, end2);
    if (overlapStart >= overlapEnd) return 0;
    const overlapMinutes = overlapEnd - overlapStart;
    const minDuration = Math.min(end1 - start1, end2 - start2);
    if (minDuration === 0) return 0;
    return overlapMinutes / minDuration;
}

function findSimultaneousMeetings(platform, day, time, place, excludeGroupId = null) {
    const b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
    const groupExpireInfo = kvGet("group_expire_info", {});
    const a_private_group = kvGet("a_private_group", {});
    const sightingConfig = getSightingConfig();

    const seenGroups = new Set();
    const simultaneousMeetings = [];

    for (const [userId, scheduleList] of Object.entries(b_confirmedSchedule)) {
        for (const meeting of scheduleList) {
            if (excludeGroupId && meeting.group === excludeGroupId) continue;
            if (meeting.day !== day || meeting.place !== place) continue;
            if (!meeting.partner) continue;
            if (!sightingConfig.include_ended_meetings && meeting.status === "ended") continue;

            const overlapRatio = calculateTimeOverlapRatio(meeting.time, time);
            if (overlapRatio < sightingConfig.time_overlap_threshold) continue;

            const meetingGroupId = meeting.group;
            if (meetingGroupId && seenGroups.has(meetingGroupId)) continue;
            if (meetingGroupId) seenGroups.add(meetingGroupId);

            const meetingParticipants = [];
            const isSoloStakeout = meeting.partner === "（独自）";
            if (meetingGroupId && groupExpireInfo[meetingGroupId]?.participants?.length) {
                meetingParticipants.push(...groupExpireInfo[meetingGroupId].participants);
            } else {
                if (!isSoloStakeout && meeting.partner !== "多人小群") meetingParticipants.push(meeting.partner);
                const [userPlatform, userUid] = userId.split(':');
                const roleName = a_private_group[userPlatform]?.[userUid]?.[0];
                if (roleName && !meetingParticipants.includes(roleName)) meetingParticipants.push(roleName);
            }

            if (meetingParticipants.length === 0) continue;

            simultaneousMeetings.push({
                groupId: meetingGroupId,
                day: meeting.day,
                time: meeting.time,
                place: meeting.place,
                participants: [...new Set(meetingParticipants)],
                type: meeting.subtype || "未知",
                isEnded: meeting.status === "ended",
                overlapRatio
            });
        }
    }

    simultaneousMeetings.sort((a, b) => b.overlapRatio - a.overlapRatio);
    return simultaneousMeetings;
}

function sendSightingReports(platform, newMeetingInfo, simultaneousMeetings, ctx, msg) {
    if (!ctx || !ctx.endPoint) return;
    const sightingConfig = getSightingConfig();
    const a_private_group = kvGet("a_private_group", {});
    if (!a_private_group[platform]) return;

    const processedReverseMeetings = new Set();

    for (const participant of newMeetingInfo.participants) {
        const participantUid = getUidByRoleName(platform, participant);
        const participantInfo = participantUid ? a_private_group[platform][participantUid] : null;
        if (!participantInfo?.[1]) continue;

        const targetGroupId = participantInfo[1];

        for (const otherMeeting of simultaneousMeetings) {
            if (otherMeeting.participants.includes(participant)) continue;
            if (!shouldSendSightingReport(platform, participant)) continue;

            const otherParticipantsText = otherMeeting.participants.join('、');
            const reportMessage = otherMeeting.participants.length === 1
                ? `👀 不会吧，你居然在 ${newMeetingInfo.place} 看见 ${otherParticipantsText} 一个人去了！（时间：${otherMeeting.time}）`
                : `👀 不会吧，你居然在 ${newMeetingInfo.place} 看见了 ${otherParticipantsText} 在一起！（时间：${otherMeeting.time}）`;

            const newMsg = seal.newMessage();
            newMsg.messageType = "group";
            newMsg.groupId = `${platform}-Group:${targetGroupId}`;
            const tempCtx = seal.createTempCtx(ctx.endPoint, newMsg);
            const atStr = participantUid ? `[CQ:at,qq=${participantUid}]\n` : "";
            try {
                seal.replyToSender(tempCtx, newMsg, `${atStr}${reportMessage}`);
            } catch (err) {
                console.error("[目击] 发送报告失败:", err);
            }

            if (participantUid) incrementUserSightingCountToday(platform, participantUid);

            if (sightingConfig.send_to_all && !processedReverseMeetings.has(otherMeeting.groupId)) {
                processedReverseMeetings.add(otherMeeting.groupId);
                sendCounterSightingReports(platform, otherMeeting, newMeetingInfo, ctx);
            }
        }
    }
}

function sendCounterSightingReports(platform, originalMeeting, newMeetingInfo, ctx) {
    if (!ctx || !ctx.endPoint) {
        console.error("[ERROR] sendCounterSightingReports: ctx 或 ctx.endPoint 无效，无法发送反向报告");
        return;
    }
    const a_private_group = kvGet("a_private_group", {});
    if (!a_private_group[platform]) return;
    const sightingConfig = getSightingConfig();

    for (const participant of originalMeeting.participants) {
        const participantUid = getUidByRoleName(platform, participant);
        const participantInfo = participantUid ? a_private_group[platform][participantUid] : null;
        if (!participantInfo || !participantInfo[1]) continue;

        if (participantUid) {
            const todayCount = getUserSightingCountToday(platform, participantUid);
            if (todayCount >= sightingConfig.max_reports_per_day) continue;
        }

        const newParticipantsText = newMeetingInfo.participants.join('、');
        const reportMessage = originalMeeting.participants.length === 1
            ? `👀 哎呀，你在 ${originalMeeting.place} 的独自行动被 ${newParticipantsText} 看到了！（时间：${originalMeeting.time}）`
            : `👀 哎呀，你和${originalMeeting.participants.length > 1 ? '伙伴们' : '朋友'}在 ${originalMeeting.place} 的约会被 ${newParticipantsText} 看到了！（时间：${originalMeeting.time}）`;

        const targetGroupId = participantInfo[1];
        const newMsg = seal.newMessage();
        newMsg.messageType = "group";
        newMsg.groupId = `${platform}-Group:${targetGroupId}`;
        const tempCtx = seal.createTempCtx(ctx.endPoint, newMsg);
        const atStr = participantUid ? `[CQ:at,qq=${participantUid}]\n` : "";
        try {
            seal.replyToSender(tempCtx, newMsg, `${atStr}${reportMessage}`);
        } catch (err) {
            console.error("[ERROR] 发送反向目击报告失败:", err);
            continue;
        }

        if (participantUid) incrementUserSightingCountToday(platform, participantUid);
    }
}

async function createSoloStakeout(ctx, msg, platform, sendname, day, time, place) {
    const alloc = await beginGroupCreation(platform, ctx, msg);
    if (!alloc) return;
    const { gid, expireTime, timeStr } = alloc;

    const groupData = { sendname, subtype: "踩点", day, time, place };
    const finalGroupName = `踩点 ${day} ${time} ${sendname}`;
    const guide = `\n\n结束互动 ➜ 在群内发「结束私约」`;
    const groupAnnouncement = `🕵️ 踩点（独行）\n\n📅 ${day} ${time}\n📍 ${place}\n👤 ${sendname}\n\n群号：${gid}\n有效至 ${timeStr}${guide}`;

    finishGroupCreation({
        platform, ctx, msg, gid, expireTime, groupData,
        participants: [sendname],
        groupAnnouncement, finalGroupName,
        partnerFor: () => "（独自）"
    });

    seal.replyToSender(ctx, msg, `✅ 已发起独自踩点！\n📅 ${day} ${time}  📍 ${place}\n群号：${gid}\n有效至 ${timeStr}`);
}

async function handleStakeout(ctx, msg, cmdArgs) {
    const toggle = kvGet("global_feature_toggle", {});
    if (!toggle.dlc_stakeout) {
        return seal.replyToSender(ctx, msg, "❌ 踩点功能未开启，请联系管理员。");
    }

    const platform = msg.platform;
    const uid = msg.sender.userId.replace(`${platform}:`, "");
    const a_private_group = kvGet("a_private_group", {});
    const sendname = a_private_group[platform]?.[uid]?.[0];
    if (!sendname) return seal.replyToSender(ctx, msg, "✨ 请先使用「创建新角色」来认领你的身份。");

    const timeArg = cmdArgs.getArgN(1);
    const placeArg = cmdArgs.getArgN(2);
    const targetArg = cmdArgs.getArgN(3);

    if (!timeArg || !placeArg) {
        return seal.replyToSender(ctx, msg, "⚠️ 格式：踩点 时间 地点 [角色名]\n例：踩点 20:00 大图书馆\n例：踩点 20:00 大图书馆 李四");
    }

    const globalDay = cachedGet("global_days") || "未知日期";

    if (!targetArg) {
        // 独立存储键（非 global_feature_toggle 的子字段），默认开启，管理员可在网页端「踩点」分区关闭
        if (cachedGet("stakeout_allow_solo") === "false") {
            return seal.replyToSender(ctx, msg, "❌ 踩点需要指定陪伴角色名，管理员已关闭「允许单人踩点」。");
        }
        return createSoloStakeout(ctx, msg, platform, sendname, globalDay, timeArg, placeArg);
    }

    // 踩点门槛独立于私密门槛，读取网页端「踩点门槛」配置（appointment_duration_config.stakeout）
    const stakeoutDuration = kvGet("appointment_duration_config", {}).stakeout;
    const aliasConfig = { trigger: "踩点", icon: "🕵️", minDuration: stakeoutDuration !== undefined ? stakeoutDuration : 59 };
    const fakeCmdArgs = {
        getArgN: (n) => [null, timeArg, placeArg, targetArg][n] || "",
        args: [timeArg, placeArg, targetArg]
    };
    return cmd_appointment_private.solve(ctx, msg, fakeCmdArgs, aliasConfig);
}

function triggerSightingCheck(platform, day, time, place, participants, groupId, subtype, ctx, msg) {
    if (!isSightingEnabled()) return;

    const newMeetingInfo = { day, time, place, participants, groupId, subtype };
    const simultaneousMeetings = findSimultaneousMeetings(platform, day, time, place, groupId);

    if (simultaneousMeetings.length > 0) {
        sendSightingReports(platform, newMeetingInfo, simultaneousMeetings, ctx, msg);
    }
}
// ========================
// ⏰ 监听系统核心函数（修改版）
// ========================

// 超时时长健全性上限：网页端(小时)↔机器人(毫秒)换算若被重复应用（如「推送全部」误把毫秒当小时
// 再推一次）会指数级爆炸成天文数字，导致 elapsed 永远追不上 timeoutDuration、超时提醒失效。
// 任何超过此上限的值一律视为损坏，回退默认值/基础超时，避免再需要手动改库才能恢复。
const MAX_REASONABLE_TIMEOUT_MS = 7 * 24 * 3600 * 1000; // 7 天
function sanitizeTimeoutMs(v, fallback) {
    return (typeof v === "number" && isFinite(v) && v > 0 && v <= MAX_REASONABLE_TIMEOUT_MS) ? v : fallback;
}

/**
 * 获取监听设置
 */
function getMonitorSettings() {
    const defaultSettings = {
        enabled: true,
        timeout: 10800000,          // 180分钟，统一超时时间
        remind_interval: 10800000,  // 180分钟，统一提醒间隔
        auto_monitor_all_groups: true
    };

    const settings = kvGet("monitor_settings", {});
    const merged = { ...defaultSettings, ...settings };
    merged.timeout = sanitizeTimeoutMs(merged.timeout, defaultSettings.timeout);
    merged.remind_interval = sanitizeTimeoutMs(merged.remind_interval, defaultSettings.remind_interval);
    for (const k of ["timeout_phone", "timeout_private", "timeout_wish", "timeout_official"]) {
        if (k in merged) {
            const safe = sanitizeTimeoutMs(merged[k], null);
            if (safe === null) delete merged[k]; else merged[k] = safe;
        }
    }
    return merged;
}

/**
 * 获取群组计时器
 */
function getGroupTimers() {
    return kvGet("group_timers", {});
}

/**
 * 保存群组计时器
 */
function saveGroupTimers(timers) {
    kvSet("group_timers", timers);
}

/**
 * 获取用户统计
 */
function getUserStats() {
    return kvGet("user_stats", {});
}

function saveUserStats(stats) {
    kvSet("user_stats", stats);
}

function getInteractionCounts() {
    return kvGet("interaction_counts", {});
}

function saveInteractionCounts(counts) {
    kvSet("interaction_counts", counts);
}

// type: "sms" | "gift" | "appt"；skipReceived=true 时只记发送方 sent，不记收件方 received
function recordInteractionStat(platform, fromRole, toRole, type, skipReceived = false) {
    if (!fromRole || !toRole || fromRole === toRole) return;
    const counts = getInteractionCounts();
    const fromKey = `${platform}:${fromRole}`;
    const toKey = `${platform}:${toRole}`;
    const sentField = `${type}_sent`;
    const recvField = `${type}_received`;

    if (!counts[fromKey]) counts[fromKey] = {};
    if (!counts[fromKey][sentField]) counts[fromKey][sentField] = {};
    counts[fromKey][sentField][toRole] = (counts[fromKey][sentField][toRole] || 0) + 1;

    if (!skipReceived) {
        if (!counts[toKey]) counts[toKey] = {};
        if (!counts[toKey][recvField]) counts[toKey][recvField] = {};
        counts[toKey][recvField][fromRole] = (counts[toKey][recvField][fromRole] || 0) + 1;
    }

    saveInteractionCounts(counts);
}

function getTop3Text(countMap) {
    if (!countMap || !Object.keys(countMap).length) return null;
    return Object.entries(countMap)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .map(([name, count], i) => `  ${i + 1}. ${name}（${count}次）`)
        .join("\n");
}

function getSessionStats() {
    return kvGet("group_session_stats", {});
}

function saveSessionStats(s) {
    kvSet("group_session_stats", s);
}

// 结戏时把本群字数/段数归入本季累计，供「本场统计」跨场次汇总
function accumulateToSeasonStats(platform, gid) {
    const ss = getSessionStats();
    const groupStat = ss[gid];
    if (!groupStat) return;
    const acc = kvGet("season_player_stats", {});
    if (!acc[platform]) acc[platform] = {};
    for (const [uid, stat] of Object.entries(groupStat)) {
        if (uid === "_startTime") continue;
        if (!acc[platform][uid]) acc[platform][uid] = { replies: 0, words: 0 };
        acc[platform][uid].replies += stat.replies || 0;
        acc[platform][uid].words   += stat.words   || 0;
    }
    kvSet("season_player_stats", acc);
}

/**
 * 结戏时发放加成奖励（模版系统）
 */
function applyEndGameBonuses(ctx, msg, gid, platform, knownSubtype) {
    const templates = kvGet("end_game_bonus_templates", []);
    // group 号会被回收复用，b_confirmedSchedule 里可能残留同一 gid 的旧场次记录，
    // 优先用调用方在清除 group_expire_info 前取到的 subtype（当场数据，无歧义）；
    // 没有传入时（兼容旧调用路径）才退回按 gid 反查 b_confirmedSchedule，且只认未结束场次，降低撞上旧场次的概率
    let groupSubtype = knownSubtype || "";
    if (!groupSubtype) {
        const _bSched = kvGet("b_confirmedSchedule", {});
        outer: for (const evList of Object.values(_bSched)) {
            for (const ev of evList) {
                if (ev.group === gid && ev.subtype && ev.status !== "ended") { groupSubtype = ev.subtype; break outer; }
            }
        }
    }
    // 模版用用户可读名称，群记录用内部名称，做映射对齐
    const tplTypeToStored = { "私约": "私密", "心意": "心愿" };
    const enabled = templates.filter(t => {
        if (!t.enabled) return false;
        const tplType = t.subtype || "通用";
        if (tplType === "通用") return true;
        const resolved = tplTypeToStored[tplType] || tplType;
        return resolved === groupSubtype;
    });

    const sessionStats = getSessionStats();
    const groupStat = sessionStats[gid];
    const playerKeys = groupStat ? Object.keys(groupStat).filter(k => k !== "_startTime") : [];

    if (!enabled.length || !groupStat || !playerKeys.length) {
        accumulateToSeasonStats(platform, gid);
        delete sessionStats[gid];
        saveSessionStats(sessionStats);
        applyEndGameDraws(ctx, msg, gid, platform, playerKeys);
        return;
    }

    const reg = kvGet("item_registry", {});
    const currencyByName = {};
    Object.values(reg).forEach(r => { if (r.type === "currency") currencyByName[r.name] = r.code; });

    const apg = kvGet("a_private_group", {});

    // 查找结戏群对应的地点（供 location_draw 奖励使用）
    const b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
    let endGamePlace = null;
    for (const [, events] of Object.entries(b_confirmedSchedule)) {
        for (const event of events) {
            if (event.group === gid && event.place) { endGamePlace = event.place; break; }
        }
        if (endGamePlace) break;
    }
    const endGamePoolName = endGamePlace ? `${endGamePlace}池` : null;
    const poolDefs = seal.ext.find("changriRPG") ? kvGet("pool_definitions", {}) : null;
    let drawRecords = kvGet("player_draw_records", {});
    let drawRecordsChanged = false;
    const currentDrawDay = cachedGet("global_days") || "";

    // 计算游戏耗时（分钟）
    const elapsedMinutes = groupStat._startTime
        ? Math.floor((Date.now() - groupStat._startTime) / 60000)
        : 0;

    // 条件评估
    function evaluateCondition(op, statVal, value) {
        switch (op) {
            case "=":     return statVal === value;
            case "!=":    return statVal !== value;
            case ">=":    return statVal >= value;
            case "<=":    return statVal <= value;
            case "range": return statVal >= value[0] && statVal <= value[1];
        }
        return false;
    }

    // 概率池抽取
    function drawFromPool(pool) {
        const totalWeight = pool.items.reduce((s, it) => s + it.weight, 0);
        if (totalWeight <= 0) return null;
        let rand = Math.random() * totalWeight;
        for (const item of pool.items) {
            rand -= item.weight;
            if (rand <= 0) return item;
        }
        return pool.items[pool.items.length - 1];
    }

    // 发放单条奖励（playerUid 为 uid），返回显示文字，失败返回 null 并将原因写入 failLines
    function applyRewardItem(playerUid, rewardItem, failLines) {
        const target = (rewardItem.target || "").trim();
        const { targetType, amount } = rewardItem;
        if (!target) {
            failLines.push(`⚠️ 模版中有一条奖励的目标名称为空，跳过（请用「结戏加成 查看」排查模版数据）`);
            return null;
        }
        if (targetType === "currency" || targetType === "item") {
            // 优先按名称查代码，找不到再试 target.toUpperCase()（兼容直接填代码的情况）
            let code = targetType === "currency"
                ? (currencyByName[target] || null)
                : null;
            const reg = getRegistry_rpg();
            if (!code) {
                const upper = target.toUpperCase();
                if (reg[upper]) {
                    code = upper;
                } else {
                    const found = Object.values(reg).find(r => r.name === target);
                    if (found) code = found.code;
                }
            }
            if (!code) {
                failLines.push(`⚠️ 「${target}」未在注册表中找到，跳过`);
                return null;
            }
            const ok = addToInv_system(`${platform}:${playerUid}`, code, amount);
            if (!ok) {
                failLines.push(`⚠️ 「${target}」发放失败（代码 ${code} 不在注册表），跳过`);
                return null;
            }
            const displayName = reg[code]?.name || target;
            return `${displayName}×${amount}`;
        } else {
            // attr：使用 uid-based profile key
            const profileKey = `${platform}:${playerUid}`;
            const profiles = kvGet("sys_char_profiles", {});
            if (!profiles[profileKey]) profiles[profileKey] = {};
            const cur = parseInt(profiles[profileKey][target] || "0");
            profiles[profileKey][target] = String(cur + amount);
            kvSet("sys_char_profiles", profiles);
            return `${target}+${amount}`;
        }
    }

    // 发放地点池抽取机会，返回显示文字（失败返回 null，附带原因到 failLines）
    function applyLocationDraw(playerUid, amount, failLines) {
        if (!endGamePoolName) {
            failLines.push("⚠️ 地点池抽取：本场未绑定地点，跳过");
            return null;
        }
        if (!poolDefs || !poolDefs[endGamePoolName]) {
            failLines.push(`⚠️ 地点池抽取：「${endGamePoolName}」不存在，跳过（可用「一键建池」创建）`);
            return null;
        }
        const recKey = `${platform}:${playerUid}`;
        if (!drawRecords[recKey]) drawRecords[recKey] = { day: "", used: {}, extra: {} };
        if (drawRecords[recKey].day !== currentDrawDay) { drawRecords[recKey].day = currentDrawDay; drawRecords[recKey].used = {}; }
        if (!drawRecords[recKey].extra) drawRecords[recKey].extra = {};
        drawRecords[recKey].extra[endGamePoolName] = (drawRecords[recKey].extra[endGamePoolName] || 0) + amount;
        drawRecordsChanged = true;
        return `「${endGamePoolName}」抽取×${amount}`;
    }

    const report = [];

    // playerKeys 中的 key 现在是 uid
    for (const playerUid of playerKeys) {
        const roleName = resolveUidToName(platform, playerUid);
        const stat = groupStat[playerUid];
        const avgWords = stat.replies > 0 ? Math.floor(stat.words / stat.replies) : 0;

        const getStatVal = (param) => {
            switch (param) {
                case "本场个人段数":       return stat.replies;
                case "本场个人总字数":     return stat.words;
                case "本场个人平均每段字数": return avgWords;
                case "结戏最多耗费时间":   return elapsedMinutes;
            }
            return 0;
        };

        const fixedLines = [];
        const poolLines = [];
        const failLines = [];

        function processReward(r) {
            const prob = (r.prob == null) ? 100 : r.prob;
            if (prob < 100 && Math.random() * 100 >= prob) return;
            if (!r.type || r.type === "fixed") {
                const result = applyRewardItem(playerUid, r, failLines);
                if (result) fixedLines.push(result);
            } else if (r.type === "pool" && r.items.length) {
                const drawn = drawFromPool(r);
                if (drawn) {
                    const result = applyRewardItem(playerUid, drawn, failLines);
                    if (result) {
                        const total = r.items.reduce((s, it) => s + it.weight, 0);
                        const pct = total > 0 ? Math.round(drawn.weight / total * 100) : 0;
                        poolLines.push(`${result}（${pct}%）`);
                    }
                }
            } else if (r.type === "location_draw") {
                const result = applyLocationDraw(playerUid, r.amount || 1, failLines);
                if (result) fixedLines.push(result);
            } else if (r.type === "named_draw") {
                const pn = r.pool_name;
                const amt = r.amount || 1;
                if (!pn) { failLines.push("⚠️ 指定池抽取：池子名为空，跳过"); }
                else {
                    const recKey = `${platform}:${playerUid}`;
                    if (!drawRecords[recKey]) drawRecords[recKey] = { day: "", used: {}, extra: {} };
                    if (drawRecords[recKey].day !== currentDrawDay) { drawRecords[recKey].day = currentDrawDay; drawRecords[recKey].used = {}; }
                    if (!drawRecords[recKey].extra) drawRecords[recKey].extra = {};
                    drawRecords[recKey].extra[pn] = (drawRecords[recKey].extra[pn] || 0) + amt;
                    drawRecordsChanged = true;
                    fixedLines.push(`「${pn}」抽取×${amt}`);
                }
            }
        }

        for (const tpl of enabled) {
            for (const group of tpl.groups) {
                if (group.op === "and") {
                    for (const block of group.blocks) {
                        const allMet = (block.conditions || []).every(c =>
                            evaluateCondition(c.op, getStatVal(c.param), c.value)
                        );
                        if (!allMet) continue;
                        for (const r of (block.rewards || [])) processReward(r);
                    }
                } else if (group.op === "or") {
                    for (const block of group.blocks) {
                        const allMet = (block.conditions || []).every(c =>
                            evaluateCondition(c.op, getStatVal(c.param), c.value)
                        );
                        if (!allMet) continue;
                        for (const r of (block.rewards || [])) processReward(r);
                        break;
                    }
                }
            }
        }

        const allLines = [...fixedLines, ...poolLines];
        if (!allLines.length && !failLines.length) continue;

        report.push(`【${roleName}】${allLines.join("、")}${failLines.length ? "\n  " + failLines.join("\n  ") : ""}`);

        // 个人群艾特通知（新结构：uid为key）
        const roleEntry = apg[platform]?.[playerUid];
        if (roleEntry && allLines.length) {
            const personalGroupId = roleEntry[1];
            const notifyMsg = seal.newMessage();
            notifyMsg.messageType = "group";
            notifyMsg.groupId = `${platform}-Group:${personalGroupId}`;
            const notifyCtx = seal.createTempCtx(ctx.endPoint, notifyMsg);
            const fixedText = fixedLines.join("、");
            const poolText = poolLines.length ? `\n🎲 概率奖励抽中：${poolLines.join("、")}` : "";
            const statsText = `\n✍️ 本场共写了 ${stat.words} 字 / ${stat.replies} 段`;
            const notice = `[CQ:at,qq=${playerUid}]\n🎁 结戏加成已发放：${fixedText}${poolText}${statsText}\n💡 可使用「背包」查看道具与货币，「角色卡」查看属性变更。`;
            seal.replyToSender(notifyCtx, notifyMsg, notice);
        }
    }

    if (drawRecordsChanged) {
        kvSet("player_draw_records", drawRecords);
    }

    // 清除本群本场记录（归档前先累加到季度累计）
    accumulateToSeasonStats(platform, gid);
    delete sessionStats[gid];
    saveSessionStats(sessionStats);

    if (report.length) {
        seal.replyToSender(ctx, msg, `🎁 结戏加成已发放：\n${report.join("\n")}`);
    }

    // 发放结戏抽取机会（sessionStats[gid] 已删，需传入 playerKeys）
    applyEndGameDraws(ctx, msg, gid, platform, playerKeys);
}

/**
 * 结戏时自动发放对应地点的抽取机会（需要先同步踩点池）
 */
function applyEndGameDraws(ctx, msg, gid, platform, playerKeys) {
    const drawConfig = kvGet("end_game_draw_config", {});
    if (!drawConfig.enabled) return;

    const chance = drawConfig.chance ?? 100; // 触发概率 0-100
    const count  = drawConfig.count  ?? 1;  // 每人发放次数

    let poolName;
    if (drawConfig.pool_name) {
        poolName = drawConfig.pool_name;
    } else {
        // 未指定池名，回退到地点池
        const b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
        let place = null;
        for (const [, events] of Object.entries(b_confirmedSchedule)) {
            for (const event of events) {
                if (event.group === gid && event.place) { place = event.place; break; }
            }
            if (place) break;
        }
        if (!place) return;
        poolName = `${place}池`;
    }

    // 调用方在删除 sessionStats[gid] 前传入 playerKeys；无传参时兜底读 storage（不含 _startTime）
    const participants = playerKeys
        ? playerKeys.filter(k => k !== "_startTime")
        : Object.keys((getSessionStats()[gid]) || {}).filter(k => k !== "_startTime");
    if (!participants.length) return;

    if (!seal.ext.find("changriRPG")) return;

    const records = kvGet("player_draw_records", {});
    const awardedList = [];

    const apgPlatform = kvGet("a_private_group", {})[platform] || {};
    for (const uid of participants) {
        if (uid === "_startTime") continue;
        // 概率检定
        if (Math.random() * 100 >= chance) continue;

        const key = `${platform}:${uid}`;
        let rec = records[key] || { day: "", used: {}, extra: {} };
        const currentDay = cachedGet("global_days") || "";
        if (rec.day !== currentDay) { rec.day = currentDay; rec.used = {}; }
        if (!rec.extra) rec.extra = {};

        rec.extra[poolName] = (rec.extra[poolName] || 0) + count;
        records[key] = rec;
        awardedList.push(apgPlatform[uid]?.[0] || uid);
    }

    if (awardedList.length) {
        kvSet("player_draw_records", records);
        const chanceText = chance < 100 ? `（${chance}%概率触发）` : "";
        seal.replyToSender(ctx, msg, `🎰 结戏抽取${chanceText}：已为 ${awardedList.join("、")} 发放「${poolName}」抽取机会 ×${count}`);
    }
}

/**
 * 初始化群组计时器（修正版）
 * 修改：过滤掉已拒绝的参与者
 */
function initGroupTimer(platform, groupId, subtype, participants, initiator) {
    const settings = getMonitorSettings();
    if (!settings.enabled) return;
    
    // 获取多人邀约状态，过滤掉已拒绝的参与者
    const b_MultiGroupRequest = kvGet("b_MultiGroupRequest", {});
    const multiGroup = Object.values(b_MultiGroupRequest).find(g => 
        g.sendname === initiator && 
        g.participants && 
        g.participants.includes(initiator)
    );
    
    // 如果有多人邀约状态，过滤掉已拒绝的人
    let activeParticipants = [...participants];
    if (multiGroup && multiGroup.targetList) {
        activeParticipants = participants.filter(participant => {
            const status = multiGroup.targetList[participant];
            // 只包括已接受和待回应的参与者（status 未设置时为 undefined，用 == null 同时匹配 null/undefined）
            return status === "accepted" || status == null;
        });
    }
    
    // 如果没有活跃参与者，不创建计时器
    if (activeParticipants.length === 0) return;
    
    const timers = getGroupTimers();
    const now = Date.now();
    
    // 获取超时时间：优先使用服务端下发的分场次配置，其次单一 timeout，最后兜底默认
    const _subtypeTimeoutKey = { "电话": "timeout_phone", "私密": "timeout_private", "心愿": "timeout_wish", "官约": "timeout_official" }[subtype];
    const getTimeout = () => (_subtypeTimeoutKey && settings[_subtypeTimeoutKey]) || settings.timeout || 10800000;
    
    // 判断计时模式：2人使用轮流模式，多人使用独立模式
    const isTwoPerson = activeParticipants.length === 2;
    
    // 初始化计时器状态
    const timerData = {
        platform: platform,
        groupId: groupId,
        subtype: subtype,
        startTime: now,
        participants: activeParticipants, // 使用过滤后的参与者
        timerStatus: {},
        lastRemindTime: null,
        timeoutDuration: getTimeout(),
        timerMode: isTwoPerson ? "turn_taking" : "independent"
    };
    
    if (isTwoPerson) {
        // 一对一邀约：轮流模式
        timerData.timerStatus[initiator] = {
            status: "timing",
            startTime: now,
            repliedTime: null,
            wordCount: 0,
            remindedTimes: 0,
            isInitiator: true,
            sessionReplies: 0,
            sessionWords: 0
        };

        const receiver = activeParticipants.find(p => p !== initiator);
        if (receiver) {
            timerData.timerStatus[receiver] = {
                status: "waiting",
                startTime: null,
                repliedTime: null,
                wordCount: 0,
                remindedTimes: 0,
                isInitiator: false,
                sessionReplies: 0,
                sessionWords: 0
            };
        }
    } else {
        // 多人邀约：独立模式
        activeParticipants.forEach(participant => {
            const isInitiator = participant === initiator;
            timerData.timerStatus[participant] = {
                status: "timing", // 独立模式中，所有人一开始都计时
                startTime: now,
                repliedTime: null,
                wordCount: 0,
                remindedTimes: 0,
                isInitiator: isInitiator,
                sessionReplies: 0,
                sessionWords: 0
            };
        });
    }
    
    timers[groupId] = timerData;
    saveGroupTimers(timers);

    // 记录游戏真正开始时间，供结戏加成的"结戏最多耗费时间"使用
    // （计时器在结戏前会被清理，所以需要提前写入 sessionStats）
    // 强制重置：上一场若未走「结束私约/强结」流程，残留的 _startTime 和字数
    // 会让新场次合并进旧 session_id 并继承旧统计，必须清掉
    const _initSS = getSessionStats();
    _initSS[groupId] = { _startTime: now };
    saveSessionStats(_initSS);

    console.log(`[监听系统] 初始化群组 ${groupId} 的计时器，参与者：${activeParticipants.join(',')}，模式：${isTwoPerson ? '轮流模式' : '独立模式'}`);
}


/**
 * 处理回复（监听消息时调用）
 * 已集成：计时状态更新、字数校验、转发逻辑、以及写帖进度计数
 */
// 从消息首行提取角色名对应的正文。支持三种握手写法：
// 「角色名\n正文」「角色名 正文」（腾讯客户端有时把换行转成空格）「角色名：正文」（半角/全角冒号，剧本式书写，可与空格混用）
// 均不匹配时返回 null，判定为闲聊，不入档/不计字数。
function extractRoleContent(message, roleName) {
    const lines = (message || "").split("\n");
    const first = lines[0].trim();
    const rest = lines.slice(1).join("\n").trim();
    if (first === roleName) return rest || null;
    if (!first.startsWith(roleName)) return null;
    let tail = first.slice(roleName.length);
    const beforeLen = tail.length;
    tail = tail.replace(/^[\s:：]+/, "");
    if (tail.length === beforeLen) return null; // 名字后没有分隔符，是别的角色名的前缀（如"张三丰"之于"张"），不算匹配
    const combined = (tail.trim() + (rest ? "\n" + rest : "")).trim();
    return combined || null;
}

// 返回当前时刻相对本季档期的区段：'pre'|'main'|'supplement'|'post'。
// 未设置档期（season_schedule_start 为空）时始终视为 'main'，不影响没启用档期功能的季度。
// 逻辑与 rp_archive/app.py 的 _schedule_zone 保持一致（补戏期/超期只留场次记录，不计弧长）；
// 统一用 UTC+8 位移计算"今天"，不依赖服务器系统时区。
function getScheduleZone() {
    const startStr = cachedGet("season_schedule_start") || "";
    if (!startStr) return "main";
    const endStr  = cachedGet("season_schedule_end") || startStr;
    const suppStr = cachedGet("season_supplement_end") || "";

    const mkDateUTC = (mmdd, year) => {
        if (!mmdd || mmdd.length !== 4) return null;
        const mm = parseInt(mmdd.slice(0, 2), 10), dd = parseInt(mmdd.slice(2), 10);
        if (!mm || !dd) return null;
        return Date.UTC(year, mm - 1, dd);
    };
    // 传入的是"东八区位移过的" epoch ms，取其 UTC 年月日字段即得到北京时间的年月日
    const beijingYMD = (shiftedMs) => {
        const d = new Date(shiftedMs);
        return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
    };

    const todayShifted = Date.now() + 8 * 3600 * 1000;
    const todayUTC = beijingYMD(todayShifted);

    // start 所在的日历年：以「创建本季度时」为基准去猜，而不是用「查询时的今天」猜——
    // 否则跨年档期（如 12/28~1/5）在元旦之后查询时，会把 start 的年份跟着"今天"往后挪一年，
    // 变成还没到的未来日期，误判成 pre（其实正处于 main/supplement 期间）。
    // season_created_at 缺失（这版上线前就已经开着的老季度）时，第一次读到就落一次"当下"当锚点并写回去，
    // 之后固定不再变——如果每次都临时用"今天"兜底，锚点会随时间不断漂移，季度开得越久跨年判断就越容易再错。
    let createdAtRaw = parseInt(cachedGet("season_created_at") || "", 10);
    if (!createdAtRaw) {
        createdAtRaw = Date.now();
        cachedSet("season_created_at", String(createdAtRaw));
    }
    const anchorShifted = createdAtRaw + 8 * 3600 * 1000;
    const anchorUTC = beijingYMD(anchorShifted);
    const anchorYear = new Date(anchorUTC).getUTCFullYear();

    let year = anchorYear, bestDiff = Infinity;
    for (const y of [anchorYear - 1, anchorYear, anchorYear + 1]) {
        const s = mkDateUTC(startStr, y);
        if (s == null) continue;
        const diff = Math.abs(s - anchorUTC);
        if (diff < bestDiff) { bestDiff = diff; year = y; }
    }

    const start = mkDateUTC(startStr, year);
    const endYear  = (endStr  && endStr  < startStr) ? year + 1 : year;
    const suppYear = (suppStr && suppStr < startStr) ? year + 1 : year;
    const end  = mkDateUTC(endStr, endYear);
    const supp = mkDateUTC(suppStr, suppYear);
    if (start == null || end == null) return "main";

    if (todayUTC < start) return "pre";
    if (todayUTC <= end) return "main";
    if (supp != null && todayUTC <= supp) return "supplement";
    return "post";
}

// 剥离正文里"最外层"括号包裹的场外/OOC内容，不计入复盘存档（半角/全角括号均支持）。
// 只吞掉顶层括号闭合的那一段（含其嵌套内容）；没打闭合的括号原样保留，避免漏打括号误删正文。
function stripOocParens(text) {
    if (!text) return text;
    const OPEN_TO_CLOSE = { "（": "）", "(": ")" };
    const spans = [];
    const stack = []; // { closer, start }
    for (let i = 0; i < text.length; i++) {
        const ch = text[i];
        if (stack.length === 0) {
            if (OPEN_TO_CLOSE[ch]) stack.push({ closer: OPEN_TO_CLOSE[ch], start: i });
        } else {
            const top = stack[stack.length - 1];
            if (ch === top.closer) {
                stack.pop();
                if (stack.length === 0) spans.push([top.start, i]);
            } else if (OPEN_TO_CLOSE[ch]) {
                stack.push({ closer: OPEN_TO_CLOSE[ch], start: i });
            }
        }
    }
    if (spans.length === 0) return text.trim();
    let result = "", cursor = 0;
    for (const [s, e] of spans) { result += text.slice(cursor, s); cursor = e + 1; }
    result += text.slice(cursor);
    return result.trim();
}

// 通用NPC专用：首行不要求匹配某个固定角色名，任意名字+分隔符+正文都算数，
// 用来支持"一个账号轮流扮演不同龙套"的场景。握手写法与 extractRoleContent 对齐（换行/空格/冒号）。
function extractGenericRoleContent(message) {
    const lines = (message || "").split("\n");
    const first = lines[0].trim();
    if (!first) return null;
    const restLines = lines.slice(1).join("\n").trim();

    // 「名字」单独一行（允许末尾带空格/冒号，比如「路人甲：」换行再写正文），正文从下一行开始
    const nameOnly = first.replace(/[\s:：]+$/, "");
    if (restLines && nameOnly && nameOnly.length <= 20 && !/[\s:：]/.test(nameOnly)) {
        return { name: nameOnly, content: restLines };
    }
    // 「名字 正文」或「名字：正文」写在同一行
    const m = first.match(/^(\S{1,20}?)[ \t：:]+(\S.*)$/);
    if (m) {
        const content = (m[2].trim() + (restLines ? "\n" + restLines : "")).trim();
        if (content) return { name: m[1], content };
    }
    return null;
}

function handleReply(platform, groupId, roleName, message) {
    const settings = getMonitorSettings();
    if (!settings.enabled) {
        return false;
    }

    const timers = getGroupTimers();
    const timer = timers[groupId];
    if (!timer) {
        return false;
    }

    // 通用NPC：账号自身没有固定身份，靠首行写的名字决定这次算谁说的话，用来支持
    // 一个账号轮流扮演不同龙套。只要该群有计时器就直接按输入的名字存档，不管邀请名单/约会类型，
    // 也不跑下面参与者专属的轮流状态/字数统计/写帖进度（那些是给邀请对象本人用的）。
    const _genericNpcList = kvGet("a_generic_npc_list", []);
    if (_genericNpcList.includes(roleName)) {
        if (isArchiveEnabled() && getSeasonMode() !== "no_review") {
            const _npcExtracted = extractGenericRoleContent(message);
            if (_npcExtracted) {
                const _npcContent = stripOocParens(_npcExtracted.content);
                if (_npcContent) {
                    const _npcSS = getSessionStats()[groupId] || {};
                    const _npcStartTs = _npcSS._startTime || Date.now();
                    const _npcExpireInfo = kvGet("group_expire_info", {})[groupId] || {};
                    postToArchive("/api/rp", {
                        session_id: `${groupId}_${_npcStartTs}`,
                        group_id:   groupId,
                        role_name:  _npcExtracted.name,
                        is_npc:     true,
                        game_day:   _npcExpireInfo.day   || timer.day   || cachedGet("global_days") || "",
                        game_time:  _npcExpireInfo.time  || timer.time  || "",
                        place:      _npcExpireInfo.place || timer.place || "",
                        subtype:    timer.subtype || "",
                        timestamp:  Date.now(),
                        content:    _npcContent
                    });
                    console.log(`[存档] 通用NPC | ${_npcExtracted.name} | ${_npcContent.slice(0,30)}…`);
                }
            }
        }
        return false;
    }

    const roleStatus = timer.timerStatus[roleName];
    if (!roleStatus) {
        // 官约群里管理员经常发旁白，但管理员不在邀请对象内、进不了 timerStatus，正常会被上面这条拦掉。
        // 官约单独放行：只要开着复盘就整条原样存档，不要求「角色名+分隔符+正文」的握手格式（旁白不是台词），
        // 也不跑下面参与者专属的轮流状态/字数统计/写帖进度（那些是给邀请对象本人用的，旁白不该污染）。
        if (timer.subtype === "官约" && isArchiveEnabled() && getSeasonMode() !== "no_review") {
            const _narratorContent = stripOocParens((message || "").trim());
            if (_narratorContent) {
                const _narratorSS = getSessionStats()[groupId] || {};
                const _narratorStartTs = _narratorSS._startTime || Date.now();
                const _narratorExpireInfo = kvGet("group_expire_info", {})[groupId] || {};
                postToArchive("/api/rp", {
                    session_id: `${groupId}_${_narratorStartTs}`,
                    group_id:   groupId,
                    role_name:  roleName,
                    is_npc:     kvGet("a_npc_list", []).includes(roleName),
                    game_day:   _narratorExpireInfo.day   || timer.day   || cachedGet("global_days") || "",
                    game_time:  _narratorExpireInfo.time  || timer.time  || "",
                    place:      _narratorExpireInfo.place || timer.place || "",
                    subtype:    timer.subtype || "",
                    timestamp:  Date.now(),
                    content:    _narratorContent
                });
                console.log(`[存档] 官约旁白 | ${roleName} | ${_narratorContent.slice(0,30)}…`);
            }
        } else {
            console.warn(`[监听系统] 处理失败: 角色 [${roleName}] 不在参与者名单中`);
        }
        return false;
    }

    // RP存档（不复盘模式跳过 entry 记录）
    if (isArchiveEnabled() && getSeasonMode() !== "no_review") {
        const _archiveSS = getSessionStats()[groupId] || {};
        const _startTs = _archiveSS._startTime || Date.now();
        const _expireInfo = kvGet("group_expire_info", {})[groupId] || {};
        const _gameDay = _expireInfo.day || timer.day || cachedGet("global_days") || "";
        const _npcList = kvGet("a_npc_list", []);
        const _logTypes = ["私密", "电话", "官约", "心愿"];
        const _archivePayload = {
            session_id: `${groupId}_${_startTs}`,
            group_id:   groupId,
            role_name:  roleName,
            is_npc:     _npcList.includes(roleName),
            game_day:   _gameDay,
            game_time:  _expireInfo.time  || timer.time  || "",
            place:      _expireInfo.place || timer.place || "",
            subtype:    timer.subtype || "",
            timestamp:  Date.now()
        };

        let _archivedContent = null;
        const _arcExtracted = extractRoleContent(message, roleName);
        const _arcStripped = _arcExtracted ? stripOocParens(_arcExtracted) : null;
        if (_arcStripped) {
            postToArchive("/api/rp", { ..._archivePayload, content: _arcStripped });
            _archivedContent = _arcStripped;
            if (_logTypes.includes(timer.subtype))
                console.log(`[存档] ${timer.subtype} | ${_gameDay} | ${roleName}${_npcList.includes(roleName) ? "(NPC)" : ""} | ${_arcStripped.slice(0,30)}…`);
        }

        // 字数统计：凡存档成功的回复（非NPC）都累计，不依赖 timing 状态
        // 10分钟内同一人同一群再发且 Jaccard 相似度 ≥ 0.6，视为撤回重发：替换字数而非新增
        if (_archivedContent && !_npcList.includes(roleName)) {
            const _wc = countWords(_archivedContent);
            const _archiveUid = getUidByRoleName(platform, roleName);
            if (_archiveUid) {
                const _ssArc = getSessionStats();
                if (!_ssArc[groupId]) _ssArc[groupId] = {};
                if (!_ssArc[groupId]._startTime) _ssArc[groupId]._startTime = _startTs;
                if (!_ssArc[groupId][_archiveUid]) _ssArc[groupId][_archiveUid] = { replies: 0, words: 0 };

                // 撤回重发检测
                const _cacheKey = `reply_cache__${groupId}__${_archiveUid}`;
                const _cached = (() => { try { return kvGet(_cacheKey, null); } catch(e) { return null; } })();
                const _now = Date.now();
                let _isRedo = false;
                if (_cached && (_now - _cached.ts) <= 600000) {
                    // Jaccard 相似度（字符 bigram）
                    const bigrams = s => {
                        const set = new Set();
                        for (let i = 0; i < s.length - 1; i++) set.add(s.slice(i, i + 2));
                        return set;
                    };
                    const a = bigrams(_cached.content), b = bigrams(_archivedContent);
                    const inter = [...a].filter(x => b.has(x)).length;
                    const union = new Set([...a, ...b]).size;
                    const jaccard = union > 0 ? inter / union : 0;
                    if (jaccard >= 0.6) {
                        // 替换：减去旧字数，不新增段数
                        _ssArc[groupId][_archiveUid].words = Math.max(0,
                            _ssArc[groupId][_archiveUid].words - _cached.words) + _wc;
                        _isRedo = true;
                        console.log(`[字数] ${roleName} | 群${groupId} | 撤回重发(Jaccard=${jaccard.toFixed(2)}) 替换 ${_cached.words}→${_wc}字`);
                    }
                }
                if (!_isRedo) {
                    _ssArc[groupId][_archiveUid].replies += 1;
                    _ssArc[groupId][_archiveUid].words += _wc;
                    console.log(`[字数] ${roleName} | 群${groupId} | +${_wc}字 +1段 | 累计${_ssArc[groupId][_archiveUid].words}字/${_ssArc[groupId][_archiveUid].replies}段`);
                }

                saveSessionStats(_ssArc);
                // 更新缓存（无论替换还是新增，都以本次内容作为下次比对基准）
                kvSet(_cacheKey, { content: _archivedContent, words: _wc, ts: _now });
            }
        }
    }

    // 1. 字数（与存档段同口径，见 extractRoleContent 支持的三种格式；同样剥离最外层括号的场外内容）
    // 先做格式校验，再判断计时状态：避免不成格式的日常闲聊也触发"已回复"提示
    const _wContent = stripOocParens(extractRoleContent(message, roleName) || "");
    if (!_wContent) return false;

    // 2. 检查计时状态
    // 独立模式：任何人随时可发，不拦截
    // 轮流模式：waiting（对方回合）和 timing（自己回合）都允许；replied 才拦截（已回等对方）
    if (timer.timerMode === "turn_taking") {
        if (roleStatus.status === "replied") return "already_replied";
    }

    const wordCount = countWords(_wContent);

    // --- 开始更新数据 ---

    // 3. 记录回复状态
    roleStatus.status = "replied";
    roleStatus.repliedTime = Date.now();
    roleStatus.wordCount = wordCount;

    // 4. 更新用户统计
    // 耗时 = 群内其他任意参与者最后一条发言时间 → 本人发言时间
    if (!timer.lastMsgAt) timer.lastMsgAt = {};
    const _otherTimes = (timer.participants || [])
        .filter(p => p !== roleName)
        .map(p => timer.lastMsgAt[p])
        .filter(t => t != null);
    const _replyStartTime = _otherTimes.length > 0 ? Math.max(..._otherTimes) : null;
    const roleUid = getUidByRoleName(platform, roleName);
    const _sessSS = getSessionStats()[groupId] || {};
    const _sessionId = `${groupId}_${_sessSS._startTime || timer.startTime || Date.now()}`;
    // 过了档期结束日（补戏期/忘记结季度后的超期期间）只留场次记录，不计入弧长——
    // 与 rp_archive 那边「补戏期只保存场次stats，不更新玩家弧长」的口径保持一致
    if (getScheduleZone() === "main") {
        updateUserStats(platform, roleUid || roleName, wordCount, _replyStartTime, roleStatus.repliedTime, _sessionId);
    }

    // 5. 【新增逻辑】记录写帖进度 (替代原来的 .写了 指令)
    // 获取该角色的 UID（新结构：直接使用 getUidByRoleName 结果）
    const uid = roleUid;

    if (uid) {
        const progress = kvGet("group_write_progress", {});
        // 这里的 groupId 是当前互动的群号（如 001_1）
        if (!progress[groupId]) progress[groupId] = {};
        progress[groupId][uid] = (progress[groupId][uid] || 0) + 1;
        kvSet("group_write_progress", progress);
        console.log(`[监听系统] 记录进度: ${roleName}(${uid}) 在群 ${groupId} 回复数 +1`);
    }

    // 6. session 统计已在存档段累计，此处仅同步写入计时器（用于展示）
    const sessionUid = roleUid;

    // 同步写入计时器，方便查看计时器时直接读取
    if (!roleStatus.sessionReplies) roleStatus.sessionReplies = 0;
    if (!roleStatus.sessionWords) roleStatus.sessionWords = 0;
    if (!roleStatus.sessionReplyTimeMs) roleStatus.sessionReplyTimeMs = 0;
    if (!roleStatus.sessionTimedReplies) roleStatus.sessionTimedReplies = 0;
    roleStatus.sessionReplies += 1;
    roleStatus.sessionWords += wordCount;
    // sessionReplies 含开场白等无法测耗时的回复，sessionTimedReplies 只计有有效耗时的那些（同 updateUserStats 的口径）
    if (_replyStartTime != null) {
        roleStatus.sessionReplyTimeMs += (roleStatus.repliedTime - _replyStartTime);
        roleStatus.sessionTimedReplies += 1;
    }

    // 实时推送本场 stats 到存档服务器（自动更新统计页面 + 玩家数据库）
    // NPC 回复不触发 stats 推送，避免污染数据分析
    const _npcListStats = kvGet("a_npc_list", []);
    if (isArchiveEnabled() && sessionUid && !_npcListStats.includes(roleName)) {
        const _ss2 = getSessionStats()[groupId] || {};
        const _startTs2 = _ss2._startTime || Date.now();
        const liveStats = {};
        (timer.participants || []).forEach(rn => {
            const ruid = getUidByRoleName(platform, rn);
            if (ruid && _ss2[ruid]) {
                liveStats[rn] = { replies: _ss2[ruid].replies || 0, words: _ss2[ruid].words || 0 };
            }
        });
        const livePlayers = (timer.participants || []).map(rn => {
            const ruid = getUidByRoleName(platform, rn);
            return ruid ? { qq: ruid, role_name: rn, is_npc: _npcListStats.includes(rn) } : null;
        }).filter(Boolean);
        const _expireInfo2 = kvGet("group_expire_info", {})[groupId] || {};
        postToArchive("/api/session_stats", {
            session_id: `${groupId}_${_startTs2}`,
            group_id:   groupId,
            game_day:   _expireInfo2.day  || timer.day   || cachedGet("global_days") || "",
            game_time:  _expireInfo2.time || timer.time  || "",
            place:      _expireInfo2.place|| timer.place || "",
            subtype:    timer.subtype || "",
            stats:      liveStats,
            players:    livePlayers,
        });
    }

    // 7. 处理计时器流转 (轮流模式/独立模式)
    const _flowNow = Date.now();
    if (timer.timerMode === "turn_taking") {
        // 轮流模式：发言方 → replied，对方 → timing（无论谁抢先开头都成立）
        const otherParticipant = timer.participants.find(p => p !== roleName);
        if (otherParticipant) {
            const otherStatus = timer.timerStatus[otherParticipant];
            if (otherStatus) {
                otherStatus.status = "timing";
                otherStatus.startTime = _flowNow;
                otherStatus.repliedTime = null;
                otherStatus.wordCount = 0;
                otherStatus.remindedTimes = 0;
            }
        }
    } else {
        // 独立模式：任何人发言后，其余所有人变 timing（开始计时等回复）
        timer.participants.forEach(p => {
            if (p === roleName) return;
            const ps = timer.timerStatus[p];
            if (ps) {
                ps.status = "timing";
                ps.startTime = _flowNow;
                ps.repliedTime = null;
                ps.wordCount = 0;
                ps.remindedTimes = 0;
            }
        });
    }

    // 8. 记录本次发言时间，供下一条其他人计算耗时用
    timer.lastMsgAt[roleName] = roleStatus.repliedTime;

    saveGroupTimers(timers);
    return true; // 返回 true 表示处理成功，外部逻辑会执行 handleReply 转发
}

/**
 * 计算字数
 */
function countWords(text) {
    if (!text) return 0;
    
    // 移除CQ码
    const cleanText = text.replace(/\[CQ:[^\]]*\]/g, '');
    
    // 统计中文字符
    const chineseChars = (cleanText.match(/[\u4e00-\u9fa5]/g) || []).length;
    
    // 统计英文单词（按空格分割）
    const englishText = cleanText.replace(/[\u4e00-\u9fa5]/g, '');
    const englishWords = englishText.trim().split(/\s+/).filter(word => word.length > 0).length;
    
    return chineseChars + englishWords;
}


/**
 * 更新用户统计
 */
/**
 * 更新用户统计（增强版：包含平均字数与平均时长）
 */
// uid 参数为玩家 uid（非 roleName），key 改为 ${platform}:${uid}
// sessionId 可选：传入时用于去重统计"参与过多少场"（「我的弧长」等汇总指令用）
function updateUserStats(platform, uid, wordCount, startTime, repliedTime, sessionId) {
    const stats = getUserStats();
    const key = `${platform}:${uid}`;

    // 1. 初始化统计结构
    if (!stats[key]) {
        stats[key] = {
            totalWords: 0,        // 总字数
            totalReplies: 0,      // 总有效回复次数
            totalReplyTimeMs: 0,  // 总回复耗时（毫秒，仅含 startTime 有效的回复）
            timedReplies: 0,      // 参与耗时平均计算的回复次数
            avgWords: 0,          // 平均字数
            avgReplyTimeMin: 0,   // 平均耗时（分钟）
            sessionIds: [],       // 参与过的场次id（去重），用于统计"总共X场"
            subtypeStats: {}      // 分类型统计
        };
    }

    const userStat = stats[key];
    if (!userStat.sessionIds) userStat.sessionIds = []; // 兼容老数据（该字段新增前已存在的用户统计）
    if (sessionId && !userStat.sessionIds.includes(sessionId)) userStat.sessionIds.push(sessionId);

    // startTime 为 null 时（轮流模式接收方尚未被计时就发言），跳过耗时统计避免污染平均值；
    // 过了档期主区间（补戏期/超期，季度还没手动结束）也跳过，字数/场次仍正常累计，
    // 只是不再计入弧长——跟 rp_archive /api/rp 那边「zone === 'main' 才计入弧长」的口径保持一致
    const replyTimeMs = (getScheduleZone() === "main" && startTime != null && startTime > 0) ? repliedTime - startTime : null;

    // 2. 更新基础累加数据
    userStat.totalReplies += 1;
    userStat.totalWords += wordCount;
    if (replyTimeMs != null && replyTimeMs >= 0) {
        userStat.totalReplyTimeMs += replyTimeMs;
        userStat.timedReplies = (userStat.timedReplies || 0) + 1;
    }

    // 3. 计算全局平均值
    userStat.avgWords = parseFloat((userStat.totalWords / userStat.totalReplies).toFixed(2));
    const _timedReplies = userStat.timedReplies || 0;
    userStat.avgReplyTimeMin = _timedReplies > 0
        ? parseFloat((userStat.totalReplyTimeMs / _timedReplies / 60000).toFixed(1))
        : 0;

    // 4. 更新细分类型统计（uid 为 key）
    if (!userStat.subtypeStats[platform]) userStat.subtypeStats[platform] = {};
    if (!userStat.subtypeStats[platform][uid]) {
        userStat.subtypeStats[platform][uid] = {
            replies: 0,
            totalWords: 0,
            totalTime: 0,
            fastestReply: null,
            slowestReply: null
        };
    }

    const sub = userStat.subtypeStats[platform][uid];
    sub.replies += 1;
    sub.totalWords += wordCount;
    if (replyTimeMs != null && replyTimeMs >= 0) {
        sub.totalTime += replyTimeMs;
        // 记录最快/最慢纪录（分钟），仅在耗时有效时更新
        const currentReplyMin = Math.round(replyTimeMs / 60000);
        if (sub.fastestReply == null || currentReplyMin < sub.fastestReply) sub.fastestReply = currentReplyMin;
        if (sub.slowestReply == null || currentReplyMin > sub.slowestReply) sub.slowestReply = currentReplyMin;
    }

    saveUserStats(stats);

    const currentReplyMin = replyTimeMs != null ? Math.round(replyTimeMs / 60000) : null;
    console.log(`[统计更新] uid=${uid}: 本次回复${wordCount}字, 耗时${currentReplyMin ?? "N/A"}分 | 累计平均: ${userStat.avgWords}字, ${userStat.avgReplyTimeMin}分`);
}


/**
 * 结束私约时清理计时器
 */
function cleanupGroupTimer(groupId) {
    const timers = getGroupTimers();
    if (timers[groupId]) {
        delete timers[groupId];
        saveGroupTimers(timers);
        console.log(`[监听系统] 清理群组 ${groupId} 的计时器`);
    }
}

// 结束/强结私约时记录：该群参与者若还没退群，供「我的待回」提醒
function recordPendingLeaveCheck(gid, subtype, participants) {
    if (!participants || !participants.length) return;
    const store = kvGet("pending_leave_check", {});
    for (const name of participants) {
        if (!name) continue;
        if (!store[name]) store[name] = [];
        if (!store[name].some(e => e.gid === gid)) {
            store[name].push({ gid, subtype: subtype || "", endedAt: Date.now() });
        }
    }
    kvSet("pending_leave_check", store);
}

function withdrawMsg(ctx, msg, wdId) {
    if (!checkCondition(ctx)) return;
    return ws(
        { action: "delete_msg", params: { message_id: parseInt(wdId) } },
        ctx, msg,
        "✅ 已撤回。",
        "❌ 撤回失败（消息不在 LLOneBot 缓存中）"
    );
}

// 「引用+撤回」联动复盘：没有存「QQ消息ID → 复盘条目ID」的映射，只能反查被撤回消息的原文，
// 按当时的握手格式解析出记录名/正文（三条分支要跟 handleReply 里的存档逻辑一一对应，否则有些消息类型
// 撤回了也匹配不到，复盘里会留下"幽灵条目"），再去存档服务器按内容匹配删除。
// 内容相同的情况下靠 orig_timestamp（原消息发送时间）辅助判断删的是哪一条，避免同一人在同一场次
// 发过两条一模一样内容时删错。
function syncWithdrawToArchive(wdId, groupId, roleName) {
    if (!isArchiveEnabled() || getSeasonMode() === "no_review") return;
    WSM.request(
        { action: "get_msg", params: { message_id: parseInt(wdId) } },
        (response) => {
            if (response.status !== 'ok' && response.retcode !== 0) return;
            const data = response.data;
            if (!data) return;
            let rawContent = data.message;
            if (Array.isArray(rawContent)) {
                rawContent = rawContent.filter(seg => seg.type === "text").map(seg => (seg.data && seg.data.text) || "").join("");
            }
            if (typeof rawContent !== "string" || !rawContent) return;

            const timers = getGroupTimers();
            const timer = timers[groupId];

            let matchName = null, matchContent = null;
            if (kvGet("a_generic_npc_list", []).includes(roleName)) {
                const g = extractGenericRoleContent(rawContent);
                if (g) { matchName = g.name; matchContent = stripOocParens(g.content); }
            } else if (timer && !timer.timerStatus[roleName] && timer.subtype === "官约") {
                // 官约旁白：不要求「角色名+分隔符」握手格式，整条原样存档——跟 handleReply 里的旁白分支保持一致
                matchName = roleName;
                matchContent = stripOocParens(rawContent.trim());
            } else {
                const extracted = extractRoleContent(rawContent, roleName);
                if (extracted) { matchName = roleName; matchContent = stripOocParens(extracted); }
            }
            if (!matchName || !matchContent) return;

            const ss = getSessionStats()[groupId] || {};
            const sessionId = `${groupId}_${ss._startTime || Date.now()}`;
            const origTimestamp = (typeof data.time === "number" && data.time > 0) ? data.time * 1000 : undefined;
            postToArchive("/api/rp/delete_by_content", {
                session_id: sessionId,
                role_name:  matchName,
                content:    matchContent,
                orig_timestamp: origTimestamp
            });
        },
        () => {}
    );
}

// ========================
// 📮 发错撤回：短信/礼物/拉线发错人时，引用自己那条指令（或机器人回执）发「撤回」，
// 把已经投递到对方个人群里的消息一起删掉（机器人需是对方个人群的管理员）。
// ========================
// 投递时记一笔 sent_recall_tracking；撤回时按记录去对方群删消息：
//   - 投递时拿得到消息 ID 的（拉线走 WS）直接 delete_msg；
//   - 走 seal.replyToSender 的（短信/礼物）拿不到 ID：投递后 5 秒 / 60 秒各去对方群聊天记录里
//     按「机器人发的 + 时间对得上 + 内容片段对得上」认领一次 ID（刚发出一定在最近几条里），
//     之后对方群再怎么刷屏，撤回都按 ID 直接删；
//   - 认领没成功或按 ID 删失败（OneBot 缓存过期等），撤回时再往前逐页翻聊天记录找，翻到早于发送时间为止。
// 这样短信/礼物的投递路径完全不用改（改成 WS 发送会碰到图片 CQ 码等兼容问题）。
//
// Record: { id, type, platform, senderUid, senderGid, toName, cmdMsgId, cmdAt, receiptText, sentAt,
//           deliveries: [{ gid, msgId?, snippet, at }], stat?: { from, to, type, skipReceived },
//           archive?: { type, from_role, to_role, timestamp }, undo?: {...类型私有}, recalled }
const RECALL_WINDOW_MS = 2 * 60 * 1000;          // 玩家自己能撤回的时限（跟 QQ 撤回一样 2 分钟）
const RECALL_KEEP_MS   = 24 * 3600 * 1000;       // 记录保留时长：超过 2 分钟后管理员仍可代撤
// 回执末尾的撤回提示；社交插件（礼物/拉线）经 api.getRecallHint() 取同一句
const RECALL_RECEIPT_HINT = "↩️ 发错人了？2 分钟内引用这条发「撤回」";
const RECALL_FORMAT_HINT  = "↩️ 发错人了？2 分钟内引用你发的那条（或机器人的回执）发「撤回」，详见「格式撤回」";
const RECALL_TRACK_MAX = 300;
const RECALL_TYPE_LABEL = { sms: "短信", gift: "礼物", rel: "关系细节" };
const RECALL_CAPTURE_DELAYS_MS = [5000, 60000];   // 投递后认领消息 ID 的时机；第二次兜住 SealDice 发送排队较久的情况
const RECALL_HISTORY_PAGE = 50;
const RECALL_HISTORY_MAX_PAGES = 10;              // 撤回时最多往前翻约 500 条
// 各类型的数据回滚（退次数、删关系线细节等）由数据所在的插件注册；走 globalThis 避免依赖插件加载顺序
globalThis.__changriRecallHandlers = globalThis.__changriRecallHandlers || {};

function getRecallTracking() { return kvGet("sent_recall_tracking", []); }
function saveRecallTracking(list) { kvSet("sent_recall_tracking", list); }

function trackSentItem(rec) {
    const now = Date.now();
    const list = getRecallTracking().filter(r => now - r.sentAt < RECALL_KEEP_MS);
    rec.id = `${now.toString(36)}${Math.random().toString(36).slice(2, 5)}`;
    rec.recalled = false;
    // 指令原文（去 CQ 码/空白），rawId 取不到时靠它确认玩家引用的确实是这条指令，而不是同一时段发的别的消息
    rec.cmdText = normalizeForMatch(rec.cmdText);
    list.push(rec);
    saveRecallTracking(list.slice(-RECALL_TRACK_MAX));
    scheduleDeliveryIdCapture(rec.id, 0);
    return rec.id;
}

// 投递后趁消息还在最近几条里，把它的消息 ID 认领下来
function scheduleDeliveryIdCapture(recId, attempt) {
    if (attempt >= RECALL_CAPTURE_DELAYS_MS.length) return;
    setTimeout(() => {
        const rec = getRecallTracking().find(r => r.id === recId);
        // 已撤回的不再动：撤回流程会改写 deliveries，按下标回填会写错位置
        if (!rec || rec.recalled) return;
        const missing = (rec.deliveries || []).map((d, idx) => ({ d, idx })).filter(x => x.d.msgId == null);
        if (!missing.length) return;
        const botUid = getBotUid(rec.platform);
        let pending = missing.length, stillMissing = 0;
        missing.forEach(({ d, idx }) => findDeliveryInHistory(d, botUid, 1, (m) => {
            if (m) updateTrackedDelivery(recId, idx, m.message_id);
            else stillMissing++;
            if (--pending === 0 && stillMissing) scheduleDeliveryIdCapture(recId, attempt + 1);
        }));
    }, RECALL_CAPTURE_DELAYS_MS[attempt]);
}

// 拉线的 WS 回包晚于记录写入，拿到消息 ID 后回填
function updateTrackedDelivery(recId, idx, msgId) {
    const list = getRecallTracking();
    const rec = list.find(r => r.id === recId);
    if (!rec || rec.recalled || !rec.deliveries[idx]) return;
    rec.deliveries[idx].msgId = msgId;
    saveRecallTracking(list);
}

// 发起者的 QQ 消息 ID（SealDice Message.rawId），供「引用自己那条指令」时直接对上记录
function getMsgRawId(msg) {
    try { return msg.rawId != null && msg.rawId !== "" ? String(msg.rawId) : ""; } catch (e) { return ""; }
}

// 比对用：去掉 CQ 码和所有空白
function normalizeForMatch(s) {
    return String(s || "").replace(/\[CQ:[^\]]*\]/g, "")
        .replace(/&#91;/g, "[").replace(/&#93;/g, "]").replace(/&#44;/g, ",").replace(/&amp;/g, "&")
        .replace(/\s+/g, "");
}

function onebotMsgText(data) {
    if (!data) return "";
    if (typeof data.raw_message === "string" && data.raw_message) return data.raw_message;
    const m = data.message;
    if (typeof m === "string") return m;
    if (Array.isArray(m)) return m.filter(seg => seg.type === "text").map(seg => (seg.data && seg.data.text) || "").join("");
    return "";
}

function getBotUid(platform) {
    const ep = getSafeEndPoint(platform);
    return ep ? String(ep.userId || "").replace(/^[A-Za-z]+:/, "") : "";
}

function revertInteractionStat(platform, fromRole, toRole, type, skipReceived) {
    if (!fromRole || !toRole || fromRole === toRole) return;
    const counts = getInteractionCounts();
    const dec = (key, field, name) => {
        const m = counts[key]?.[field];
        if (!m || !m[name]) return;
        m[name] -= 1;
        if (m[name] <= 0) delete m[name];
    };
    dec(`${platform}:${fromRole}`, `${type}_sent`, toRole);
    if (!skipReceived) dec(`${platform}:${toRole}`, `${type}_received`, fromRole);
    saveInteractionCounts(counts);
}

// 从一批聊天记录里挑出这条投递：机器人发的、时间在窗口内，优先内容片段对得上的
// 内容对不上（如纯图片内容）时，只在前后 30 秒内恰好一条机器人消息时才认，避免删错
function pickDeliveryMsg(msgs, d, botUid, allowNearFallback) {
    const snippet = normalizeForMatch(d.snippet).slice(0, 15);
    // SealDice 发送可能排队，实际发出时间会比记录时间晚一些；往前留 10 秒容差
    const inWindow = msgs.filter(m => {
        const sender = String((m.sender && m.sender.user_id) || m.user_id || "");
        const t = (m.time || 0) * 1000;
        return sender === botUid && t >= d.at - 10000 && t <= d.at + 5 * 60000;
    });
    const byContent = snippet ? inWindow.filter(m => normalizeForMatch(onebotMsgText(m)).includes(snippet)) : [];
    const near = allowNearFallback ? inWindow.filter(m => Math.abs((m.time || 0) * 1000 - d.at) <= 30000) : [];
    const pool = byContent.length ? byContent : (near.length === 1 ? near : []);
    if (!pool.length) return null;
    return pool.reduce((a, b) => Math.abs(a.time * 1000 - d.at) <= Math.abs(b.time * 1000 - d.at) ? a : b);
}

// 从最新往前逐页翻对方群聊天记录，直到找到这条投递、翻过它的发送时间、或翻满 maxPages 页。
// 各家 OneBot 的翻页参数略有出入（message_seq / message_id），拿不到新消息就停，不会死循环
function findDeliveryInHistory(d, botUid, maxPages, cb) {
    const gidNum = parseInt(String(d.gid).replace(/\D/g, ""), 10);
    if (!gidNum || !botUid) return cb(null);
    const seen = new Map();
    let pages = 0;
    const decide = () => cb(pickDeliveryMsg([...seen.values()], d, botUid, true));
    const fetchPage = (seq) => {
        const params = { group_id: gidNum, count: RECALL_HISTORY_PAGE };
        if (seq != null) params.message_seq = seq;
        WSM.request({ action: "get_group_msg_history", params }, (resp) => {
            const data = resp && resp.data;
            const msgs = (data && (data.messages || data)) || [];
            if (!Array.isArray(msgs)) return decide();
            const fresh = msgs.filter(m => m && m.message_id != null && !seen.has(m.message_id));
            if (!fresh.length) return decide();
            fresh.forEach(m => seen.set(m.message_id, m));
            pages++;
            // 内容对得上就不用再往前翻了
            const hit = pickDeliveryMsg(fresh, d, botUid, false);
            if (hit) return cb(hit);
            const oldest = fresh.reduce((a, b) => ((a.time || 0) <= (b.time || 0) ? a : b));
            if ((oldest.time || 0) * 1000 < d.at - 10000 || pages >= maxPages) return decide();
            fetchPage(oldest.message_seq != null ? oldest.message_seq : oldest.message_id);
        }, decide, 8000);
    };
    fetchPage(null);
}

// 在对方群里删掉一条投递：有 ID 先按 ID 删；没有 ID 或按 ID 删失败（缓存过期等），再翻聊天记录找回来删
function deleteTrackedDelivery(platform, d, botUid, done) {
    const del = (id, onFail) => WSM.request(
        { action: "delete_msg", params: { message_id: parseInt(id, 10) } },
        (resp) => (resp.status === "ok" || resp.retcode === 0) ? done(true) : onFail(),
        onFail, 8000);
    const searchAndDelete = () => findDeliveryInHistory(d, botUid, RECALL_HISTORY_MAX_PAGES, (m) => {
        if (!m) return done(false);
        // 即使找回的 ID 跟刚才删失败的一样也再删一次：拉聊天记录本身会让 OneBot 重新缓存这条消息
        del(m.message_id, () => done(false));
    });
    if (d.msgId != null) return del(d.msgId, searchAndDelete);
    searchAndDelete();
}

// 第一次撤回：回滚数据 + 删对方群的投递；删失败的投递留在记录里，玩家可以再引用同一条重试（重试只删消息，不重复回滚）
function performRecall(ctx, msg, rec, quotedId) {
    const isRetry = rec.recalled;
    let undoNote = "";
    if (!isRetry) {
        // 先标记，防止连点两次撤回重复退次数
        const list = getRecallTracking();
        const stored = list.find(r => r.id === rec.id);
        if (stored) stored.recalled = true;
        saveRecallTracking(list);

        const handler = globalThis.__changriRecallHandlers[rec.type];
        try { if (handler) undoNote = handler(rec) || ""; } catch (e) { console.error(`[发错撤回] ${rec.type} 数据回滚失败:`, e); }
        if (rec.stat) revertInteractionStat(rec.platform, rec.stat.from, rec.stat.to, rec.stat.type, rec.stat.skipReceived);
        if (rec.archive && isArchiveEnabled()) postToArchive("/api/event/delete_by_match", rec.archive);
    }

    const label = RECALL_TYPE_LABEL[rec.type] || "消息";
    const botUid = getBotUid(rec.platform);
    const deliveries = rec.deliveries || [];
    const failedList = [];
    let pending = deliveries.length;
    const finish = () => {
        const list = getRecallTracking();
        const stored = list.find(r => r.id === rec.id);
        if (stored) { stored.deliveries = failedList; saveRecallTracking(list); }
        let head;
        if (failedList.length === 0) {
            // 全部删干净才顺手删掉被引用的那条（跟原来「引用+撤回」一致）；失败时留着，方便玩家再引用它重试
            WSM.push({ action: "delete_msg", params: { message_id: parseInt(quotedId, 10) } });
            head = `✅ 已撤回发给「${rec.toName}」的${label}。`;
        } else {
            head = `⚠️ ${isRetry ? "重试后" : `已撤回发给「${rec.toName}」的${label}记录，但`}对方群里还有 ${failedList.length} 条消息没能删除（可能对方群刷屏太多翻不到了，或机器人不是那个群的管理员），请尽快联系管理员手动撤回。\n（如果是机器人刚才连接不稳，也可以稍后再引用这条发「撤回」重试）`;
        }
        seal.replyToSender(ctx, msg, head + (undoNote ? `\n${undoNote}` : ""));
    };
    if (pending === 0) return finish();
    deliveries.forEach(d => deleteTrackedDelivery(rec.platform, d, botUid, (ok) => {
        if (!ok) failedList.push(d);
        if (--pending === 0) finish();
    }));
}

// 「引用 + 撤回」入口：对上发错撤回记录就走撤回流程，否则退回原来的「删掉被引用的那条」（戏群里撤 RP 消息）。
// 跟原来的 RP 撤回共用入口，下面几道闸都是为了不误伤它：
//   - 只有引用后正文恰好是「撤回」才考虑发错撤回（原逻辑是「包含撤回」，回一句"别撤回啊"不能把短信撤了）；
//   - 本群 24 小时内没有任何短信/礼物/拉线记录（戏群的常态）就直接走原逻辑，不多发一次 OneBot 请求；
//   - 读原消息兜底匹配时，玩家自己发的消息必须跟记录里的指令原文一致才算，不能只看时间接近。
function handleQuotedWithdraw(ctx, msg, wdId, raw) {
    const platform = msg.platform;
    const gid = msg.groupId.replace(`${platform}-Group:`, "");
    const myUid = getPrimaryUid(platform, msg.sender.userId.replace(`${platform}:`, ""));
    const isAdmin = isUserAdmin(ctx, msg);
    const now = Date.now();
    if (normalizeForMatch(raw) !== "撤回") return withdrawMsg(ctx, msg, wdId);
    const candidates = getRecallTracking().filter(r =>
        r.platform === platform && r.senderGid === gid && now - r.sentAt < RECALL_KEEP_MS);
    if (!candidates.length) return withdrawMsg(ctx, msg, wdId);

    const tryRecall = (rec) => {
        if (rec.senderUid !== myUid && !isAdmin) {
            seal.replyToSender(ctx, msg, "❌ 只能撤回自己发出的内容。");
            return;
        }
        if (rec.recalled && !(rec.deliveries || []).length) {
            seal.replyToSender(ctx, msg, "这条已经撤回过了。");
            return;
        }
        // 玩家只能 2 分钟内自己撤；管理员 24 小时内都能代撤（也就是提示里说的「联系管理员」）
        // 失败后重试不受时限限制：已经撤回过、只是对方群那条没删掉，不算新的撤回
        if (!rec.recalled && !isAdmin && now - rec.sentAt > RECALL_WINDOW_MS) {
            seal.replyToSender(ctx, msg, "⏰ 已经超过 2 分钟，撤不回了。确实需要的话请联系管理员帮忙撤回。");
            return;
        }
        performRecall(ctx, msg, rec, wdId);
    };

    // 快速路径：引用的是自己发的那条指令，消息 ID 直接对得上
    const byId = candidates.find(r => r.cmdMsgId && r.cmdMsgId === String(wdId));
    if (byId) return tryRecall(byId);

    // 否则读出被引用的消息：可能是机器人的回执，或 rawId 没取到时的指令原文
    WSM.request(
        { action: "get_msg", params: { message_id: parseInt(wdId, 10) } },
        (resp) => {
            const data = (resp.status === "ok" || resp.retcode === 0) ? resp.data : null;
            if (!data) return withdrawMsg(ctx, msg, wdId);
            const sender = String((data.sender && data.sender.user_id) || data.user_id || "");
            const t = (data.time || 0) * 1000;
            const text = normalizeForMatch(onebotMsgText(data));
            let rec = null;
            if (sender === getBotUid(platform)) {
                rec = candidates.filter(r => r.receiptText && normalizeForMatch(r.receiptText) === text)
                    .sort((a, b) => Math.abs(a.sentAt - t) - Math.abs(b.sentAt - t))[0] || null;
            } else if (text) {
                // 内容必须跟指令原文一致：同一时段在同一个群里发的 RP 消息不会被误认成短信指令
                rec = candidates.filter(r => r.cmdText && r.cmdText === text)
                    .sort((a, b) => Math.abs(a.cmdAt - t) - Math.abs(b.cmdAt - t))[0] || null;
            }
            if (rec) return tryRecall(rec);

            // 没有记录：看起来是短信/礼物/拉线（超过 24 小时或本功能上线前发的），只能删掉本群这条，要明确告诉对方那边没撤
            // 只认机器人回执的固定开头，或整条就是指令格式的玩家消息；RP 正文里顺带提到"短信"不算
            const plain = (onebotMsgText(data) || "").replace(/\[CQ:[^\]]*\]/g, "").trim();
            const looksLikeSend = sender === getBotUid(platform)
                ? /^(🕊️信件已由鸽子衔往|🎁已成功将|✅细节已同步至|✨关系线已建立)/.test(text)
                : /^[。.]?[^\s:：。.]{0,10}(短信|送礼|拉线)\s*\S+\s+\S/.test(plain);
            withdrawMsg(ctx, msg, wdId);
            if (looksLikeSend) {
                seal.replyToSender(ctx, msg, "⚠️ 找不到这条的投递记录（发出太久了），只删掉了本群这条，对方那边请联系管理员手动撤回。");
            }
        },
        () => withdrawMsg(ctx, msg, wdId),
        6000
    );
}

// 短信的数据回滚：退今日次数、清冷却（发错人后能马上重发给对的人）
globalThis.__changriRecallHandlers.sms = (rec) => {
    const u = rec.undo || {};
    const counts = kvGet("global_chaos_letter_counts", {});
    const userRec = counts[u.userKey];
    let refunded = false;
    // 只退同一游戏日的次数；跨天后计数已重置，不用退
    if (userRec && userRec.day === u.day && userRec.count > 0) {
        userRec.count -= 1;
        kvSet("global_chaos_letter_counts", counts);
        refunded = true;
    }
    // 冷却只在「还是这条短信设的」时清，之后又发过别的就不动
    if (u.cooldownKey && cachedGet(u.cooldownKey) === String(u.cooldownAt)) cachedSet(u.cooldownKey, "0");
    return refunded ? "（今日短信次数已返还）" : "";
};

// 通用条件检查
function checkCondition(ctx) {
    const triggerCondition = seal.ext.getStringConfig(ext, "群管插件使用需要满足的条件");
    const fmtCondition = parseInt(seal.format(ctx, `{${triggerCondition}}`));
    return fmtCondition === 1;
}

// ========================
// 📡 全局事件监听
// ========================
// ═══ 监听器子处理函数（从 onNotCommandReceived 拆出；触发词匹配仍在监听器内，勿在此加匹配逻辑）═══

// 回复音乐卡片点歌：解析点歌人/留言/歌名/送给，经 WS 读原消息后投递到戏群
// 歌名/送给由玩家自己填写（均选填）：卡片本身多数情况下不带元数据，等卡片发送失败降级成
// 文字兜底时才用得上，靠正则去卡片 JSON 里抠歌名歌手并不可靠
function handleSongCardRequest(ctx, msg, raw, wdId) {
    const rawGid = cachedGet("song_group_id");
    const dM = raw.match(/点歌人[:：]\s*(.*?)(?=\s*(?:留言|歌名|送给)[:：]|$)/);
    const lM = raw.match(/留言[:：]\s*(.*?)(?=\s*(?:点歌人|歌名|送给)[:：]|$)/);
    const nM = raw.match(/歌名[:：]\s*(.*?)(?=\s*(?:点歌人|留言|送给)[:：]|$)/);
    const sM = raw.match(/送给[:：]\s*(.*?)(?=\s*(?:点歌人|留言|歌名)[:：]|$)/);
    if (!rawGid || !dM || !lM) return seal.replyToSender(ctx, msg, !rawGid ? "❌ 未配置戏群" : "⚠️ 格式错误\n正确用法：回复音乐卡片，消息内容写\n点歌人：名字 留言：内容 歌名：歌曲名（选填） 送给：名字（选填）");
    const songGid  = parseInt(rawGid.replace(/[^\d]/g, ""), 10);
    const songDgr  = dM[1].trim();
    const songLy   = lM[1].trim();
    const songName = nM ? nM[1].trim() : "";
    const songTo   = sM ? sM[1].trim() : "";
    const errMsg   = "❌ 点歌失败：LLOneBot 未能读取该消息（可能不在缓存中）。";
    WSM.request(
        { action: "get_msg", params: { message_id: wdId } },
        (response) => {
            if (response.status !== "ok" && response.retcode !== 0) { seal.replyToSender(ctx, msg, errMsg); return; }
            handleSongDelivery(ctx, msg, response.data, songGid, songDgr, songLy, songName, songTo);
        },
        () => seal.replyToSender(ctx, msg, errMsg)
    );
    return seal.ext.newCmdExecuteResult(true);
}

// ========================
// 🍾 漂流瓶：不填收件人的匿名短信，随机送到某个在世玩家手里，
// 靠编号回信（编号绑定「抛瓶人↔捡瓶人」这一对，双方可以一直用同一个编号来回）
// ========================
function getDriftBottles() {
    return kvGet("drift_bottles", { nextId: 1, bottles: {} });
}
function saveDriftBottles(data) {
    kvSet("drift_bottles", data);
}

function handleDriftBottleThrow(ctx, msg, platform, content) {
    const senderRoleName = getRoleName(ctx, msg);
    if (!senderRoleName) return seal.replyToSender(ctx, msg, "❌ 请先创建角色。");
    const uid = getPrimaryUid(platform, msg.sender.userId.replace(`${platform}:`, ""));

    const storage = getRoleStorage()[platform] || {};
    const npcList = kvGet("a_npc_list", []);
    // 拉黑检查：扔瓶子随机分配接收者，直接把拉黑了发送者的人排除在候选池外，避免瓶子随机落到对方手里
    const candidates = Object.entries(storage).filter(([candUid, entry]) =>
        candUid !== uid && entry[0] && !npcList.includes(entry[0]) && !getBlockEntry(platform, candUid, uid)
    );
    if (!candidates.length) return seal.replyToSender(ctx, msg, "🌊 大海太安静了，暂时没有能接到漂流瓶的人。");

    const [catcherUid, catcherEntry] = candidates[Math.floor(Math.random() * candidates.length)];

    const data = getDriftBottles();
    const bottleId = String(data.nextId++);
    data.bottles[bottleId] = { platform, throwerUid: uid, catcherUid, createdAt: Date.now() };
    saveDriftBottles(data);

    const newmsg = seal.newMessage();
    newmsg.messageType = "group";
    newmsg.groupId = `${platform}-Group:${catcherEntry[1]}`;
    const newctx = seal.createTempCtx(ctx.endPoint, newmsg);
    seal.replyToSender(newctx, newmsg,
        `🍾 你捡到一个漂流瓶（编号${bottleId}）：\n「${content}」\n\n想回信就发送：漂流瓶 ${bottleId} 你想说的话`);

    if (isArchiveEnabled()) {
        postToArchive("/api/event", {
            type: "drift_bottle", from_role: senderRoleName, from_qq: uid,
            to_role: catcherEntry[0], to_qq: catcherUid,
            content, extra_info: { bottle_id: bottleId, action: "throw" },
            game_day: cachedGet("global_days") || "", session_id: "", timestamp: Date.now()
        });
    }

    seal.replyToSender(ctx, msg, `🍾 漂流瓶已抛入大海（编号${bottleId}），说不定哪天会有回信……`);
    return seal.ext.newCmdExecuteResult(true);
}

function handleDriftBottleReply(ctx, msg, platform, bottleId, bottle, uid, content) {
    const senderRoleName = getRoleName(ctx, msg);
    if (!senderRoleName) return seal.replyToSender(ctx, msg, "❌ 请先创建角色。");
    const targetUid = bottle.throwerUid === uid ? bottle.catcherUid : bottle.throwerUid;

    // 拉黑检查：对方拉黑了自己就拦下回信，静默伪装送出成功，非静默如实告知
    const bottleBlockEntry = getBlockEntry(platform, targetUid, uid);
    if (bottleBlockEntry) {
        if (bottleBlockEntry.silent) {
            seal.replyToSender(ctx, msg, `🍾 回信已经通过漂流瓶（编号${bottleId}）送出。`);
        } else {
            seal.replyToSender(ctx, msg, `❌ ${resolveUidToName(platform, targetUid)} 已拒绝你的联络。`);
        }
        return seal.ext.newCmdExecuteResult(true);
    }

    const targetEntry = (getRoleStorage()[platform] || {})[targetUid];
    if (!targetEntry) return seal.replyToSender(ctx, msg, "❌ 回信投递失败：找不到对方所在群组。");

    const newmsg = seal.newMessage();
    newmsg.messageType = "group";
    newmsg.groupId = `${platform}-Group:${targetEntry[1]}`;
    const newctx = seal.createTempCtx(ctx.endPoint, newmsg);
    seal.replyToSender(newctx, newmsg,
        `🍾 漂流瓶（编号${bottleId}）有了新的回信：\n「${content}」\n\n想继续回信就发送：漂流瓶 ${bottleId} 你想说的话`);

    if (isArchiveEnabled()) {
        postToArchive("/api/event", {
            type: "drift_bottle", from_role: senderRoleName, from_qq: uid,
            to_role: targetEntry[0], to_qq: targetUid,
            content, extra_info: { bottle_id: bottleId, action: "reply" },
            game_day: cachedGet("global_days") || "", session_id: "", timestamp: Date.now()
        });
    }

    seal.replyToSender(ctx, msg, `🍾 回信已经通过漂流瓶（编号${bottleId}）送出。`);
    return seal.ext.newCmdExecuteResult(true);
}

// 无前缀「短信」：识别署名（含自定义署名开关）后转交寄信流程
function routeChaosLetterMessage(ctx, msg, platform, letM) {
    const allowCustom = cachedGet("allow_custom_letter_sign") === "true";
    const priv = kvGet("a_private_group", {})[platform] || {};
    let snd = "";
    if (allowCustom && letM[1]) {
        // 允许自定义且写了 A 部分，直接取 A
        snd = letM[1].trim();
    } else {
        // 不允许自定义或没写 A，按原逻辑自动识别或校验
        snd = letM[1] ? letM[1].trim() : getRoleName(ctx, msg);
    }
    // 如果开启了自定义，不再强制要求 snd 必须存在于 priv 绑定中
    if (snd && (allowCustom || Object.values(priv).some(v => v[0] === snd))) {
        return handleNaturalChaosLetter(ctx, msg, platform, snd, letM[2].trim(), letM[3].trim());
    }
    return seal.replyToSender(ctx, msg, "❌ 角色识别失败");
}

// 「额外账号」绑定/删除/查看（本人操作）；绑定时清理辅助账号的商城/图鉴数据
function handleExtraAccountMsg(ctx, msg, platform, uid, rest) {
    const selfRoleName = getRoleName(ctx, msg);
    if (!selfRoleName) return seal.replyToSender(ctx, msg, "❌ 请先创建角色。");
    const extras = store.get("extra_accounts");
    if (rest.startsWith("删除")) {
        const extraQQ = rest.slice(2).trim();
        if (!extraQQ) return seal.replyToSender(ctx, msg, "格式：额外账号 删除 QQ号");
        const extraKey = `${platform}:${extraQQ}`;
        if (extras[extraKey] !== uid) return seal.replyToSender(ctx, msg, `❌ 该账号不是你的额外账号`);
        delete extras[extraKey];
        store.set("extra_accounts", extras);
        return seal.replyToSender(ctx, msg, `✅ 已移除额外账号 ${extraQQ}`);
    }
    if (rest) {
        const extraQQ = rest.trim();
        const extraKey = `${platform}:${extraQQ}`;
        if (extras[extraKey]) return seal.replyToSender(ctx, msg, `❌ 该账号已被绑定为其他角色的额外账号`);
        const rolesStorageCheck = store.get("a_private_group")[platform] || {};
        if (rolesStorageCheck[extraQQ]) return seal.replyToSender(ctx, msg, `❌ 该账号已是主账号（角色：${rolesStorageCheck[extraQQ][0]}），无法绑定为额外账号`);
        extras[extraKey] = uid;
        store.set("extra_accounts", extras);

        // 清理辅助账号的商城/图鉴数据，只保留主账号的
        // 1. 删除辅助账号的 gift_sightings（uid-based key）
        const sightings = kvGet("gift_sightings", {});
        const extraSightingKey = `${platform}:${extraQQ}`;
        if (sightings[extraSightingKey]) {
            delete sightings[extraSightingKey];
            kvSet("gift_sightings", sightings);
        }
        // 2. 删除辅助账号的 global_inventories（roleName-based key）
        // 找出辅助账号在 a_private_group 中绑定的角色名
        const rolesStorage = store.get("a_private_group")[platform] || {};
        const extraRoleName = Object.entries(rolesStorage).find(([, v]) => v[0] === extraQQ)?.[0];
        if (extraRoleName) {
            const invs = kvGet("global_inventories", {});
            const extraInvKey = `${platform}:${extraRoleName}`;
            if (invs[extraInvKey]) {
                delete invs[extraInvKey];
                kvSet("global_inventories", invs);
            }
        }
        // 3. 删除辅助账号的 shop_personal_display（uid-based key，抽卡进度）
        const spd = kvGet("shop_personal_display", {});
        if (spd[extraSightingKey]) {
            delete spd[extraSightingKey];
            kvSet("shop_personal_display", spd);
        }

        return seal.replyToSender(ctx, msg, `✅ 已将 ${extraQQ} 绑定为「${selfRoleName}」的额外账号（辅助账号的商城/图鉴数据已清除）`);
    }
    // 查看自己的额外账号
    const myExtras = Object.entries(extras).filter(([, v]) => v === uid).map(([k]) => k.replace(`${platform}:`, ""));
    return seal.replyToSender(ctx, msg, myExtras.length ? `📱 你的额外账号：\n${myExtras.join("\n")}` : "📭 暂无额外账号");
}

// 「角色卡」：汇总档案/装备/属性/货币生成角色卡文本
function handleRoleCardMsg(ctx, msg, platform) {
    const roleName = getRoleName(ctx, msg);
    if (!roleName) return seal.replyToSender(ctx, msg, "❌ 请先创建角色。");
    const uid = getPrimaryUid(platform, msg.sender.userId.replace(`${platform}:`, ""));
    const roleKey = `${platform}:${uid}`;
    const prof = getCharProfile(platform, roleName);

    // 基础信息
    const genderText = prof.gender === "男" ? "👨 男" : "👩 女";
    const ageText = prof.age !== undefined && prof.age !== null ? `${prof.age}岁` : "未设置";

    // ── 装备 ──────────────────────────────────────────────
    const equipLines = [];
    const equipBonus = {};
    try {
        const allEquips = kvGet("player_equipments", {});
        const reg = kvGet("equipment_registry", {});
        const playerEquips = allEquips[roleKey] || {};
        const slots = kvGet("equipment_slots", []);
        const slotNames = kvGet("equipment_slot_names", {});
        const defaultNames = { head:"头部", chest:"胸部", hand:"手部", leg:"腿部", foot:"脚部" };
        const defaultEmoji = { head:"🎩", chest:"🛡️", hand:"⚔️", leg:"👖", foot:"👢" };
        for (const slot of (slots.length ? slots : ["head","chest","hand","leg","foot"])) {
            const e = playerEquips[slot];
            if (e && e.code) {
                const displayName = slotNames[slot] || defaultNames[slot] || slot;
                const emoji = defaultEmoji[slot] || "📦";
                const equipDef = reg[e.code];
                equipLines.push(`${emoji}${displayName}：${equipDef?.name || e.code}`);
                for (const [attr, val] of Object.entries(equipDef?.baseAttrs || {})) {
                    equipBonus[attr] = (equipBonus[attr] || 0) + val;
                }
            }
        }
    } catch(e) { console.error(`[名片] 读取 ${roleKey} 装备失败:`, e.message); }

    // ── 属性 ──────────────────────────────────────────────
    const attrLines = [];
    try {
        const attrDefs = kvGet("rpg_attr_defs", {});
        const charAttrs = kvGet("sys_character_attrs", {});
        // 新结构：charAttrs 以 uid 为 key
        const roleAttrs = charAttrs[uid] || {};
        const BAR = 6;
        for (const [name, def] of Object.entries(attrDefs)) {
            const base = roleAttrs[name] ?? (def.default ?? 0);
            const bonus = equipBonus[name] || 0;
            const val = base + bonus;
            const bonusText = bonus ? ` (${bonus > 0 ? '+' : ''}${bonus})` : '';
            if (def.max !== null && def.max !== undefined && def.min !== null) {
                const pct = def.max === def.min ? 1 : (val - def.min) / (def.max - def.min);
                const filled = Math.round(Math.max(0, Math.min(1, pct)) * BAR);
                attrLines.push(`【${name}】${"▓".repeat(filled)}${"░".repeat(BAR - filled)} ${val}/${def.max}${bonusText}`);
            } else {
                attrLines.push(`【${name}】${val}${bonusText}`);
            }
        }
    } catch(e) { console.error(`[名片] 读取 ${uid} 属性失败:`, e.message); }

    // ── 货币 ──────────────────────────────────────────────
    const currLines = [];
    try {
        const invs = kvGet("global_inventories", {});
        const reg = kvGet("item_registry", {});
        for (const e of (invs[roleKey] || [])) {
            if (e.count > 0 && reg[e.code]?.type === "currency") {
                currLines.push(`${reg[e.code].name}：${e.count}`);
            }
        }
    } catch(e) { console.error(`[名片] 读取 ${roleKey} 货币失败:`, e.message); }

    // ── 拼接 ──────────────────────────────────────────────
    const out = [];
    out.push(`★━━━━━━━━━━★`);
    out.push(`🃏 【${roleName}】`);
    out.push(`★━━━━━━━━━━★`);
    out.push(``);
    out.push(`${genderText} · ${ageText}`);
    out.push(`🌸 皮相：${prof.look || "未设置"}`);
    if (prof.bio) out.push(`✏️ ${prof.bio}`);
    if (attrLines.length) { out.push(``); out.push(`📊 战斗属性`); out.push(...attrLines); }
    if (equipLines.length) { out.push(``); out.push(`⚔️ 装备`); out.push(...equipLines); }
    if (currLines.length) { out.push(``); out.push(`💰 货币`); out.push(...currLines); }
    out.push(``);
    out.push(`★━━━━━━━━━━★`);

    seal.replyToSender(ctx, msg, out.join("\n"));
    return seal.ext.newCmdExecuteResult(true);
}

// 「玩家指南」：角色/账号入门指令一览
function handlePlayerGuideMsg(ctx, msg) {
    const text = [
        "📖 玩家指南",
        "",
        "【创建角色】",
        "创建新角色 角色名",
        "（创建后自动生成初始档案：性别/年龄/皮相）",
        "",
        "【修改档案】",
        "修改名字 新名字",
        "修改性别 男/女",
        "修改年龄 数字",
        "修改皮相 明星名",
        "修改签名 你的签名（12小时冷却）",
        "",
        "【查看】",
        "玩家名单            查看所有角色",
        "地点查看            查看可用地点",
        "我的待回            查看还没回的群/还没进的群/还没退的群，及今日心动信投递情况",
        "我的弧长            查看自己的回复速度统计",
        "我的数量            查看自己今天的私约/电话/短信/礼物/心愿次数，及全服今天总数",
        "（发送「我的」可直接看这三条的速查一览）",
        "",
        "【指令模板】",
        "格式                查看所有指令模板目录",
        "格式+类型           如「格式心动信」，直接拿可复制的模板",
        "",
        "💡 约会/互动类指令（私约、电话、送礼等）发送「基础指南」查看",
    ].join("\n");
    seal.replyToSender(ctx, msg, text);
}

// 「基础指南」：优先从存档服务器拉取，失败回退静态合并转发
function handleBasicGuideMsg(ctx, msg) {
    if (!msg.groupId) {
        return seal.replyToSender(ctx, msg, "请在群内使用此指令。");
    }
    (async () => {
        const base = (seal.ext.getStringConfig(ext, "RP存档服务器地址") || "").replace(/\/$/, "");
        const token = seal.ext.getStringConfig(ext, "RP存档Token") || "";
        if (base) {
            try {
                const resp = await fetch(`${base}/api/command_guides`, {
                    headers: { "X-Archive-Token": token }
                });
                if (resp.ok) {
                    const data = await resp.json();
                    if (data.ok && data.guides && data.guides.length > 0) {
                        if (data.guides.length === 1) {
                            seal.replyToSender(ctx, msg, data.guides[0].text);
                        } else {
                            data.guides.forEach(g => seal.replyToSender(ctx, msg, g.text));
                        }
                        return;
                    }
                }
            } catch (e) {
                console.log("[基础指南] archive 不可用，回退到静态文本:", e.message || String(e));
            }
        }
        // fallback：静态合并转发
        const sections = [
            ["📖 基础指南", ""],
            ["【私约】",
             "私约 1120-1230 地点 对方角色名[/对方2/...]",
             "例：私约 1400-1500 咖啡厅 张三",
             "例：私约 1400-1500 咖啡厅 张三/李四"],
            ["【修改时间线】（在约会群内使用）",
             "修改时间线 D1 1400-1500",
             "",
             "【拒绝时间线】",
             "拒绝时间线 群号"],
            ["【电话】",
             "电话 1100-1200 邀请人1[/邀请人2/...]",
             "例：电话 1400-1500 张三"],
            ["【短信】",
             "[署名]短信 收信人 内容",
             "例：短信 张三 你好！",
             "例：李四短信 张三 你好！",
             "",
             "【送礼】",
             "送礼 对方名 礼物内容",
             "送礼 对方名 #编号（图鉴内礼物，可无限送）"],
            ["【心动信】",
             "发送心动信",
             "【发送对象】角色名",
             "【内容】想说的话",
             "【署名】自定义昵称（选填，不超过20字）",
             "",
             "。撤回心动信 编号   撤回已投递的信",
             "查看信箱            查看收到的心动信",
             "",
             "我的待回            先出一份数量摘要，再以合并转发列出每个群的群名和已经弧了多久（含还没进的群、已结束还没退的群、今日心动信投递情况）"],
        ];
        const gidRaw = parseInt(msg.groupId.replace(/\D/g, ""), 10);
        const nodes = sections.map(lines => ({
            type: "node",
            data: { name: "基础指南", uin: "10001", content: lines.join("\n") }
        }));
        const m = seal.newMessage();
        m.messageType = "group";
        m.groupId = msg.groupId;
        const c = seal.createTempCtx(ctx.endPoint, m);
        ws({ action: "send_group_forward_msg", params: { group_id: gidRaw, messages: nodes } }, c, m, "");
    })();
    return seal.ext.newCmdExecuteResult(true);
}

// 🎭 出场系统已拆分到卫星文件 长日出场.js（2026-07-31），本文件不再包含其实现。

// 「我提交 项目：内容」：项目存在则记录（内容可以不带图片；带图片则尝试转存到 rp_archive，失败则替换为失败提示文字，不留会过期的 QQ 链接）
async function handleInfoSubmit(ctx, msg, subM) {
    const t = subM[1].trim(); // 用户尝试提交的项目名
    const content = subM[2].trim(); // 提交的内容

    // 检查项目是否存在于 projects 列表中
    if (kvGet("sys_info_projects", []).includes(t)) {
        // 逻辑 A: 项目存在，正常记录数据
        // 不再经 rp_archive 下载落地图片，直接存原文（含 QQ 原始 CQ:image 链接），减轻 rp_archive 负担；
        // 记 ts 时间戳供 degradeStaleImages 在展示时按有效期自动降级为纯文字
        const senderName = getRoleName(ctx, msg);
        let d = kvGet("sys_info_collection", {});
        (d[t] = d[t] || []).push({
            sender: senderName,
            time: new Date().toLocaleString(),
            ts: Date.now(),
            text: content
        });
        kvSet("sys_info_collection", d);
        const bgGid = kvGet("background_group_id", null);
        if (bgGid) sendTextToGroup("QQ", bgGid, `📥 ${senderName} 向「${t}」提交了新内容（当前共 ${d[t].length} 条），发送「查看收集 ${t}」查看。`);
        return seal.replyToSender(ctx, msg, `✅ 已记录至「${t}」。`);
    } else {
        // 逻辑 B: 项目不存在，提示联系管理员
        return seal.replyToSender(ctx, msg, `❌ 错误：尚未创建收集集「${t}」，请联系管理员创建后再提交。`);
    }
}

// 「删除上传 项目名 序号」：撤回自己的提交（管理员可删任意人）
async function handleInfoDeleteUpload(ctx, msg, raw, isAdmin) {
    const delArg = raw.slice(4).trim();
    const delM = delArg.match(/^(.+?)\s+(\d+)$/);
    if (!delM) {
        return seal.replyToSender(ctx, msg, `📤 删除上传格式：删除上传 项目名 序号\n示例：删除上传 人物档案 3\n（先用「查看收集 项目名」查看序号）`);
    }
    const delProject = delM[1].trim();
    const delIdx = parseInt(delM[2]) - 1;
    const myName = getRoleName(ctx, msg);
    const projectsList2 = kvGet("sys_info_projects", []);
    if (!projectsList2.includes(delProject)) {
        return seal.replyToSender(ctx, msg, `❌ 未找到项目「${delProject}」`);
    }
    let delData = kvGet("sys_info_collection", {});
    const recs = delData[delProject] || [];
    if (delIdx < 0 || delIdx >= recs.length) {
        return seal.replyToSender(ctx, msg, `❌ 序号超出范围（共 ${recs.length} 条）`);
    }
    const target = recs[delIdx];
    if (!isAdmin && target.sender !== myName) {
        return seal.replyToSender(ctx, msg, `❌ 只能删除自己的提交（该条由「${target.sender || "未知"}」提交）`);
    }
    // 新记录（有 ts）存的是 QQ 原始链接，没有 rp_archive 文件要删；只有老记录（无 ts）需要清理 rp_archive 上的永久文件
    if (!target.ts) {
        for (const url of extractStoredImageUrls(target.text)) {
            await deleteCollectedImage(url);
        }
    }
    recs.splice(delIdx, 1);
    delData[delProject] = recs;
    kvSet("sys_info_collection", delData);
    const bgGidDel = kvGet("background_group_id", null);
    if (bgGidDel) {
        const actor = getRoleName(ctx, msg);
        const who = isAdmin && actor !== target.sender ? `管理员${actor}` : actor;
        sendTextToGroup("QQ", bgGidDel, `🗑️ ${who} 删除了「${delProject}」第 ${delIdx + 1} 条提交（原提交人：${target.sender || "未知"}）。`);
    }
    return seal.replyToSender(ctx, msg, `✅ 已删除「${delProject}」第 ${delIdx + 1} 条提交。`);
}

// 「查看收集 [项目名]」：列出项目或以合并转发展示项目内容
async function handleInfoViewCollection(ctx, msg, raw, isAdmin) {
    const t = raw.replace("查看收集", "").trim();
    const projectsList = kvGet("sys_info_projects", []);
    const privateProjects = kvGet("sys_info_private_projects", []);

    // 1. 如果只输入"查看收集"，列出所有可选项目（私密项目对非管理员隐藏）
    if (!t) {
        const visibleList = isAdmin ? projectsList : projectsList.filter(p => !privateProjects.includes(p));
        return seal.replyToSender(ctx, msg, `📋 可查看的收集项目：\n${visibleList.length ? visibleList.join('\n') : "暂无项目"}`);
    }

    // 2. 私密项目仅管理员可查看内容
    if (privateProjects.includes(t) && !isAdmin) {
        return seal.replyToSender(ctx, msg, `❌ 「${t}」是私密收集，仅管理员可查看提交内容。`);
    }

    // 3. 如果项目存在，展示内容
    if (projectsList.includes(t)) {
        let allInfo = kvGet("sys_info_collection", {});
        let records = allInfo[t] || [];
        if (records.length > 0) {
            // 失效检查：只对老记录（无 ts，即 rp_archive 永久链接）做 HEAD 探活，管理员直接删了文件就整条去掉；
            // 新记录（有 ts，未下载的 QQ 原始链接）不发探活请求，展示时交给 degradeStaleImages 按时间自动降级
            const aliveFlags = await Promise.all(records.map(async (item) => {
                if (item.ts) return true;
                const urls = extractStoredImageUrls(item.text);
                if (urls.length === 0) return true;
                const checks = await Promise.all(urls.map(isStoredImageAlive));
                return checks.every(Boolean);
            }));
            if (aliveFlags.some(alive => !alive)) {
                records = records.filter((_, i) => aliveFlags[i]);
                allInfo[t] = records;
                kvSet("sys_info_collection", allInfo);
            }
            if (records.length === 0) {
                return seal.replyToSender(ctx, msg, `❓ 项目「${t}」目前还没有人提交内容哦。`);
            }
            const gid = parseInt(msg.groupId.replace(/[^\d]/g, ""), 10);
            const nodes = [
                { type: "node", data: { name: "长日将尽", uin: "10001", content: `📖 「${t}」共 ${records.length} 条记录` } },
                ...records.map((item, idx) => ({
                    type: "node",
                    data: {
                        name: item.sender || "未知",
                        uin: "10001",
                        content: `[${idx + 1}] ${item.time}\n${degradeStaleImages(item.text, item.ts)}`
                    }
                }))
            ];
            ws({ action: "send_group_forward_msg", params: { group_id: gid, messages: nodes } }, ctx, msg, "");
            return;
        } else {
            return seal.replyToSender(ctx, msg, `❓ 项目「${t}」目前还没有人提交内容哦。`);
        }
    } else {
        return seal.replyToSender(ctx, msg, `❌ 未找到项目「${t}」，请检查名称是否正确。`);
    }
}

// 私有群监听：RP 正文计入存档/字数，并对格式错误的首行给出提醒
function handlePrivateGroupListen(ctx, msg, platform, groupId, uid) {
    try {
        const a_private_group = kvGet("a_private_group", {});
        // 新结构：a_private_group[platform][uid] = [roleName, gid]，直接用 uid 查
        const roleName = a_private_group[platform]?.[uid]?.[0];

        if (roleName) {
            const _replyResult = handleReply(platform, groupId, roleName, msg.message || "");
            // “已回复过”静默处理，不再提示，避免正常连续发言被打断

            // 格式提示：首行≠角色名时提醒，不计入存档和字数
            // 只在有活跃计时器的群里提示，避免日常闲聊误触发
            // 通用NPC没有固定角色名可比对，格式由 extractGenericRoleContent 自行判断，跳过这条提示
            const _hintTimers = getGroupTimers();
            const _hintTimer = _hintTimers[groupId];
            if (_hintTimer && !kvGet("a_generic_npc_list", []).includes(roleName)) {
                const _hintLines = (msg.message || "").split("\n");
                const _hintFirst = _hintLines[0].trim();
                if (extractRoleContent(msg.message || "", roleName) === null) {
                    const _isPhone = _hintTimer.subtype === "电话";
                    // 电话群：所有不符合格式的消息都提醒
                    // 其他群：仅在首行像角色名（≤20字）且有第二行时提醒（避免日常闲聊刷屏）
                    const _msgLen = (msg.message || "").length;
                    const _shouldHint = _isPhone
                        || _msgLen >= 50
                        || (_hintFirst.length >= 1 && _hintFirst.length <= 20
                            && _hintLines.length >= 2 && _hintLines[1].trim());
                    if (_shouldHint) {
                        seal.replyToSender(ctx, msg,
                            `⚠️ 首行「${_hintFirst}」不是你的角色名，这条不会计入存档和字数。\n你的角色名是「${roleName}」`);
                    }
                }
            }
        }
    } catch (e) {
        console.error('监听系统错误:', e);
    }
}

ext.onNotCommandReceived = async (ctx, msg) => {
    const raw = (msg.rawMessage || msg.message || "").trim();
    const platform = msg.platform;
    const _rawUid = msg.sender.userId.replace(`${platform}:`, '');
    const uid = getPrimaryUid(platform, _rawUid); // 辅助账号自动解析为主账号 uid
    const groupId = msg.groupId.replace(`${platform}-Group:`, ''), isAdmin = isUserAdmin(ctx, msg);
    const getS = (k) => kvGet(k, (k.includes("list") || k.includes("presets") || k.includes("projects")) ? [] : {});

    // 1. 回复卡片逻辑 (撤回/点歌/复盘)
    const replyMatch = raw.match(/\[CQ:reply,id=(\-?\d+)\]/);
    if (replyMatch) {
        const wdId = Number(replyMatch[1]);
        if (raw.includes("撤回")) {
            const _wdRoleName = kvGet("a_private_group", {})[platform]?.[uid]?.[0];
            if (_wdRoleName) syncWithdrawToArchive(wdId, groupId, _wdRoleName);
            // 引用的是短信/礼物/拉线（指令或回执）时连对方群里那条一起撤；对不上记录就跟以前一样只删被引用的这条。
            // 发错撤回不受「群管插件使用需要满足的条件」限制（那个开关常被限定到戏群，会把个人群挡掉），
            // 退回原逻辑时 withdrawMsg 内部仍照旧检查
            return handleQuotedWithdraw(ctx, msg, wdId, raw);
        }
        if (raw.includes("点歌")) return handleSongCardRequest(ctx, msg, raw, wdId);
        if (raw.includes("转发复盘")) {
            return seal.replyToSender(ctx, msg, "📋 当前版本无需转发复盘，直接发送「结束私约」退群即可。");
        }
    }

    // 2.5 点歌引导（未回复卡片时单独发点歌）
    if (raw === "点歌") {
        return seal.replyToSender(ctx, msg, "🎵 点歌用法：回复一张音乐卡片，消息内容写\n点歌人：名字 留言：内容 歌名：歌曲名（选填） 送给：名字（选填）\n例：点歌人：张三 留言：送给你的歌 歌名：晴天 送给：李四");
    }

    // 2.6 格式导览：新手记不住各种指令格式时，发「格式」查目录，发「格式+类型」直接拿可复制的模板
    const FORMAT_TEMPLATES = {
        "心动信": "发送心动信\n【发送对象】角色名\n【内容】想说的话\n【署名】自定义昵称（选填）",
        "短信":   `短信 收信人 内容\n例：短信 张三 你好！\n\n${RECALL_FORMAT_HINT}`,
        "漂流瓶": "漂流瓶 内容\n例：漂流瓶 有人能听到我说话吗\n\n回信（对方捡到后会得到编号）：漂流瓶 编号 内容\n例：漂流瓶 1 我听到啦，你还好吗",
        "前置电话": "前置电话 编号\n例：前置电话 1\n（编号对应谁只有管理员知道，可以多次选不同编号）",
        "信件":   "发送信件\n【收件人】小明\n【内容】亲爱的小明，今天天气真好...\n【日期】2026年4月28日（选填）\n【附件】随信附上一份礼物（选填）\n【署名】小红（选填）",
        "私约":   "私约 1400-1500 咖啡厅 张三",
        "电话":   "电话 1400-1500 张三",
        "送礼":   `送礼 张三 一束玫瑰\n\n${RECALL_FORMAT_HINT}`,
        "心愿":   "挂心愿 1400-1500 花园 一起散步",
        "悬赏心愿": "悬赏心愿 1400-1500 图书馆 陪我看书 | 滋补汤 1",
        "拉线":   `拉线 张三 在高中时期是同班同学\n\n${RECALL_FORMAT_HINT}`,
        "发帖":   "发帖 张三 今天天气真好！",
        "点歌":   "（先回复一张音乐卡片，再发送）\n点歌人：张三 留言：这首歌送给你 歌名：晴天（选填） 送给：李四（选填）",
        "撤回":   "短信/礼物/拉线发错人时：\n长按你发的那条（或机器人回的「已送达」那条）→ 引用/回复 → 发送：\n撤回\n\n· 2 分钟内有效，已送到对方群里的那条会一起删掉\n· 今日次数返还，可以马上重发给对的人\n· 超过 2 分钟请联系管理员帮忙撤回",
    };
    // 管理员配置的个性化触发词（私约别名/短信别名/送礼别名）也各自生成一份可复制模板，
    // 跟原指令共用同一套「格式」导览，不用额外记文档
    for (const a of getPrivateAliases()) {
        if (!a.trigger || FORMAT_TEMPLATES[a.trigger]) continue;
        FORMAT_TEMPLATES[a.trigger] = a.baseType === "phone"
            ? `${a.trigger} 1400-1500 张三`
            : `${a.trigger} 1400-1500 咖啡厅 张三`;
    }
    for (const trig of getSmsAliases().map(a => a.trigger).filter(Boolean)) {
        if (FORMAT_TEMPLATES[trig]) continue;
        FORMAT_TEMPLATES[trig] = `${trig} 收信人 内容\n例：${trig} 张三 你好！\n\n${RECALL_FORMAT_HINT}`;
    }
    for (const trig of kvGet("gift_aliases", []).map(a => a.trigger).filter(Boolean)) {
        if (FORMAT_TEMPLATES[trig]) continue;
        FORMAT_TEMPLATES[trig] = `${trig} 对方名 礼物内容\n例：${trig} 张三 一束玫瑰\n\n${RECALL_FORMAT_HINT}`;
    }
    if (raw === "格式") {
        const nav = Object.keys(FORMAT_TEMPLATES).map(k => `如果需要${k}格式，发送「格式${k}」`).join("\n");
        return seal.replyToSender(ctx, msg, `📋 输入「格式+类型」直接拿可复制的指令模板：\n\n${nav}`);
    }
    if (raw.startsWith("格式") && FORMAT_TEMPLATES[raw.slice(2).trim()]) {
        return seal.replyToSender(ctx, msg, FORMAT_TEMPLATES[raw.slice(2).trim()]);
    }

    const smsTriggers = ["短信", ...getSmsAliases().map(a => a.trigger).filter(Boolean)];
    let letM = null;
    for (const trig of smsTriggers) {
        letM = raw.match(new RegExp(`^(.+?)?${escapeRegExp(trig)}\\s*(.+?)\\s+([\\s\\S]+)$`));
        if (letM) break;
    }
    if (letM) {
        return routeChaosLetterMessage(ctx, msg, platform, letM);
    } else if (smsTriggers.some(trig => new RegExp(`^(.+?)?${escapeRegExp(trig)}$`).test(raw))) {
        return seal.replyToSender(ctx, msg, "💌 短信格式：[署名]短信 收信人 内容\n例：短信 李四 你好！\n例：张三短信 李四 你好！");
    }

    // 3.5 漂流瓶：不填收件人，随机送到某个玩家手里；对方用「漂流瓶 编号 内容」原路回信
    if (raw.startsWith("漂流瓶")) {
        const rest = raw.slice(3).trim();
        if (!rest) {
            return seal.replyToSender(ctx, msg, "🍾 漂流瓶格式：\n扔漂流瓶：漂流瓶 内容\n回信：漂流瓶 编号 内容\n例：漂流瓶 有人能听到我说话吗\n例：漂流瓶 1 我听到啦，你还好吗");
        }
        const replyM = rest.match(/^(\d+)\s+([\s\S]+)$/);
        if (replyM) {
            const bottleId = replyM[1];
            const data = getDriftBottles();
            const bottle = data.bottles[bottleId];
            const uid = getPrimaryUid(platform, msg.sender.userId.replace(`${platform}:`, ""));
            if (bottle && bottle.platform === platform && (bottle.throwerUid === uid || bottle.catcherUid === uid)) {
                return handleDriftBottleReply(ctx, msg, platform, bottleId, bottle, uid, replyM[2].trim());
            }
            // 编号不存在或不属于自己：多半是正文碰巧带数字，按新漂流瓶处理，不报错打断
        }
        return handleDriftBottleThrow(ctx, msg, platform, rest);
    }

    // 3.6 前置电话（收集模式）：玩家自助提交自我介绍类内容，不显示提交人/时间，
    // 收齐所有非NPC角色后才可查看，届时随机打乱分配编号
    if (raw.startsWith("前置电话收集")) {
        const content = raw.slice(6).trim();
        const roleName = getRoleName(ctx, msg);
        if (!roleName) return seal.replyToSender(ctx, msg, "❌ 请先创建角色。");
        if (getPretelMode() !== "收集") return seal.replyToSender(ctx, msg, "❌ 当前不是「收集」模式，请联系管理员「开启前置电话 收集」。");
        if (!content) return seal.replyToSender(ctx, msg, "格式：前置电话收集 内容\n（可以随时重新发送来修改自己的内容）");

        const platform = msg.platform;
        const collection = getPretelCollection();
        const idx = collection.findIndex(e => e.sender === roleName);
        const isUpdate = idx !== -1;
        if (isUpdate) collection[idx].text = content;
        else collection.push({ sender: roleName, text: content });
        savePretelCollection(collection);

        const total = getPretelEligibleCount(platform);
        let reply = isUpdate ? "✅ 已更新你的前置电话收集内容。" : `✅ 已记录你的前置电话收集内容（${collection.length}/${total}）。`;

        // 只在"第一次收齐"时打乱分配编号；如果之后又有新角色注册导致 total 变大，
        // 不会因为迟到的提交重新洗牌，避免打乱已经在用的编号（有人可能已经据此挑了号）
        if (!Object.keys(getPretelList()).length && collection.length >= total && total > 0) {
            const shuffled = shuffleArray(collection);
            const list = {};
            shuffled.forEach((e, i) => { list[String(i + 1)] = e.sender; });
            savePretelList(list);
            reply += "\n🎉 已收集齐所有人，编号已随机打乱分配，发送「查看前置电话收集」即可查看内容。";
        }
        return seal.replyToSender(ctx, msg, reply);
    }

    // 3.7 查看前置电话收集：收齐前只显示进度，不透露任何内容/提交人；收齐后按（打乱后的）编号顺序显示内容
    if (raw === "查看前置电话收集") {
        const platform = msg.platform;
        if (getPretelMode() !== "收集") return seal.replyToSender(ctx, msg, "❌ 当前不是「收集」模式。");
        const collection = getPretelCollection();
        const total = getPretelEligibleCount(platform);
        if (!collection.length) return seal.replyToSender(ctx, msg, "📭 目前还没有人提交前置电话收集内容。");
        const list = getPretelList();
        if (!Object.keys(list).length) {
            return seal.replyToSender(ctx, msg, `⏳ 还没收集齐，暂不可查看（${collection.length}/${total}）。`);
        }
        const contentBySender = {};
        collection.forEach(e => { contentBySender[e.sender] = e.text; });
        const showGender = getPretelShowGender();
        const nums = Object.keys(list).sort((a, b) => parseInt(a) - parseInt(b));
        const lines = nums.map(n => {
            const genderTag = showGender ? `(${getCharProfile(platform, list[n]).gender || "?"}) ` : "";
            return `${n} ${genderTag}: ${contentBySender[list[n]] || "（内容缺失）"}`;
        });
        return seal.replyToSender(ctx, msg, `📞 前置电话收集内容（共${nums.length}份）：\n${lines.join("\n")}`);
    }

    // 3.8 取消前置电话：安排前置电话之前可以撤回某个已选编号
    if (raw.startsWith("取消前置电话")) {
        const numRaw = raw.slice(6).trim();
        const roleName = getRoleName(ctx, msg);
        if (!roleName) return seal.replyToSender(ctx, msg, "❌ 请先创建角色。");
        if (!numRaw || !/^\d+$/.test(numRaw)) {
            return seal.replyToSender(ctx, msg, "格式：取消前置电话 编号\n例：取消前置电话 1");
        }
        const pretelPicks = getPretelPicks();
        if (!pretelPicks[roleName] || !pretelPicks[roleName].includes(numRaw)) {
            return seal.replyToSender(ctx, msg, `❌ 你没有选过编号「${numRaw}」。`);
        }
        pretelPicks[roleName] = pretelPicks[roleName].filter(n => n !== numRaw);
        savePretelPicks(pretelPicks);
        return seal.replyToSender(ctx, msg, `✅ 已取消编号「${numRaw}」的意向。`);
    }

    // 3.9 前置电话：玩家凭编号表达接听意向，不知道编号对应谁，可多次选不同编号
    if (raw.startsWith("前置电话")) {
        const numRaw = raw.slice(4).trim();
        const roleName = getRoleName(ctx, msg);
        if (!roleName) return seal.replyToSender(ctx, msg, "❌ 请先创建角色。");
        if (!numRaw || !/^\d+$/.test(numRaw)) {
            return seal.replyToSender(ctx, msg, "格式：前置电话 编号\n例：前置电话 1");
        }
        const pretelList = getPretelList();
        if (!Object.keys(pretelList).length) return seal.replyToSender(ctx, msg, "❌ 当前没有开放的前置电话名单。");
        if (!pretelList[numRaw]) return seal.replyToSender(ctx, msg, `❌ 编号「${numRaw}」不在本轮可选范围内。`);
        if (pretelList[numRaw] === roleName) return seal.replyToSender(ctx, msg, "❌ 不能选到自己。");

        const pretelPicks = getPretelPicks();
        if (!pretelPicks[roleName]) pretelPicks[roleName] = [];
        if (pretelPicks[roleName].includes(numRaw)) return seal.replyToSender(ctx, msg, `你已经选过编号「${numRaw}」了。`);
        pretelPicks[roleName].push(numRaw);
        savePretelPicks(pretelPicks);
        return seal.replyToSender(ctx, msg, `✅ 已记录你的前置电话意向（第${pretelPicks[roleName].length}个）。`);
    }

    // 4. 约会/邀约/微信/心愿/发帖/心动信（无指令前缀触发）
    const makeFakeCmdArgs = (parts) => ({
        getArgN: (n) => parts[n - 1] || "",
        args: parts
    });

    if (raw.startsWith("电话")) {
        const rest = raw.slice(2).trim();
        return cmd_phone.solve(ctx, msg, makeFakeCmdArgs(rest ? rest.split(/\s+/) : []));
    }

    if (raw.startsWith("踩点")) {
        const rest = raw.slice(2).trim();
        return handleStakeout(ctx, msg, makeFakeCmdArgs(rest ? rest.split(/\s+/) : []));
    }

    if (raw.startsWith("约战")) {
        const toggle = kvGet("global_feature_toggle", {});
        if (!toggle.dlc_battle_appt) return seal.replyToSender(ctx, msg, "❌ 约战功能未开启，请联系管理员。");
        const rest = raw.slice(2).trim();
        return cmd_appointment_private.solve(ctx, msg, makeFakeCmdArgs(rest ? rest.split(/\s+/) : []), { trigger: "约战", icon: "⚔️" });
    }

    const _matchedAlias = getPrivateAliases().find(a => a.trigger && raw.startsWith(a.trigger));
    if (_matchedAlias) {
        const rest = raw.slice(_matchedAlias.trigger.length).trim();
        const fakeArgs = makeFakeCmdArgs(rest ? rest.split(/\s+/) : []);
        // baseType === "phone"：别名只是电话的另一个触发词，格式/门槛/开关完全复用电话本体，不论别名改叫什么名字都始终对应「电话门槛」
        if (_matchedAlias.baseType === "phone") return cmd_phone.solve(ctx, msg, fakeArgs);
        return cmd_appointment_private.solve(ctx, msg, fakeArgs, _matchedAlias);
    }

    if (raw.startsWith("私约")) {
        const rest = raw.slice(2).trim();
        return cmd_appointment_private.solve(ctx, msg, makeFakeCmdArgs(rest ? rest.split(/\s+/) : []));
    }

    if (raw.startsWith("微信")) {
        const rest = raw.slice(2).trim();
        return cmd_wechat.solve(ctx, msg, makeFakeCmdArgs(rest ? [rest] : []));
    }

    if (raw.startsWith("发送心动信")) {
        return cmd_send_lovemail.solve(ctx, msg, makeFakeCmdArgs([]));
    }

    if (raw === "查看信箱") return cmd_view_mylovemails.solve(ctx, msg, makeFakeCmdArgs([]));

    if (raw.startsWith("发帖")) {
        const rest = raw.slice(2).trim();
        if (rest) return cmd_post_forum.solve(ctx, msg, makeFakeCmdArgs(rest.split(/\s+/)));
    }

    if (raw.startsWith("回复帖子")) {
        const rest = raw.slice(4).trim();
        if (rest) return cmd_reply_post.solve(ctx, msg, makeFakeCmdArgs(rest.split(/\s+/)));
    }

    if (raw.startsWith("查看帖子")) {
        const rest = raw.slice(4).trim();
        return cmd_view_posts.solve(ctx, msg, makeFakeCmdArgs(rest ? [rest] : []));
    }


    // 4.5 角色系统（无前缀）
    if (raw.startsWith("创建新角色")) {
        const rest = raw.slice(5).trim();
        if (rest) return cmd_bind_role.solve(ctx, msg, makeFakeCmdArgs(rest.split(/\s+/)));
    }

    if (raw === "玩家名单") return cmd_role_list.solve(ctx, msg, makeFakeCmdArgs([]));

    if (raw === "地点查看" || raw === "查看地点") {
        return cmdPlace.solve(ctx, msg, makeFakeCmdArgs(["查看"]));
    }

    if (raw.startsWith("申请加入")) {
        const rest = raw.slice(4).trim();
        if (rest) return cmd_apply_join.solve(ctx, msg, makeFakeCmdArgs(rest.split(/\s+/)));
    }

    // 4.7 额外账号（无前缀，本人操作）
    if (raw.startsWith("额外账号")) {
        return handleExtraAccountMsg(ctx, msg, platform, uid, raw.slice(4).trim());
    }

    // 4.8 角色档案修改（无前缀）
    if (raw.startsWith("修改名字") || raw.startsWith("修改姓名")) {
        const newName = raw.slice(4).trim();
        if (!newName) return seal.replyToSender(ctx, msg, "格式：修改名字 新名字");
        return doRenameRole(ctx, msg, newName);
    }

    if (raw.startsWith("修改性别")) {
        const roleName = getRoleName(ctx, msg);
        if (!roleName) return seal.replyToSender(ctx, msg, "❌ 请先创建角色。");
        const val = raw.slice(4).trim();
        if (val !== "男" && val !== "女") return seal.replyToSender(ctx, msg, "性别仅支持：男 / 女");
        setCharProfile(platform, roleName, { gender: val });
        return seal.replyToSender(ctx, msg, `✅ 性别已更新为：${val}`);
    }

    if (raw.startsWith("修改年龄")) {
        const roleName = getRoleName(ctx, msg);
        if (!roleName) return seal.replyToSender(ctx, msg, "❌ 请先创建角色。");
        const val = parseInt(raw.slice(4).trim());
        if (isNaN(val) || val < 0 || val > 200) return seal.replyToSender(ctx, msg, "❌ 请输入有效年龄（0-200）");
        setCharProfile(platform, roleName, { age: val });
        return seal.replyToSender(ctx, msg, `✅ 年龄已更新为：${val}`);
    }

    if (raw.startsWith("修改皮相")) {
        const roleName = getRoleName(ctx, msg);
        if (!roleName) return seal.replyToSender(ctx, msg, "❌ 请先创建角色。");
        const val = raw.slice(4).trim();
        if (!val) return seal.replyToSender(ctx, msg, "请输入明星名，例：修改皮相 刘亦菲");
        const prof = getCharProfile(platform, roleName);
        const now = Date.now();
        const cooldown = 2 * 3600 * 1000;
        if (prof.lookUpdatedAt && now - prof.lookUpdatedAt < cooldown) {
            const remain = Math.ceil((cooldown - (now - prof.lookUpdatedAt)) / 60000);
            return seal.replyToSender(ctx, msg, `⏳ 皮相修改冷却中，还需等待 ${remain} 分钟`);
        }
        setCharProfile(platform, roleName, { look: val, lookUpdatedAt: now });
        return seal.replyToSender(ctx, msg, `✅ 皮相已更新为：${val}`);
    }

    if (raw.startsWith("修改签名")) {
        const roleName = getRoleName(ctx, msg);
        if (!roleName) return seal.replyToSender(ctx, msg, "❌ 请先创建角色。");
        const val = raw.slice(4).trim();
        if (!val) return seal.replyToSender(ctx, msg, "请输入签名内容，例：修改签名 愿岁月温柔以待");
        const prof = getCharProfile(platform, roleName);
        const now = Date.now();
        const cooldown = 12 * 3600 * 1000;
        if (prof.bioUpdatedAt && now - prof.bioUpdatedAt < cooldown) {
            const remain = Math.ceil((cooldown - (now - prof.bioUpdatedAt)) / 60000);
            return seal.replyToSender(ctx, msg, `⏳ 签名修改冷却中，还需等待 ${remain} 分钟`);
        }
        setCharProfile(platform, roleName, { bio: val, bioUpdatedAt: now });
        return seal.replyToSender(ctx, msg, `✅ 签名已更新为：${val}`);
    }

    if (raw === "角色卡") return handleRoleCardMsg(ctx, msg, platform);

    // 4.11 时间线
    if (raw === "时间线") return cmd_view_schedule.solve(ctx, msg, makeFakeCmdArgs([]));
    if (raw === "我的") {
        return seal.replyToSender(ctx, msg,
            "📋 「我的」系列一览：\n" +
            "我的待回      还没回的群/还没进的群/还没退的群，及今日心动信投递情况\n" +
            "我的弧长      自己的历史平均回复速度统计\n" +
            "我的数量      自己今天的私约/电话/短信/礼物/心愿次数，及全服今天总数"
        );
    }
    if (raw === "我的待回") return cmd_my_pending.solve(ctx, msg);
    if (raw === "我的弧长") return cmdMyArcLength.solve(ctx, msg);
    if (raw === "我的数量") return cmdMyCounts.solve(ctx, msg);
    if (raw.startsWith("结束私约")) {
        const rest = raw.slice(4).trim();
        return cmd_grouplist_release.solve(ctx, msg, makeFakeCmdArgs(rest ? rest.split(/\s+/) : []));
    }

    // 4.12 加入请求
    if (raw === "加入请求") return cmd_join_requests.solve(ctx, msg, makeFakeCmdArgs([]));
    if (raw.startsWith("同意加入")) {
        const rest = raw.slice(4).trim();
        if (rest) return cmd_accept_join.solve(ctx, msg, makeFakeCmdArgs([rest]));
    }
    if (raw.startsWith("拒绝加入")) {
        const rest = raw.slice(4).trim();
        if (rest) return cmd_reject_join.solve(ctx, msg, makeFakeCmdArgs([rest]));
    }

    // 4.14.0 玩家指南
    if (raw === "玩家指南") return handlePlayerGuideMsg(ctx, msg);

    // 4.14.1 基础指南
    if (raw === "基础指南") return handleBasicGuideMsg(ctx, msg);

    // 4.15 管理员无前缀指令
    if (isAdmin) {
        if (raw === "查看计时器") return cmd_view_timers.solve(ctx, msg, makeFakeCmdArgs([]));
        if (raw === "查看进行中" || raw.startsWith("查看进行中 ")) {
            const dayPart = raw.slice(5).trim();
            return cmd_admin_view_active.solve(ctx, msg, makeFakeCmdArgs(dayPart ? [dayPart] : []));
        }
        if (raw.startsWith("提醒超时")) {
            const rest = raw.slice(4).trim();
            return cmd_remind_timeouts.solve(ctx, msg, makeFakeCmdArgs(rest ? [rest] : []));
        }
        if (raw.startsWith("设定关系线")) {
            const param = raw.slice(5).trim();
            if (!param) {
                const maxChars = cachedGet("max_detail_chars") || "500";
                const maxRel = cachedGet("max_relationships_per_user") || "20";
                return seal.replyToSender(ctx, msg, `📐 设定关系线\n字数上限：${maxChars} 字\n关系线上限：${maxRel} 条\n\n格式：\n设定关系线 字数上限 N\n设定关系线 关系上限 N`);
            }
            const m = param.match(/^(字数上限|关系上限)\s+(\d+)$/);
            if (!m) return seal.replyToSender(ctx, msg, "格式：设定关系线 字数上限 500\n  或：设定关系线 关系上限 20");
            const val = parseInt(m[2]);
            if (val <= 0) return seal.replyToSender(ctx, msg, "❌ 数值必须为正整数");
            if (m[1] === "字数上限") {
                cachedSet("max_detail_chars", String(val));
                return seal.replyToSender(ctx, msg, `✅ 单条拉线字数上限已设为 ${val} 字`);
            } else {
                cachedSet("max_relationships_per_user", String(val));
                return seal.replyToSender(ctx, msg, `✅ 关系线上限已设为 ${val} 条`);
            }
        }
        if (raw.startsWith("发起官约")) {
            const rest = raw.slice(4).trim();
            if (rest) return cmd_create_official_appointment.solve(ctx, msg, makeFakeCmdArgs(rest.split(/\s+/)));
        }
    }


    // 5. 信息收集系统 & 设定NPC
    const projects = getS("sys_info_projects"); // 获取已有的项目列表
    const subM = raw.match(/^我提交\s*(.+?)[:：\s]\s*([\s\S]+)$/);
    if (subM) return handleInfoSubmit(ctx, msg, subM);

    // --- 删除上传：用户撤回自己的提交 ---
    if (raw.startsWith("删除上传")) return handleInfoDeleteUpload(ctx, msg, raw, isAdmin);

    // --- 所有人可用的查看功能 ---
    if (raw.startsWith("查看收集")) return handleInfoViewCollection(ctx, msg, raw, isAdmin);

    // --- 设定 NPC 指令 ---
    const npcM = raw.match(/^设定\s*(.+?)\s*为\s*npc$/i);
    if (npcM && isAdmin) {
        const name = npcM[1].trim(); let npcList = getS("a_npc_list");
        if (!getUidByRoleName(platform, name)) return seal.replyToSender(ctx, msg, `❌ 未找到角色「${name}」`);
        const idx = npcList.indexOf(name);
        if (idx === -1) npcList.push(name); else npcList.splice(idx, 1);
        kvSet("a_npc_list", npcList);
        return seal.replyToSender(ctx, msg, `✅ ${name} 的 NPC 身份已${idx === -1 ? '设定' : '取消'}`);
    }

    if (isAdmin) {
        if (raw.startsWith("创建私密收集") && isAdmin) {
            const pN = raw.replace("创建私密收集", "").trim();
            if (pN && !projects.includes(pN)) {
                projects.push(pN);
                kvSet("sys_info_projects", projects);
                let privateProjects = getS("sys_info_private_projects");
                privateProjects.push(pN);
                kvSet("sys_info_private_projects", privateProjects);
                return seal.replyToSender(ctx, msg, `✅ 已建立私密项目：${pN}（提交格式与普通收集一致，但只有管理员能查看提交内容）`);
            }
        } else if (raw.startsWith("创建收集") && isAdmin) {
            const pN = raw.replace("创建收集", "").trim();
            if (pN && !projects.includes(pN)) { projects.push(pN); kvSet("sys_info_projects", projects); return seal.replyToSender(ctx, msg, `✅ 已建立项目：${pN}`); }
        }
        let allInfo = getS("sys_info_collection");
        if (raw.startsWith("我清空")) {
            const t = raw.replace("我清空", "").trim();
            if (allInfo[t]) {
                const clearedCount = allInfo[t].length;
                for (const rec of allInfo[t]) {
                    for (const url of extractStoredImageUrls(rec.text)) {
                        await deleteCollectedImage(url);
                    }
                }
                allInfo[t] = []; kvSet("sys_info_collection", allInfo);
                const bgGidClear = kvGet("background_group_id", null);
                if (bgGidClear) sendTextToGroup("QQ", bgGidClear, `🗑️ 管理员${getRoleName(ctx, msg)} 清空了「${t}」的全部提交（共 ${clearedCount} 条）。`);
                return seal.replyToSender(ctx, msg, `🗑️ 已清空「${t}」`);
            }
        }
    }

    // 5. 私有群监听（正文计入存档/字数 + 首行格式提醒）
    handlePrivateGroupListen(ctx, msg, platform, groupId, uid);
};

let cmd_view_timers = {};
cmd_view_timers.solve =(ctx, msg) => {
    if (!isUserAdmin(ctx, msg)) return;

    const timers = kvGet("group_timers", {}), now = Date.now();
    const tKeys = Object.keys(timers);
    if (!tKeys.length) return seal.replyToSender(ctx, msg, "📭 当前没有活跃的计时器");

    let totalOverdue = 0;
    const timerNodes = [];
    tKeys.forEach(gid => {
        const t = timers[gid];
        const safeTimeoutDuration = sanitizeTimeoutMs(t.timeoutDuration, getMonitorSettings().timeout);
        const detail = Object.entries(t.timerStatus).map(([name, s]) => {
            const replies = s.sessionReplies || 0;
            const words = s.sessionWords || 0;
            const avg = replies > 0 ? Math.round(words / replies) : 0;
            const statLine = `  📝 ${replies}段 / ${words}字 / 均${avg}字`;

            if (s.status !== "timing") return `✅ ${name}: replied\n${statLine}`;

            const diff = safeTimeoutDuration - (now - s.startTime);
            const isOver = diff < 0;
            if (isOver) totalOverdue++;

            return `${isOver ? "🔴" : "⏳"} ${name}: ${Math.abs(Math.round(diff / 60000))}min${isOver ? "!" : ""}\n${statLine}`;
        }).join('\n');

        timerNodes.push({
            type: "node",
            data: { name: `群组 ${gid} | ${t.subtype}`, uin: "10001", content: `📍 模式：${t.timerMode === 'turn_taking' ? '轮流' : '独立'}\n— 以上 —\n${detail}` }
        });
    });

    const gId = parseInt(msg.groupId.replace(/[^\d]/g, ""), 10);
    const CHUNK = 10;
    const totalBatches = Math.ceil(timerNodes.length / CHUNK);
    const timeStr = new Date().toLocaleTimeString();

    for (let i = 0; i < totalBatches; i++) {
        const batchLabel = totalBatches > 1 ? `（第${i + 1}批/共${totalBatches}批）` : "";
        const header = { type: "node", data: { name: "计时监控中心", uin: "2852199344", content: `📊 运行中：${tKeys.length} 个${batchLabel}\n更新：${timeStr}` } };
        const chunk = [header, ...timerNodes.slice(i * CHUNK, (i + 1) * CHUNK)];
        ws({ action: "send_group_forward_msg", params: { group_id: gId, messages: chunk } }, ctx, msg, "");
    }

    seal.replyToSender(ctx, msg, `✅ 报表已生成${totalBatches > 1 ? `（共${totalBatches}批）` : ""}\n⏳ 超时：${totalOverdue} 人\n(详情见下方合并消息)`);
    return seal.ext.newCmdExecuteResult(true);
};

// 时长格式化：X小时Y分钟 / Y分钟
function formatDurationMin(ms) {
    const totalMin = Math.max(0, Math.round(ms / 60000));
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    return h > 0 ? `${h}小时${m}分钟` : `${m}分钟`;
}

// 「我的弧长」：本人历史平均回复耗时（含已结/未结场次）+ 当前所有未结双人场次里，自己和对方的回复次数对比、
// 本人在这场内的平均耗时、以及当前轮到谁回复、对方（或自己）已经等了多久
// 弧长报告核心：「我的弧长」（查自己）和「查看弧长」（管理员查他人）共用
function buildArcLengthReport(platform, roleName, uid) {
    const allStats = getUserStats();
    const myStat = allStats[`${platform}:${uid}`];
    const totalTimed = myStat ? (myStat.timedReplies || 0) : 0;
    const totalSessions = myStat && myStat.sessionIds ? myStat.sessionIds.length : 0;
    const avgMin = myStat ? (myStat.avgReplyTimeMin || 0) : 0;

    let rep = `【${roleName} 的弧长】\n本人总平均：${avgMin}分钟（${totalTimed}次，${totalSessions}场，含已结/未结）\n`;

    const timers = getGroupTimers();
    const now = Date.now();
    const myGroups = Object.entries(timers).filter(([, t]) =>
        t.timerMode === "turn_taking" && t.timerStatus && t.timerStatus[roleName]
    );

    const myIndepGroups = Object.entries(timers).filter(([, t]) =>
        t.timerMode === "independent" && t.timerStatus && t.timerStatus[roleName]
    );

    if (myGroups.length === 0 && myIndepGroups.length === 0) {
        rep += `\n当前没有进行中的场次。`;
    }

    if (myGroups.length > 0) {
        const lines = myGroups.map(([gid, t]) => {
            const otherName = (t.participants || []).find(p => p !== roleName);
            const myS = t.timerStatus[roleName];
            const otherS = otherName ? t.timerStatus[otherName] : null;

            const myReplies = myS.sessionReplies || 0;
            const otherReplies = otherS ? (otherS.sessionReplies || 0) : 0;
            const myTimedReplies = myS.sessionTimedReplies || 0;
            const myAvg = myTimedReplies > 0 ? Math.round(myS.sessionReplyTimeMs / myTimedReplies / 60000) : 0;

            const waitingOnMe = myS.status === "timing";
            const waitingStatus = waitingOnMe ? myS : otherS;
            const waitDuration = waitingStatus ? formatDurationMin(now - waitingStatus.startTime) : "—";
            const waitingOnLabel = waitingOnMe ? "你" : (otherName || "?");
            const waitLine = waitingOnMe ? `你还没回：${waitDuration}` : `${otherName || "?"}未回：${waitDuration}`;

            return `${getCustomTypeLabel(t.subtype)}${gid}：${roleName}x${otherName || "?"} ${myReplies}v${otherReplies}（待${waitingOnLabel}），本人平均${myAvg}分钟（${myTimedReplies}次），${waitLine}`;
        });
        rep += `\n当前未结双嘉宾小群：\n${lines.join("\n")}`;
    }

    if (myIndepGroups.length > 0) {
        const indepLines = myIndepGroups.map(([gid, t]) => {
            const myS = t.timerStatus[roleName];
            const myReplies = myS.sessionReplies || 0;
            const myTimedReplies = myS.sessionTimedReplies || 0;
            const myAvg = myTimedReplies > 0 ? Math.round(myS.sessionReplyTimeMs / myTimedReplies / 60000) : 0;
            const myWaitLine = myS.status === "timing"
                ? `你还没回：${formatDurationMin(now - myS.startTime)}`
                : `你已回复，等其他人`;

            const others = (t.participants || []).filter(p => p !== roleName);
            const waitingOthers = others.filter(p => t.timerStatus[p] && t.timerStatus[p].status === "timing");
            const othersLine = waitingOthers.length > 0
                ? waitingOthers.map(p => `${p}未回：${formatDurationMin(now - t.timerStatus[p].startTime)}`).join("、")
                : "其他人均已回复";

            return `${getCustomTypeLabel(t.subtype)}${gid}：${roleName}所在多人场（共${(t.participants || []).length}人），本人平均${myAvg}分钟（${myTimedReplies}次，本场共${myReplies}次），${myWaitLine}；${othersLine}`;
        });
        rep += `\n当前未结多人场次：\n${indepLines.join("\n")}`;
    }

    return rep;
}

let cmdMyArcLength = seal.ext.newCmdItemInfo();
cmdMyArcLength.name = "我的弧长";
cmdMyArcLength.help = "。我的弧长 —— 查看自己的历史平均回复耗时，以及当前所有未结双人场次里，自己和对方各自的回复次数、本场平均耗时、当前等待时长";
cmdMyArcLength.solve = (ctx, msg) => {
    const platform = msg.platform;
    const roleName = getRoleName(ctx, msg);
    if (!roleName) {
        seal.replyToSender(ctx, msg, "❌ 请先创建角色。");
        return seal.ext.newCmdExecuteResult(true);
    }
    const rawUid = msg.sender.userId.replace(`${platform}:`, "");
    const uid = getPrimaryUid(platform, rawUid);
    seal.replyToSender(ctx, msg, buildArcLengthReport(platform, roleName, uid));
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["我的弧长"] = cmdMyArcLength;

// 统计指定游戏日的私约/电话/短信/礼物/心愿数量，供「我的数量」和天数切换公告共用
// 私约/电话按 b_confirmedSchedule 里当天的场次算，全员总数按 group 号去重避免双人各记一次；
// 短信/礼物/心愿直接读现成的「每人每天」计数器（本来就是给每日次数上限用的，天然带 day 字段）
function getDailyActivityCounts(day, userKey) {
    const b_confirmedSchedule = kvGet("b_confirmedSchedule", {});
    const isAppointmentType = (subtype) => subtype !== "官约" && subtype !== "踩点";
    const seenGroups = new Set();
    let totalPrivate = 0, totalPhone = 0, myPrivate = 0, myPhone = 0;
    for (const [key, events] of Object.entries(b_confirmedSchedule)) {
        for (const ev of events) {
            if (ev.day !== day || !isAppointmentType(ev.subtype)) continue;
            if (key === userKey) { if (ev.subtype === "电话") myPhone++; else myPrivate++; }
            if (!ev.group || seenGroups.has(ev.group)) continue;
            seenGroups.add(ev.group);
            if (ev.subtype === "电话") totalPhone++; else totalPrivate++;
        }
    }

    const sumTodayCounts = (storeKey) => {
        const store = kvGet(storeKey, {});
        let mine = 0, total = 0;
        for (const [key, rec] of Object.entries(store)) {
            if (!rec || rec.day !== day) continue;
            total += rec.count || 0;
            if (key === userKey) mine += rec.count || 0;
        }
        return { mine, total };
    };
    const sms = sumTodayCounts("global_chaos_letter_counts");
    const gift = sumTodayCounts("global_gift_stats");
    const wishPost = sumTodayCounts("wish_daily_post_counts");
    const wishPick = sumTodayCounts("wish_daily_pick_counts");

    return {
        my: { private: myPrivate, phone: myPhone, sms: sms.mine, gift: gift.mine, wish: wishPost.mine + wishPick.mine },
        total: { private: totalPrivate, phone: totalPhone, sms: sms.total, gift: gift.total, wish: wishPost.total + wishPick.total }
    };
}

function getTodayActivitySummaryLine(day) {
    const { total } = getDailyActivityCounts(day, null);
    return `🌐 全员今天：私约 ${total.private} 次｜电话 ${total.phone} 次｜短信 ${total.sms} 次｜礼物 ${total.gift} 次｜心愿 ${total.wish} 次`;
}

// 「我的数量」：自己今天发起的私约/电话/短信/心愿次数 + 全服今天的私约/电话/短信/礼物/心愿总数
let cmdMyCounts = seal.ext.newCmdItemInfo();
cmdMyCounts.name = "我的数量";
cmdMyCounts.help = "。我的数量 —— 查看自己今天发起的私约/电话/短信/心愿次数，以及全服今天的私约/电话/短信/礼物/心愿总数";
cmdMyCounts.solve = (ctx, msg) => {
    const platform = msg.platform;
    const rawUid = msg.sender.userId.replace(`${platform}:`, "");
    const uid = getPrimaryUid(platform, rawUid);
    const roleName = getRoleName(ctx, msg);
    if (!roleName) {
        seal.replyToSender(ctx, msg, "❌ 请先创建角色。");
        return seal.ext.newCmdExecuteResult(true);
    }
    const userKey = `${platform}:${uid}`;
    const gameDay = cachedGet("global_days") || "D0";
    const counts = getDailyActivityCounts(gameDay, userKey);

    let reply = `📊 我的数量（${gameDay}）\n`;
    reply += `👤 我今天：私约 ${counts.my.private} 次｜电话 ${counts.my.phone} 次｜短信 ${counts.my.sms} 次｜礼物 ${counts.my.gift} 次｜心愿 ${counts.my.wish} 次\n`;
    reply += getTodayActivitySummaryLine(gameDay);

    seal.replyToSender(ctx, msg, reply);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["我的数量"] = cmdMyCounts;

let cmdViewArcLength = seal.ext.newCmdItemInfo();
cmdViewArcLength.name = "查看弧长";
cmdViewArcLength.help = "。查看弧长 [角色名] —— 管理员专属，查看指定角色的弧长情况，格式同「我的弧长」";
cmdViewArcLength.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用");
        return seal.ext.newCmdExecuteResult(true);
    }
    const name = cmdArgs.getArgN(1);
    if (!name) {
        seal.replyToSender(ctx, msg, "格式：。查看弧长 角色名");
        return seal.ext.newCmdExecuteResult(true);
    }
    const platform = msg.platform;
    const uid = getUidByRoleName(platform, name);
    if (!uid) {
        seal.replyToSender(ctx, msg, `❌ 未找到角色「${name}」`);
        return seal.ext.newCmdExecuteResult(true);
    }
    seal.replyToSender(ctx, msg, buildArcLengthReport(platform, name, uid));
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["查看弧长"] = cmdViewArcLength;

let cmd_remind_timeouts = {};
cmd_remind_timeouts.solve =(ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) return seal.replyToSender(ctx, msg, "🌸 只有管理员可以呼唤大家哦～");

    const target = cmdArgs.getArgN(1), now = Date.now();
    const timers = kvGet("group_timers", {});
    let sentCount = 0, detail = [], allEntries = [];

    for (const [gid, timer] of Object.entries(timers)) {
        if (target && gid !== target) continue;

        // 修复损坏的 timeoutDuration（见 sanitizeTimeoutMs 注释），已在跑的计时器也能自愈，
        // 不必手动改库或重开约会
        timer.timeoutDuration = sanitizeTimeoutMs(timer.timeoutDuration, getMonitorSettings().timeout);

        const groupReminders = Object.entries(timer.timerStatus).filter(([name, s]) => {
            if (s.status !== "timing") return false;
            const elapsed = now - s.startTime;
            return elapsed > timer.timeoutDuration;
        });

        groupReminders.forEach(([name, s]) => {
            allEntries.push({ gid, timer, name, s, elapsed: now - s.startTime });
            sentCount++;
        });

        if (groupReminders.length) {
            timer.lastRemindTime = now;
            detail.push(`群组 ${gid}: ${groupReminders.map(r => r[0]).join("、")}`);
        }
    }
    processOverdueBatch(ctx, allEntries);

    if (sentCount > 0) {
        kvSet("group_timers", timers);
        seal.replyToSender(ctx, msg, `💖 提醒任务完成！\n共送出 ${sentCount} 份温柔提醒：\n${detail.join('\n')}\n大家一定会感受到的～ 🌟`);
    } else {
        seal.replyToSender(ctx, msg, "🌙 检查了一圈，现在大家都很守时，不需要打扰呢～");
    }
    return seal.ext.newCmdExecuteResult(true);
};

// ========================
// 📋 我的待回：列出玩家自己还没回的群（超时的置顶）+ 今日心动信投递情况
// ========================
let cmd_my_pending = {};
cmd_my_pending.solve = async (ctx, msg) => {
    const platform = msg.platform;
    const roleName = getRoleName(ctx, msg);
    if (!roleName) return seal.replyToSender(ctx, msg, "✨ 请先使用「创建新角色」认领你的身份吧。");

    const uid = getPrimaryUid(platform, msg.sender.userId.replace(`${platform}:`, ""));
    const extras = kvGet("extra_accounts", {});
    const myUids = new Set([uid, ...Object.entries(extras)
        .filter(([k, v]) => k.startsWith(`${platform}:`) && v === uid)
        .map(([k]) => k.replace(`${platform}:`, ""))]);
    const isMemberOf = async (gid) => {
        const members = await getGroupMembersSilent(gid, ctx, msg);
        return members.some(m => myUids.has((m.user_id ?? m.qq)?.toString()));
    };

    const now = Date.now();
    const timers = kvGet("group_timers", {});
    const baseTimeout = getMonitorSettings().timeout;

    const pending = [];    // 需要你回复的场次（status: timing）
    const notJoined = [];  // 场次已开但你实际还没进这个群
    for (const [gid, timer] of Object.entries(timers)) {
        if (timer.platform !== platform) continue;
        const s = timer.timerStatus[roleName];
        if (!s || s.status === "replied") continue;

        const inGroup = await isMemberOf(gid);
        if (s.status === "timing") {
            const safeTimeout = sanitizeTimeoutMs(timer.timeoutDuration, baseTimeout);
            const elapsed = now - s.startTime;
            pending.push({ gid, subtype: timer.subtype, elapsed, isOver: elapsed > safeTimeout, inGroup });
        } else if (!inGroup) {
            notJoined.push({ gid, subtype: timer.subtype });
        }
    }
    // 超时的排最前，同为超时/未超时时等得越久的越靠前
    pending.sort((a, b) => (b.isOver - a.isOver) || (b.elapsed - a.elapsed));

    const fmtElapsed = (ms) => {
        const h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000);
        return h > 0 ? `${h}h${m}m` : `${m}m`;
    };

    // 已结束但还没退群（结束私约/强结私约 时记录，实时核对是否仍在群里）
    const leaveStore = kvGet("pending_leave_check", {});
    const myLeaveChecks = leaveStore[roleName] || [];
    const stillLingering = [];
    if (myLeaveChecks.length) {
        const groupPool = kvGet("group", []);
        const remaining = [];
        for (const entry of myLeaveChecks) {
            // 群号已被重新分配（不在空闲池里）：旧记录失效，直接丢弃，不再核对
            if (!groupPool.includes(entry.gid)) continue;
            if (await isMemberOf(entry.gid)) {
                stillLingering.push(entry);
                remaining.push(entry);
            }
            // 已经查不到人了：视为已退群，不再保留
        }
        if (remaining.length !== myLeaveChecks.length) {
            if (remaining.length) leaveStore[roleName] = remaining; else delete leaveStore[roleName];
            kvSet("pending_leave_check", leaveStore);
        }
    }

    // 关系线待回：最后一条细节不是自己发的，说明轮到自己回复（系统强制关系线、已确认完成的不计入）
    const pendingRel = [];
    if (cachedGet("relationship_system_enabled") === "true") {
        const relData = kvGet("relationship_lines", {});
        const myRels = relData[platform]?.[uid] || {};
        for (const [counterpartUid, rel] of Object.entries(myRels)) {
            if (rel.initiator === "SYSTEM" || rel.confirmed || !rel.details?.length) continue;
            const last = rel.details[rel.details.length - 1];
            if (last.from !== roleName) pendingRel.push({ name: resolveUidToName(platform, counterpartUid) });
        }
    }

    // 今日心动信（功能关闭时不显示）
    const globalDay = cachedGet("global_days") || "";
    let lovemailLine = "（当前未设置游戏天数）";
    let sentToday = [];
    if (isLoveMailEnabled() && globalDay) {
        const dayLimits = kvGet("lovemail_day_limits", {});
        const defaultLimit = parseInt(cachedGet("lovemail_default_limit") || "3");
        const maxPerDay = dayLimits[globalDay] !== undefined ? dayLimits[globalDay] : defaultLimit;
        sentToday = kvGet("lovemail_pool", []).filter(r => r.uid === uid && r.gameDay === globalDay);
        const remain = Math.max(0, maxPerDay - sentToday.length);
        lovemailLine = `已投递 ${sentToday.length}/${maxPerDay} 封，还能写 ${remain} 封`;
    }

    // ---- 1. 先发一份摘要回执 ----
    const overCount = pending.filter(p => p.isOver).length;
    const hasDetail = pending.length || notJoined.length || stillLingering.length || pendingRel.length;
    const summaryLines = [`📋 ${roleName} 的待回速览`];
    if (!hasDetail) {
        summaryLines.push("🌙 当前没有等待你处理的事项，很守时哦～");
    } else {
        summaryLines.push(`🔴 待回复：${pending.length} 个群${overCount ? `（其中 ${overCount} 个已超时）` : ""}`);
        if (notJoined.length) summaryLines.push(`🚪 待进群：${notJoined.length} 个`);
        if (stillLingering.length) summaryLines.push(`🚶 待退群：${stillLingering.length} 个`);
        if (pendingRel.length) summaryLines.push(`🔗 待回关系线：${pendingRel.length} 条`);
    }
    if (isLoveMailEnabled()) summaryLines.push(`💌 心动信：${lovemailLine}`);
    seal.replyToSender(ctx, msg, summaryLines.join("\n"));

    if (!hasDetail) return;

    // ---- 2. 再发一份合并转发，展开每个群的名字和已经弧了多久 ----
    const allGids = [...new Set([
        ...pending.map(p => p.gid),
        ...notJoined.map(n => n.gid),
        ...stillLingering.map(e => e.gid)
    ])];
    const nameEntries = await Promise.all(allGids.map(async gid =>
        [gid, (await getGroupInfoSilent(gid, ctx, msg))?.group_name || null]
    ));
    const nameMap = Object.fromEntries(nameEntries);
    const gidLabel = (gid) => nameMap[gid] ? `${nameMap[gid]}（${gid}）` : `群 ${gid}`;

    const botUid = ctx.endPoint.userId;
    const nodes = [{ type: "node", data: { name: "待回管家", uin: botUid, content: `📋 ${roleName} 的待回详情` } }];

    if (pending.length) {
        nodes.push({ type: "node", data: { name: "待回管家", uin: botUid, content: "🔴 还没回复的场次" } });
        pending.forEach(p => {
            const content =
                `${p.isOver ? "🔴 已超时" : "⏳ 等待中"}\n` +
                `群：${gidLabel(p.gid)}\n` +
                `类型：${getCustomTypeLabel(p.subtype)}\n` +
                `已经弧了：${fmtElapsed(p.elapsed)}` +
                `${p.inGroup ? "" : "\n⚠️ 你好像还没进这个群"}`;
            nodes.push({ type: "node", data: { name: gidLabel(p.gid), uin: botUid, content } });
        });
    }
    if (notJoined.length) {
        nodes.push({ type: "node", data: { name: "待回管家", uin: botUid, content: "🚪 已开场但你还没进群" } });
        notJoined.forEach(n => {
            nodes.push({ type: "node", data: { name: gidLabel(n.gid), uin: botUid, content: `群：${gidLabel(n.gid)}\n类型：${getCustomTypeLabel(n.subtype)}` } });
        });
    }
    if (stillLingering.length) {
        nodes.push({ type: "node", data: { name: "待回管家", uin: botUid, content: "🚶 已结束但你好像还没退群" } });
        stillLingering.forEach(e => {
            nodes.push({ type: "node", data: { name: gidLabel(e.gid), uin: botUid, content: `群：${gidLabel(e.gid)}\n类型：${getCustomTypeLabel(e.subtype)}` } });
        });
    }
    if (pendingRel.length) {
        nodes.push({ type: "node", data: { name: "待回管家", uin: botUid, content: "🔗 待回关系线" } });
        pendingRel.forEach(r => {
            nodes.push({ type: "node", data: { name: r.name, uin: botUid, content: `${r.name}已回复你的关系线\n💡 发送「查看关系线 ${r.name}」查看完整细节并回复` } });
        });
    }
    if (sentToday.length) {
        nodes.push({ type: "node", data: { name: "待回管家", uin: botUid, content: `💌 今日已写给：${sentToday.map(r => r.receiver).join("、")}` } });
    }

    if (msg.groupId) {
        ws({ action: "send_group_forward_msg", params: { group_id: parseInt(msg.groupId.replace(/[^\d]/g, ""), 10), messages: nodes } }, ctx, msg, "");
    } else {
        // 私聊没有合并转发能力，退化为逐条普通消息
        for (const node of nodes) seal.replyToSender(ctx, msg, node.data.content);
    }
};

// ========================
// 更新活跃计时器超时/提醒间隔（供设置面板改「超时时间」「提醒间隔」时调用，让正在跑的计时器立刻生效，
// 而不是只影响之后新建的群）。两个参数任传一个，另一个传 null/undefined 表示不改。
function updateActiveTimerSettings(newTimeout, newRemindInterval) {
    const timers = getGroupTimers();
    let changed = false;
    for (const timer of Object.values(timers)) {
        if (newTimeout != null && timer.timeoutDuration !== newTimeout) {
            timer.timeoutDuration = newTimeout;
            changed = true;
        }
        if (newRemindInterval != null && timer.remindInterval !== newRemindInterval) {
            timer.remindInterval = newRemindInterval;
            changed = true;
        }
    }
    if (changed) saveGroupTimers(timers);
}

// ========================
// 📮 派送辅助与档期自动 D0
// ========================

// requireApi 在主插件里永远成立，shim 保持接口一致
function requireApi(ctx, msg) { return true; }

// ========================
// 💌 心动信系统
// ========================

let cmd_send_lovemail = {};
cmd_send_lovemail.solve =(ctx, msg, cmdArgs) => {
    if (!requireApi(ctx, msg)) return seal.ext.newCmdExecuteResult(true);
    const config = kvGet("global_feature_toggle", {});
    if (config.enable_lovemail === false) {
        seal.replyToSender(ctx, msg, "💌 心动信箱已关闭，暂不可投稿");
        return seal.ext.newCmdExecuteResult(true);
    }
    { const _fw = checkTsFeatureWindow("enable_lovemail"); if (!_fw.ok) { seal.replyToSender(ctx, msg, _fw.msg); return seal.ext.newCmdExecuteResult(true); } }

    const platform = msg.platform;
    const uid = getPrimaryUid(platform, msg.sender.userId.replace(`${platform}:`, ""));
    const a_private_group = kvGet("a_private_group", {});

    const senderRoleName = getRoleName(ctx, msg);
    if (!senderRoleName) {
        seal.replyToSender(ctx, msg, "✨ 远方的旅人，寄信前请先使用「创建新角色」来认领你的身份吧。");
        return seal.ext.newCmdExecuteResult(true);
    }

    const raw = msg.message.trim();
    const getTag = (tag) => {
        const regex = new RegExp(`【${tag}】([\\s\\S]*?)(?=【|$)`, "i");
        const match = raw.match(regex);
        return match ? match[1].trim() : null;
    };

    const signature = getTag("署名") || "匿名";
    const receiver = getTag("发送对象") || getTag("收件人");
    let content = getTag("内容") || "";

    if (/\[CQ:image[^\]]*\]/.test(signature)) {
        seal.replyToSender(ctx, msg, `⚠️ 署名不能包含图片，请修改后重新投递。`);
        return seal.ext.newCmdExecuteResult(true);
    }
    if (signature.length > 20) {
        seal.replyToSender(ctx, msg, `⚠️ 署名不得超过 20 个字（当前 ${signature.length} 个字），请修改后重新投递。`);
        return seal.ext.newCmdExecuteResult(true);
    }
    if (/\[CQ:image[^\]]*\]/.test(content)) {
        seal.replyToSender(ctx, msg, `⚠️ 心动信内容不能包含图片，请修改后重新投递。`);
        return seal.ext.newCmdExecuteResult(true);
    }

    if (!receiver) {
        seal.replyToSender(ctx, msg, `⚠️ 格式错误！请指定发送对象。`);
        seal.replyToSender(ctx, msg, `发送心动信\n【发送对象】角色名\n【内容】想说的话\n【署名】自定义昵称（选填）`);
        return seal.ext.newCmdExecuteResult(true);
    }

    const receiverUid = getUidByRoleName(platform, receiver);
    if (!a_private_group[platform] || !receiverUid) {
        seal.replyToSender(ctx, msg, `⚠️ 找不到角色「${receiver}」的投递地址，请确认名字是否正确。`);
        return seal.ext.newCmdExecuteResult(true);
    }

    let globalDay = cachedGet("global_days");
    if (!globalDay) {
        seal.replyToSender(ctx, msg, "⚠️ 当前未设置游戏天数，请联系管理员设置「。设置天数 D0」");
        return seal.ext.newCmdExecuteResult(true);
    }

    const dayLimits = kvGet("lovemail_day_limits", {});
    const defaultLimit = parseInt(cachedGet("lovemail_default_limit") || "3");
    let maxPerDay = dayLimits[globalDay] !== undefined ? dayLimits[globalDay] : defaultLimit;
    if (maxPerDay <= 0) {
        seal.replyToSender(ctx, msg, `📪 当前游戏天数 ${globalDay} 的心动信投稿已关闭。`);
        return seal.ext.newCmdExecuteResult(true);
    }

    let dayCounts = kvGet("lovemail_day_counts", {});
    if (!dayCounts[uid]) dayCounts[uid] = {};
    const currentCount = dayCounts[uid][globalDay] || 0;

    if (currentCount >= maxPerDay) {
        seal.replyToSender(ctx, msg, `📪 在当前游戏天数 ${globalDay} 中，你已投稿 ${currentCount} 封（上限 ${maxPerDay} 封）。请等待下一天再试。`);
        return seal.ext.newCmdExecuteResult(true);
    }

    const mailKey = "lovemail_pool";
    let records = kvGet(mailKey, []);
    records.push({ uid, receiver, content, signature, gameDay: globalDay, timestamp: Date.now() });
    kvSet(mailKey, records);

    dayCounts[uid][globalDay] = currentCount + 1;
    kvSet("lovemail_day_counts", dayCounts);

    let reply = `💌 心动信已成功投递至「${receiver}」的信箱！\n`;
    reply += `📝 署名：${signature}\n`;
    reply += `📅 游戏天数：${globalDay}（今日剩余次数：${maxPerDay - (currentCount + 1)}/${maxPerDay}）\n`;
    reply += `✨ 提示：管理员统一送出前，你仍可以使用「。撤回心动信」取消本次投递。`;
    seal.replyToSender(ctx, msg, reply);
    return seal.ext.newCmdExecuteResult(true);
};

function generateMailReport(records, title = "📮 心动信派送清单") {
    if (!records?.length) return [];
    const mailBox = records.reduce((map, r) => ((map[r.receiver] ??= []).push(r), map), {});
    const nodes = [{
        type: "node",
        data: {
            name: "心动邮局·系统日志", uin: "2852199344",
            content: `${title}\n🕐 ${new Date().toLocaleString()}\n📬 待派送信件总数：${records.length} 封\n— 以上 —`
        }
    }];
    const MAX = 1200;
    for (const [receiver, mails] of Object.entries(mailBox)) {
        let text = `👤 收件人：${receiver}\n📨 信件数量：${mails.length} 封\n┈┈┈┈┈┈┈┈┈┈\n`;
        let part = 1;
        mails.forEach((mail, idx) => {
            const letter = `【信件 ${idx + 1}】\n📝 署名：${mail.signature}\n📜 内容：${mail.content}\n${idx < mails.length - 1 ? '┈┈┈┈┈┈┈┈┈┈\n' : ''}`;
            if ((text + letter).length > MAX) {
                nodes.push({ type: "node", data: { name: `致 ${receiver} 的信件 (分册 ${part})`, uin: "10001", content: text.trim() } });
                text = `👤 收件人：${receiver} (接前文)\n┈┈┈┈┈┈┈┈┈┈\n${letter}`;
                part++;
            } else text += letter;
        });
        nodes.push({ type: "node", data: { name: part === 1 ? `致 ${receiver} 的信件` : `致 ${receiver} 的信件 (终卷)`, uin: "10001", content: text.trim() } });
    }
    return nodes;
}

let cmd_stat_lovemail = seal.ext.newCmdItemInfo();
cmd_stat_lovemail.name = "信箱统计";
cmd_stat_lovemail.solve = (ctx, msg, cmdArgs) => {
    if (!requireApi(ctx, msg)) return seal.ext.newCmdExecuteResult(true);
    if (!isUserAdmin(ctx, msg)) return seal.replyToSender(ctx, msg, "✨ 抱歉，这里只有邮局守护者才能进入哦。");
    const records = kvGet("lovemail_pool", []);
    if (!records.length) return seal.replyToSender(ctx, msg, "🕊️ 此时的邮局静悄悄的，还没有待投递的心意。");

    const nodes = generateMailReport(records, "🌸 心动邮局·巡检手记");
    nodes[0].data.content = `🌸 此时此刻，共有 ${records.length} 份心意正在等待传递\n🕰️ 巡检时间：${new Date().toLocaleString()}\n愿每一份温柔都能准时抵达。`;

    const targetGid = msg.groupId.replace(/\D/g, "");
    for (let i = 0; i < nodes.length; i += 90) {
        ws({ action: "send_group_forward_msg", params: { group_id: parseInt(targetGid, 10), messages: nodes.slice(i, i + 90) } }, ctx, msg, "");
    }

    const receiverCount = new Set(records.map(r => r.receiver)).size;
    seal.replyToSender(ctx, msg, `✅ 统计报表已封缄完毕\n📮 发现 ${receiverCount} 位收件人的小小秘密\n✨ 巡检记录共计 ${nodes.length} 页，请您审阅。`);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["信箱统计"] = cmd_stat_lovemail;

let cmd_view_mylovemails = {};
cmd_view_mylovemails.solve =(ctx, msg, cmdArgs) => {
    if (!requireApi(ctx, msg)) return seal.ext.newCmdExecuteResult(true);
    const platform = msg.platform;
    const uid = getPrimaryUid(platform, msg.sender.userId.replace(`${platform}:`, ""));
    const records = kvGet("lovemail_pool", []);
    const my = records.filter(r => r.uid === uid);
    if (!my.length) return seal.replyToSender(ctx, msg, "📭 你目前没有待投递的信件。");
    let res = "📄 你待投递的信件如下：\n";
    my.forEach((r, i) => res += `\n#${i + 1} | 接收者: ${r.receiver}\n内容: ${r.content}\n`);
    seal.replyToSender(ctx, msg, res);
    return seal.ext.newCmdExecuteResult(true);
};

let cmd_revoke_lovemail = seal.ext.newCmdItemInfo();
cmd_revoke_lovemail.name = "撤回心动信";
cmd_revoke_lovemail.solve = (ctx, msg, cmdArgs) => {
    if (!requireApi(ctx, msg)) return seal.ext.newCmdExecuteResult(true);
    const senderRoleName = getRoleName(ctx, msg);
    if (!senderRoleName) {
        seal.replyToSender(ctx, msg, "✨ 你还不是本系统的会员，请先使用「创建新角色」来认领你的身份吧。");
        return seal.ext.newCmdExecuteResult(true);
    }
    const platform = msg.platform;
    const uid = getPrimaryUid(platform, msg.sender.userId.replace(`${platform}:`, ""));
    const idx = parseInt(cmdArgs.getArgN(1)) - 1;
    let records = kvGet("lovemail_pool", []);
    const my = records.filter(r => r.uid === uid);
    if (isNaN(idx) || idx < 0 || idx >= my.length) {
        return seal.replyToSender(ctx, msg, "⚠️ 请输入正确的序号，例如：。撤回心动信 1");
    }
    const targetMail = my[idx];
    const originalIdx = records.indexOf(targetMail);
    const finalRecords = originalIdx !== -1
        ? records.slice(0, originalIdx).concat(records.slice(originalIdx + 1))
        : records.filter(r => r !== targetMail);

    let dayCounts = kvGet("lovemail_day_counts", {});
    const gameDay = targetMail.gameDay;
    if (dayCounts[uid] && dayCounts[uid][gameDay] && dayCounts[uid][gameDay] > 0) {
        dayCounts[uid][gameDay]--;
        if (dayCounts[uid][gameDay] === 0) delete dayCounts[uid][gameDay];
        if (Object.keys(dayCounts[uid]).length === 0) delete dayCounts[uid];
        kvSet("lovemail_day_counts", dayCounts);
    }
    kvSet("lovemail_pool", finalRecords);
    seal.replyToSender(ctx, msg, `✅ 已成功撤回发送给「${targetMail.receiver}」的信件。\n📪 已恢复你在「${gameDay}」的 1 次发送机会。`);
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["撤回心动信"] = cmd_revoke_lovemail;

const isLoveMailEnabled = () => kvGet("global_feature_toggle", {}).enable_lovemail !== false;

function performLoveMailDelivery(ctx, msg, backgroundGroupId) {
    const platform = msg?.platform ?? "QQ";
    const mailKey = "lovemail_pool";
    let records = [];
    try {
        records = kvGet(mailKey, []);
    } catch (e) {
        console.error(`[心动信箱] 无法读取信件池: ${e.message}`);
    }
    if (!records.length) return { success: 0, fail: 0, empty: true, status: "信池为空" };

    const ep = (ctx && ctx.endPoint) ? ctx.endPoint : getSafeEndPoint(platform);
    if (!ep) {
        console.error("[心动信箱] 致命错误：无可用的 EndPoint，派送中止");
        return { success: 0, fail: 0, status: "找不到EndPoint" };
    }

    const sendForward = (gid, nodes) => {
        const raw = gid.toString().replace(/\D/g, "");
        const m = seal.newMessage();
        m.messageType = "group";
        m.groupId = `${platform}-Group:${raw}`;
        const c = seal.createTempCtx(ep, m);
        ws({ action: "send_group_forward_msg", params: { group_id: parseInt(raw, 10), messages: nodes } }, c, m, "");
    };

    if (backgroundGroupId && records.length) {
        const reportNodes = generateMailReport(records, "📋 心动信自动派送清单");
        if (reportNodes.length) sendForward(backgroundGroupId, reportNodes);
    }

    const a_private_group = kvGet("a_private_group", {});
    const isPublicEnabled = cachedGet("lovemail_expose") === "true";
    const publicChance = getStorageInt("lovemail_expose_chance", 10);
    const hideReceiverOnDrop = cachedGet("drop_hide_receiver") === "true";
    let announceGroupId = kvGet("adminAnnounceGroupId", null);
    if (!announceGroupId || announceGroupId === "null") announceGroupId = null;

    const mailBox = records.reduce((map, r) => ((map[r.receiver] ??= []).push(r), map), {});
    let success = 0, fail = 0, publicCount = 0, maxReceived = 0;
    const publicNodes = [];
    const failedRecords = [];

    for (const [receiver, mails] of Object.entries(mailBox)) {
        const recvUid = getUidByRoleName(platform, receiver);
        const addr = recvUid ? a_private_group[platform]?.[recvUid] : null;
        if (addr) {
            if (mails.length > maxReceived) maxReceived = mails.length;
            const targetGidRaw = (addr[1] || "").replace(/\D/g, "");
            const personalNodes = [{ type: "node", data: { name: "心动邮局·派送员", uin: "2852199344", content: `💌 亲爱的 ${receiver}，你有一份包含 ${mails.length} 封信件的包裹待启封。` } }];
            const imageGroups = [];
            mails.forEach((mail, idx) => {
                const imgMatches = mail.content.match(/\[CQ:image[^\]]*\]/g) || [];
                const textOnly = mail.content.replace(/\[CQ:image[^\]]*\]/g, "").trim();
                imageGroups.push(imgMatches);
                personalNodes.push({ type: "node", data: { name: `第 ${idx + 1} 封信件`, uin: "10001", content: `「 ${textOnly || "（图片见下方）"} 」\n┈┈┈┈┈┈┈┈┈┈┈┈\n📝 署名：${mail.signature}` } });
                success++;
                const isThisMailPublic = isPublicEnabled && announceGroupId &&
                    (Math.floor(Math.random() * 100) + 1 <= publicChance);
                if (isArchiveEnabled()) {
                    const fromRole = a_private_group[platform]?.[mail.uid]?.[0];
                    if (!fromRole) console.warn(`[心动信] 派送存档找不到发件人角色名，UID: ${mail.uid}`);
                    postToArchive("/api/event", {
                        type:            "lovemail",
                        from_role:       fromRole || mail.uid,
                        from_custom_name: mail.signature && mail.signature !== (fromRole || mail.uid) ? mail.signature : undefined,
                        to_role:         receiver,
                        content:         mail.content,
                        extra_info:      { signature: mail.signature, isPublic: isThisMailPublic, hide_receiver: isThisMailPublic && hideReceiverOnDrop },
                        game_day:        mail.gameDay || "",
                        session_id:      "",
                        timestamp:       mail.timestamp || Date.now()
                    });
                }
                if (isThisMailPublic) {
                    publicCount++;
                    const publicReceiver = hideReceiverOnDrop ? "某人" : receiver;
                    publicNodes.push({ type: "node", data: { name: "飘落的信笺", uin: "2852199344", content: `📩 寄给「${publicReceiver}」的心动信\n来自「${mail.signature}」\n内容：「${mail.content}」` } });
                }
            });
            sendForward(targetGidRaw, personalNodes);
            mails.forEach((mail, idx) => {
                const imgs = imageGroups[idx];
                if (!imgs.length) return;
                const label = `📎 第 ${idx + 1} 封信件（署名：${mail.signature}）附带的图片：`;
                sendTextToGroup(platform, targetGidRaw, label + "\n" + imgs.join("\n"));
            });
        } else {
            failedRecords.push(...mails);
            fail += mails.length;
        }
    }

    if (publicNodes.length && announceGroupId) {
        sendForward(announceGroupId, [{ type: "node", data: { name: "心动天使", uin: "2852199344", content: `✨ 哎呀，有 ${publicNodes.length} 份心意在飞往信箱的途中，不小心飘落到了公告区...` } }, ...publicNodes]);
    }

    if (success > 0 && announceGroupId) {
        sendTextToGroup(platform, announceGroupId, `💌 今日心动信已派送完毕，共派送 ${success} 封信件，最高收信 ${maxReceived} 封～`);
    }

    kvSet(mailKey, failedRecords);
    if (success > 0) recordMeetingAndAnnounce("心动信", platform, ctx, ep);
    return { success, fail, publicCount, empty: false, status: "派送完成" };
}

let _loveMailLastTriggerMinute = -1;
function loveMailTick() {
    if (!isLoveMailEnabled()) return;
    const now = new Date();
    const currentMinute = now.getMinutes();
    const currentTimeTotal = now.getHours() * 60 + currentMinute;
    if (currentMinute === _loveMailLastTriggerMinute) return;

    const deliveryTime = (cachedGet("lovemail_delivery_time") || "22:00").replace(/"/g, "").trim() || "22:00";
    const timeParts = deliveryTime.split(':').map(Number);
    if (timeParts.length !== 2) return;
    const [targetH, targetM] = timeParts;
    const targetTimeTotal = targetH * 60 + targetM;
    const getOffsetTotal = (offset) => (targetTimeTotal + offset + 1440) % 1440;

    if (currentTimeTotal === targetTimeTotal) {
        const backgroundGroupId = kvGet("background_group_id", null);
        try {
            performLoveMailDelivery(null, { platform: "QQ" }, backgroundGroupId);
        } catch (err) {
            console.error(`[心动信箱] 自动派送异常: ${err.message}`);
        }
        _loveMailLastTriggerMinute = currentMinute;
    } else if (currentTimeTotal === getOffsetTotal(-5)) {
        // 提醒类播报只在档期主区间内发（补戏/超期/开季前都不发），跟弧长统计的口径保持一致；
        // 到点的正式派送不受这条限制，已经投的信照常派送
        if (getScheduleZone() === "main") {
            const announceGid = kvGet("adminAnnounceGroupId", null);
            if (announceGid) sendTextToGroup("QQ", announceGid, `📬 邮差正在整理信箱，心动信件即将在 5 分钟后开始派送，请注意查收。`);
        }
        _loveMailLastTriggerMinute = currentMinute;
    } else if (currentTimeTotal === getOffsetTotal(-10)) {
        if (getScheduleZone() === "main") {
            const groups = kvGet("a_private_group", {})["QQ"] || {};
            const targetGids = [...new Set(Object.values(groups).map(v => v[1]))];
            targetGids.forEach(gid => sendTextToGroup("QQ", gid, `⌛ 投递截止预告：\n心动信箱将于 10 分钟后截止收稿并开始派送，还没投递的小伙伴要抓紧咯～`));
        }
        _loveMailLastTriggerMinute = currentMinute;
    }
}

let cmd_deliver_lovemail = seal.ext.newCmdItemInfo();
cmd_deliver_lovemail.name = "统一送心动信";
cmd_deliver_lovemail.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) return seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
    const result = performLoveMailDelivery(ctx, msg);
    if (result.empty) {
        seal.replyToSender(ctx, msg, "📭 信箱空空如也。");
    } else {
        seal.replyToSender(ctx, msg, `📬 手动投递完成！结果: ${result.status} (成功 ${result.success} 封)`);
    }
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["统一送心动信"] = cmd_deliver_lovemail;

function getSafeEndPoint(platform = "QQ") {
    const eps = seal.getEndPoints();
    if (!eps || eps.length === 0) return null;
    let target = eps.find(e => e.platform === platform && e.state === 1);
    if (!target) target = eps.find(e => e.state === 1);
    if (!target) target = eps[0];
    return target;
}

const sendTextToGroup = (platform, gid, text) => {
    try {
        const ep = getSafeEndPoint(platform);
        if (!ep) return;
        const target = `${platform}-Group:${gid.toString().replace(/\D/g, "")}`;
        const m = seal.newMessage();
        m.messageType = "group";
        m.groupId = target;
        seal.replyToSender(seal.createTempCtx(ep, m), m, text);
    } catch (e) {
        console.error(`[LoveMail] sendTextToGroup 异常:`, e);
    }
};

// 返回今天的 MMDD 字符串，如 "0528"
function getTodayMMDD() {
    const d = new Date();
    return String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
}

// 档期自动 D0：每分钟检查一次，档期开始日当天 global_days 为空时自动设置 D0
let _lastAutoD0Date = "";
function checkAutoD0() {
    const schedStart = cachedGet("season_schedule_start") || "";
    if (!schedStart) return;
    const today = getTodayMMDD();
    if (today !== schedStart) return;
    if (_lastAutoD0Date === today) return;          // 今天已处理过
    const current = cachedGet("global_days") || "";
    if (current && current !== "D100") return;        // 已有正式天数，不覆盖；D100 是开季占位值，允许自动切到 D0
    cachedSet("global_days", "D0");
    _lastAutoD0Date = today;
    const announceGid = kvGet("adminAnnounceGroupId", null);
    if (announceGid) sendTextToGroup("QQ", announceGid, `🗓️ 档期正式开始！游戏天数已自动设置为 D0。`);
}

// 到期约会群自动巡检：group_expire_info 到期后不会自动清理，
// 之前完全依赖管理员手动跑「查看到期群」才能发现，这里改为主动推送到后台群提醒。
// 每个 gid 只提醒一次（expireNotified 标记），避免同一个到期群反复刷屏；
// 群结束（结束私约/强结私约）时 group_expire_info[gid] 会被整条删除，标记随之自然清除。
function checkExpiredGroups() {
    const backgroundGroupId = kvGet("background_group_id", null);
    if (!backgroundGroupId) return;

    const groupInfo = kvGet("group_expire_info", {});
    const now = Date.now();
    let changed = false;

    for (const [gid, info] of Object.entries(groupInfo)) {
        if (now <= info.expireTime || info.expireNotified) continue;
        const label = getCustomTypeLabel(info.subtype || "") || "小群";
        const participants = (info.participants || []).join("、") || "未知";
        sendTextToGroup("QQ", backgroundGroupId,
            `⏰ 群号 ${gid}（${label}）已到期未处理\n参与者：${participants}\n时间：${info.day || ""} ${info.time || ""}\n如互动已结束，请及时「强结私约 ${gid}」释放群号。`);
        info.expireNotified = true;
        changed = true;
    }

    if (changed) kvSet("group_expire_info", groupInfo);
}
setInterval(() => {
    checkAutoD0();
    checkExpiredGroups();
    loveMailTick();
}, 30000);

// ========================
// 🎭 杂项管理指令
// ========================
let cmd_set_npc = seal.ext.newCmdItemInfo();
cmd_set_npc.name = "设为npc";
cmd_set_npc.help = "用法：.设为npc [角色名]\n说明：将角色标记为NPC，标记后该角色不会参与自动分组。再次输入可取消标记。";
cmd_set_npc.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
        return seal.ext.newCmdExecuteResult(true);
    }

    let name = cmdArgs.getArgN(1);
    if (!name) {
        seal.replyToSender(ctx, msg, "❌ 请输入要操作的角色名。");
        return seal.ext.newCmdExecuteResult(true);
    }

    let platform = msg.platform;
    let storage = getRoleStorage();
    let npcList = kvGet("a_npc_list", []);

    if (!storage[platform] || !getUidByRoleName(platform, name)) {
        seal.replyToSender(ctx, msg, `❌ 未找到角色「${name}」，请先创建角色。`);
        return seal.ext.newCmdExecuteResult(true);
    }

    let index = npcList.indexOf(name);
    if (index === -1) {
        npcList.push(name);
        kvSet("a_npc_list", npcList);
        seal.replyToSender(ctx, msg, `✅ 已将「${name}」设为 NPC，分组时将自动跳过。`);
    } else {
        npcList.splice(index, 1);
        kvSet("a_npc_list", npcList);
        seal.replyToSender(ctx, msg, `✅ 已取消「${name}」的 NPC 身份。`);
    }

    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["设为npc"] = cmd_set_npc;

// 通用NPC：账号本身没有固定角色名，在任意有计时器的群里发言时首行写「这次扮演的名字」即可，
// 用来支持一个账号轮流扮演不同龙套（比如路人甲、路人乙）。需要先创建/绑定过角色，会自动一并标记为NPC。
let cmd_set_generic_npc = seal.ext.newCmdItemInfo();
cmd_set_generic_npc.name = "设为通用NPC";
cmd_set_generic_npc.help = "用法：.设为通用NPC [角色名]\n说明：将角色标记为「通用NPC」——该账号发言时不再要求首行匹配固定角色名，" +
    "而是把首行写的任意名字当作这次扮演的角色记入复盘（格式同普通角色：名字+换行/空格/冒号+正文）。" +
    "会自动一并标记为NPC。再次输入可取消标记。";
cmd_set_generic_npc.solve = (ctx, msg, cmdArgs) => {
    if (!isUserAdmin(ctx, msg)) {
        seal.replyToSender(ctx, msg, "❌ 权限不足，仅管理员可用。");
        return seal.ext.newCmdExecuteResult(true);
    }

    let name = cmdArgs.getArgN(1);
    if (!name) {
        seal.replyToSender(ctx, msg, "❌ 请输入要操作的角色名。");
        return seal.ext.newCmdExecuteResult(true);
    }

    let platform = msg.platform;
    let storage = getRoleStorage();

    if (!storage[platform] || !getUidByRoleName(platform, name)) {
        seal.replyToSender(ctx, msg, `❌ 未找到角色「${name}」，请先创建角色。`);
        return seal.ext.newCmdExecuteResult(true);
    }

    let genericList = kvGet("a_generic_npc_list", []);
    let index = genericList.indexOf(name);
    if (index === -1) {
        genericList.push(name);
        kvSet("a_generic_npc_list", genericList);
        let npcList = kvGet("a_npc_list", []);
        if (!npcList.includes(name)) {
            npcList.push(name);
            kvSet("a_npc_list", npcList);
        }
        seal.replyToSender(ctx, msg, `✅ 已将「${name}」设为通用NPC。之后该账号在有计时器的群里发言，首行写谁的名字就记谁的话。`);
    } else {
        genericList.splice(index, 1);
        kvSet("a_generic_npc_list", genericList);
        seal.replyToSender(ctx, msg, `✅ 已取消「${name}」的通用NPC身份，恢复为按固定角色名匹配。`);
    }

    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["设为通用NPC"] = cmd_set_generic_npc;

// 创建NPC（与创建新角色逻辑相同，额外加入 npc_list）
let cmd_create_npc = seal.ext.newCmdItemInfo();
cmd_create_npc.name = "创建NPC";
cmd_create_npc.help = "用法：。创建NPC [角色名]\n说明：创建角色并自动标记为NPC身份（不计入弧长统计）。";
cmd_create_npc.solve = (ctx, msg, cmdArgs) => {
    const name = cmdArgs.getArgN(1);
    if (!name || name === "help") {
        const ret = seal.ext.newCmdExecuteResult(true);
        ret.showHelp = true;
        return ret;
    }

    // archive 开启时必须先有活跃季度
    if (isArchiveEnabled() && !hasActiveSeason()) {
        seal.replyToSender(ctx, msg, "❌ 当前无活跃季度。请先运行「创建新季度 恋综名 复盘/不复盘 MMDD-MMDD」。");
        return seal.ext.newCmdExecuteResult(true);
    }

    const platform = msg.platform;
    const gid = msg.groupId ? msg.groupId.replace(`${platform}-Group:`, "") : "0";
    const uid = msg.sender.userId.replace(`${platform}:`, "");
    const storage = getRoleStorage();
    if (!storage[platform]) storage[platform] = {};

    // 检查名称是否被他人占用
    const existingUidForName = Object.entries(storage[platform]).find(([k, v]) => v[0] === name && k !== uid)?.[0];
    if (existingUidForName) {
        seal.replyToSender(ctx, msg, `❌ 名称「${name}」已被其他用户占用`);
        return seal.ext.newCmdExecuteResult(true);
    }

    // 已有角色则拒绝
    if (storage[platform][uid]) {
        const existingName = storage[platform][uid][0];
        seal.replyToSender(ctx, msg, `⚠️ 你已有角色「${existingName}」。若想改名，请发送「修改名字 新名字」。`);
        return seal.ext.newCmdExecuteResult(true);
    }

    storage[platform][uid] = [name, gid];
    kvSet("a_private_group", storage);
    initCharProfile(platform, name);

    // 加入 NPC 列表
    const npcList = kvGet("a_npc_list", []);
    if (!npcList.includes(name)) {
        npcList.push(name);
        kvSet("a_npc_list", npcList);
    }

    const profile = getCharProfile(platform, name);
    seal.replyToSender(ctx, msg,
        `✅ NPC「${name}」创建成功！已自动标记为NPC身份。\n` +
        `\n以下是初始档案：\n` +
        `👤 性别：${profile.gender}　年龄：${profile.age}\n` +
        `🌸 皮相：${profile.look}\n` +
        `\n💡 可发送以下消息定制角色：\n` +
        `  修改性别 男/女\n` +
        `  修改年龄 数字\n` +
        `  修改皮相 明星名\n` +
        `  修改签名 你的签名`
    );
    return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap["创建NPC"] = cmd_create_npc;

// ========================
// ========================
// RPG背包辅助函数（复制自长日RPG，确保长日系统能调用）
// ========================
function getRegistry_rpg() {
    const main = seal.ext.find("changri");
    if (!main) return {};
    const items = kvGet("item_registry", {});
    const equips = kvGet("equipment_registry", {});
    return Object.assign({}, items, equips);
}
function findItem_rpg(reg, input) {
    if (!input) return null;
    const code = input.toUpperCase();
    if (reg[code]) return reg[code];
    return Object.values(reg).find(r => r.name === input) || null;
}
function findCurrencyByName_rpg(name) {
    const reg = getRegistry_rpg();
    return Object.values(reg).find(i => i.type === "currency" && i.name === name) || null;
}
function getInvCount_rpg(roleKey, code) {
    const inv = getInvAll_rpg()[roleKey] || [];
    return inv.filter(e => e.code === code).reduce((s, e) => s + e.count, 0);
}
function removeFromInv_rpg(roleKey, code, count) {
    const invs = getInvAll_rpg();
    const inv = invs[roleKey] || [];
    let remaining = count;
    for (const entry of inv.filter(e => e.code === code).sort((a, b) => (b.remainingUses || 0) - (a.remainingUses || 0))) {
        if (remaining <= 0) break;
        const take = Math.min(entry.count, remaining);
        entry.count -= take;
        remaining -= take;
    }
    invs[roleKey] = inv.filter(e => e.count > 0);
    saveInvAll_rpg(invs);
}
function getInvAll_rpg() {
    const main = seal.ext.find("changri");
    return main ? kvGet("global_inventories", {}) : {};
}
function saveInvAll_rpg(invs) {
    const main = seal.ext.find("changri");
    if (main) kvSet("global_inventories", invs);
}
function addToInv_system(roleKey, code, count) {
    const invs = getInvAll_rpg();
    const inv = invs[roleKey] || [];
    const reg = getRegistry_rpg();
    const itemInfo = reg[code];

    if (!itemInfo) {
        console.error(`[长日系统] 尝试添加不存在的物品代码: ${code}`);
        return false;
    }

    const initialUses = itemInfo.maxUses ?? -1;
    const entry = inv.find(e => e.code === code && (e.remainingUses ?? -1) === initialUses);

    if (entry) {
        entry.count += count;
    } else {
        const newEntry = { code, count, remainingUses: initialUses };
        if (itemInfo.durability != null) newEntry.currentDurability = itemInfo.durability;
        inv.push(newEntry);
    }

    invs[roleKey] = inv;
    saveInvAll_rpg(invs);
    return true;
}

// 拍卖指令已移至 长日拍卖.js
// 季度/时间线/场次指令已移至 长日季度.js
