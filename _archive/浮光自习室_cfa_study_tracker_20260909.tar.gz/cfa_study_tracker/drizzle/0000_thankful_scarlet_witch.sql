CREATE TABLE `study_logs` (
	`date` text PRIMARY KEY NOT NULL,
	`video_minutes` integer DEFAULT 0 NOT NULL,
	`questions` integer DEFAULT 0 NOT NULL,
	`old_mistakes` integer DEFAULT 0 NOT NULL,
	`review_minutes` integer DEFAULT 0 NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`updated_at` integer NOT NULL
);
